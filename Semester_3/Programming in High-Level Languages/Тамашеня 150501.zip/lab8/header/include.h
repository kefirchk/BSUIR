#pragma once
#include <iostream>
#include <iomanip>
#include <windows.h>
#include <fstream>
#include <stack>
using namespace std;


#define CHAR_LENGTH 20
#define INT_LENGTH 15
#define STR_LENGTH 80
#define MAX_VALUE 999

void setColor(int color);

enum myBool
{
	notSearch = -1,
	No = 0,
	Yes = 1,
};

template<typename T>
void outputStack(stack<T> thisStack)
{
	T value;
	value.outputFrame();
	auto cont = thisStack._Get_container();
	for (auto iter = cont.rbegin(); iter != cont.rend(); iter++)
		cout << *iter;
}
