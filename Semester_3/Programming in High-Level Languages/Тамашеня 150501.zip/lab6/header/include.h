#pragma once
#include <iostream>
#include <iomanip>
#include <windows.h>
#include <fstream>
using namespace std;


#define CHAR_LENGTH 20
#define INT_LENGTH 15
#define STR_LENGTH 80
#define MAX_VALUE 999

void setColor(int color);
