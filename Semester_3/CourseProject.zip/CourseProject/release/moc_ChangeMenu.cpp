/****************************************************************************
** Meta object code from reading C++ file 'ChangeMenu.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../ChangeMenu.h"
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ChangeMenu.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_ChangeMenu_t {
    uint offsetsAndSizes[22];
    char stringdata0[11];
    char stringdata1[35];
    char stringdata2[1];
    char stringdata3[30];
    char stringdata4[33];
    char stringdata5[42];
    char stringdata6[43];
    char stringdata7[40];
    char stringdata8[41];
    char stringdata9[34];
    char stringdata10[34];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_ChangeMenu_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_ChangeMenu_t qt_meta_stringdata_ChangeMenu = {
    {
        QT_MOC_LITERAL(0, 10),  // "ChangeMenu"
        QT_MOC_LITERAL(11, 34),  // "on_ExchCurrRate_buttonBox_acc..."
        QT_MOC_LITERAL(46, 0),  // ""
        QT_MOC_LITERAL(47, 29),  // "on_addToAccSum_Button_clicked"
        QT_MOC_LITERAL(77, 32),  // "on_takeFromAccSum_Button_clicked"
        QT_MOC_LITERAL(110, 41),  // "on_showPossibleCredits_pushBu..."
        QT_MOC_LITERAL(152, 42),  // "on_showPossibleDeposits_pushB..."
        QT_MOC_LITERAL(195, 39),  // "on_closeGivenCredits_pushButt..."
        QT_MOC_LITERAL(235, 40),  // "on_closeGivenDeposits_pushBut..."
        QT_MOC_LITERAL(276, 33),  // "on_payForCreditSum_Button_cli..."
        QT_MOC_LITERAL(310, 33)   // "on_saveChanges_pushButton_cli..."
    },
    "ChangeMenu",
    "on_ExchCurrRate_buttonBox_accepted",
    "",
    "on_addToAccSum_Button_clicked",
    "on_takeFromAccSum_Button_clicked",
    "on_showPossibleCredits_pushButton_clicked",
    "on_showPossibleDeposits_pushButton_clicked",
    "on_closeGivenCredits_pushButton_clicked",
    "on_closeGivenDeposits_pushButton_clicked",
    "on_payForCreditSum_Button_clicked",
    "on_saveChanges_pushButton_clicked"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_ChangeMenu[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   68,    2, 0x08,    1 /* Private */,
       3,    0,   69,    2, 0x08,    2 /* Private */,
       4,    0,   70,    2, 0x08,    3 /* Private */,
       5,    0,   71,    2, 0x08,    4 /* Private */,
       6,    0,   72,    2, 0x08,    5 /* Private */,
       7,    0,   73,    2, 0x08,    6 /* Private */,
       8,    0,   74,    2, 0x08,    7 /* Private */,
       9,    0,   75,    2, 0x08,    8 /* Private */,
      10,    0,   76,    2, 0x08,    9 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject ChangeMenu::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_ChangeMenu.offsetsAndSizes,
    qt_meta_data_ChangeMenu,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_ChangeMenu_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<ChangeMenu, std::true_type>,
        // method 'on_ExchCurrRate_buttonBox_accepted'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_addToAccSum_Button_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_takeFromAccSum_Button_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_showPossibleCredits_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_showPossibleDeposits_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_closeGivenCredits_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_closeGivenDeposits_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_payForCreditSum_Button_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_saveChanges_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void ChangeMenu::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<ChangeMenu *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_ExchCurrRate_buttonBox_accepted(); break;
        case 1: _t->on_addToAccSum_Button_clicked(); break;
        case 2: _t->on_takeFromAccSum_Button_clicked(); break;
        case 3: _t->on_showPossibleCredits_pushButton_clicked(); break;
        case 4: _t->on_showPossibleDeposits_pushButton_clicked(); break;
        case 5: _t->on_closeGivenCredits_pushButton_clicked(); break;
        case 6: _t->on_closeGivenDeposits_pushButton_clicked(); break;
        case 7: _t->on_payForCreditSum_Button_clicked(); break;
        case 8: _t->on_saveChanges_pushButton_clicked(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject *ChangeMenu::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ChangeMenu::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ChangeMenu.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int ChangeMenu::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 9;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
