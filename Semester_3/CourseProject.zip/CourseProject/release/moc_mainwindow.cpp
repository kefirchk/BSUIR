/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../mainwindow.h"
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_MainWindow_t {
    uint offsetsAndSizes[66];
    char stringdata0[11];
    char stringdata1[29];
    char stringdata2[1];
    char stringdata3[29];
    char stringdata4[41];
    char stringdata5[41];
    char stringdata6[40];
    char stringdata7[30];
    char stringdata8[33];
    char stringdata9[31];
    char stringdata10[31];
    char stringdata11[36];
    char stringdata12[40];
    char stringdata13[33];
    char stringdata14[37];
    char stringdata15[35];
    char stringdata16[42];
    char stringdata17[6];
    char stringdata18[27];
    char stringdata19[28];
    char stringdata20[35];
    char stringdata21[36];
    char stringdata22[37];
    char stringdata23[39];
    char stringdata24[38];
    char stringdata25[35];
    char stringdata26[38];
    char stringdata27[33];
    char stringdata28[35];
    char stringdata29[29];
    char stringdata30[39];
    char stringdata31[31];
    char stringdata32[20];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_MainWindow_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 28),  // "on_signIn_pushButton_clicked"
        QT_MOC_LITERAL(40, 0),  // ""
        QT_MOC_LITERAL(41, 28),  // "on_signUp_pushButton_clicked"
        QT_MOC_LITERAL(70, 40),  // "on_currency_converter_pushBut..."
        QT_MOC_LITERAL(111, 40),  // "on_deposit_calculator_pushBut..."
        QT_MOC_LITERAL(152, 39),  // "on_credit_calculator_pushButt..."
        QT_MOC_LITERAL(192, 29),  // "on_options_pushButton_clicked"
        QT_MOC_LITERAL(222, 32),  // "on_openNewAcc_pushButton_clicked"
        QT_MOC_LITERAL(255, 30),  // "on_closeAcc_pushButton_clicked"
        QT_MOC_LITERAL(286, 30),  // "on_addMoney_pushButton_clicked"
        QT_MOC_LITERAL(317, 35),  // "on_takeMoneyFrom_pushButton_c..."
        QT_MOC_LITERAL(353, 39),  // "on_updateAccountInfo_pushButt..."
        QT_MOC_LITERAL(393, 32),  // "on_transferTo_pushButton_clicked"
        QT_MOC_LITERAL(426, 36),  // "on_changeCurrRate_pushButton_..."
        QT_MOC_LITERAL(463, 34),  // "on_backForAdmin_pushButton_cl..."
        QT_MOC_LITERAL(498, 41),  // "on_backFromUserOptions_pushBu..."
        QT_MOC_LITERAL(540, 5),  // "exits"
        QT_MOC_LITERAL(546, 26),  // "on_given_credits_triggered"
        QT_MOC_LITERAL(573, 27),  // "on_given_deposits_triggered"
        QT_MOC_LITERAL(601, 34),  // "on_cleanHistory_pushButton_cl..."
        QT_MOC_LITERAL(636, 35),  // "on_takeNewCredit_pushButton_c..."
        QT_MOC_LITERAL(672, 36),  // "on_takeNewDeposit_pushButton_..."
        QT_MOC_LITERAL(709, 38),  // "on_updateMyDeposits_pushButto..."
        QT_MOC_LITERAL(748, 37),  // "on_updateMyCredits_pushButton..."
        QT_MOC_LITERAL(786, 34),  // "on_payForCredit_pushButton_cl..."
        QT_MOC_LITERAL(821, 37),  // "on_takeFromDeposit_pushButton..."
        QT_MOC_LITERAL(859, 32),  // "on_deleteUser_pushButton_clicked"
        QT_MOC_LITERAL(892, 34),  // "on_showAllUsers_pushButton_cl..."
        QT_MOC_LITERAL(927, 28),  // "on_search_pushButton_clicked"
        QT_MOC_LITERAL(956, 38),  // "on_changeParametres_pushButto..."
        QT_MOC_LITERAL(995, 30),  // "on_editUser_pushButton_clicked"
        QT_MOC_LITERAL(1026, 19)   // "on_action_triggered"
    },
    "MainWindow",
    "on_signIn_pushButton_clicked",
    "",
    "on_signUp_pushButton_clicked",
    "on_currency_converter_pushButton_clicked",
    "on_deposit_calculator_pushButton_clicked",
    "on_credit_calculator_pushButton_clicked",
    "on_options_pushButton_clicked",
    "on_openNewAcc_pushButton_clicked",
    "on_closeAcc_pushButton_clicked",
    "on_addMoney_pushButton_clicked",
    "on_takeMoneyFrom_pushButton_clicked",
    "on_updateAccountInfo_pushButton_clicked",
    "on_transferTo_pushButton_clicked",
    "on_changeCurrRate_pushButton_clicked",
    "on_backForAdmin_pushButton_clicked",
    "on_backFromUserOptions_pushButton_clicked",
    "exits",
    "on_given_credits_triggered",
    "on_given_deposits_triggered",
    "on_cleanHistory_pushButton_clicked",
    "on_takeNewCredit_pushButton_clicked",
    "on_takeNewDeposit_pushButton_clicked",
    "on_updateMyDeposits_pushButton_clicked",
    "on_updateMyCredits_pushButton_clicked",
    "on_payForCredit_pushButton_clicked",
    "on_takeFromDeposit_pushButton_clicked",
    "on_deleteUser_pushButton_clicked",
    "on_showAllUsers_pushButton_clicked",
    "on_search_pushButton_clicked",
    "on_changeParametres_pushButton_clicked",
    "on_editUser_pushButton_clicked",
    "on_action_triggered"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_MainWindow[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      31,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  200,    2, 0x08,    1 /* Private */,
       3,    0,  201,    2, 0x08,    2 /* Private */,
       4,    0,  202,    2, 0x08,    3 /* Private */,
       5,    0,  203,    2, 0x08,    4 /* Private */,
       6,    0,  204,    2, 0x08,    5 /* Private */,
       7,    0,  205,    2, 0x08,    6 /* Private */,
       8,    0,  206,    2, 0x08,    7 /* Private */,
       9,    0,  207,    2, 0x08,    8 /* Private */,
      10,    0,  208,    2, 0x08,    9 /* Private */,
      11,    0,  209,    2, 0x08,   10 /* Private */,
      12,    0,  210,    2, 0x08,   11 /* Private */,
      13,    0,  211,    2, 0x08,   12 /* Private */,
      14,    0,  212,    2, 0x08,   13 /* Private */,
      15,    0,  213,    2, 0x08,   14 /* Private */,
      16,    0,  214,    2, 0x08,   15 /* Private */,
      17,    0,  215,    2, 0x08,   16 /* Private */,
      18,    0,  216,    2, 0x08,   17 /* Private */,
      19,    0,  217,    2, 0x08,   18 /* Private */,
      20,    0,  218,    2, 0x08,   19 /* Private */,
      21,    0,  219,    2, 0x08,   20 /* Private */,
      22,    0,  220,    2, 0x08,   21 /* Private */,
      23,    0,  221,    2, 0x08,   22 /* Private */,
      24,    0,  222,    2, 0x08,   23 /* Private */,
      25,    0,  223,    2, 0x08,   24 /* Private */,
      26,    0,  224,    2, 0x08,   25 /* Private */,
      27,    0,  225,    2, 0x08,   26 /* Private */,
      28,    0,  226,    2, 0x08,   27 /* Private */,
      29,    0,  227,    2, 0x08,   28 /* Private */,
      30,    0,  228,    2, 0x08,   29 /* Private */,
      31,    0,  229,    2, 0x08,   30 /* Private */,
      32,    0,  230,    2, 0x08,   31 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSizes,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'on_signIn_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_signUp_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_currency_converter_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_deposit_calculator_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_credit_calculator_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_options_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_openNewAcc_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_closeAcc_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_addMoney_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_takeMoneyFrom_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_updateAccountInfo_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_transferTo_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_changeCurrRate_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_backForAdmin_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_backFromUserOptions_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'exits'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_given_credits_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_given_deposits_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_cleanHistory_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_takeNewCredit_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_takeNewDeposit_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_updateMyDeposits_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_updateMyCredits_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_payForCredit_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_takeFromDeposit_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_deleteUser_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_showAllUsers_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_search_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_changeParametres_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_editUser_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_action_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_signIn_pushButton_clicked(); break;
        case 1: _t->on_signUp_pushButton_clicked(); break;
        case 2: _t->on_currency_converter_pushButton_clicked(); break;
        case 3: _t->on_deposit_calculator_pushButton_clicked(); break;
        case 4: _t->on_credit_calculator_pushButton_clicked(); break;
        case 5: _t->on_options_pushButton_clicked(); break;
        case 6: _t->on_openNewAcc_pushButton_clicked(); break;
        case 7: _t->on_closeAcc_pushButton_clicked(); break;
        case 8: _t->on_addMoney_pushButton_clicked(); break;
        case 9: _t->on_takeMoneyFrom_pushButton_clicked(); break;
        case 10: _t->on_updateAccountInfo_pushButton_clicked(); break;
        case 11: _t->on_transferTo_pushButton_clicked(); break;
        case 12: _t->on_changeCurrRate_pushButton_clicked(); break;
        case 13: _t->on_backForAdmin_pushButton_clicked(); break;
        case 14: _t->on_backFromUserOptions_pushButton_clicked(); break;
        case 15: _t->exits(); break;
        case 16: _t->on_given_credits_triggered(); break;
        case 17: _t->on_given_deposits_triggered(); break;
        case 18: _t->on_cleanHistory_pushButton_clicked(); break;
        case 19: _t->on_takeNewCredit_pushButton_clicked(); break;
        case 20: _t->on_takeNewDeposit_pushButton_clicked(); break;
        case 21: _t->on_updateMyDeposits_pushButton_clicked(); break;
        case 22: _t->on_updateMyCredits_pushButton_clicked(); break;
        case 23: _t->on_payForCredit_pushButton_clicked(); break;
        case 24: _t->on_takeFromDeposit_pushButton_clicked(); break;
        case 25: _t->on_deleteUser_pushButton_clicked(); break;
        case 26: _t->on_showAllUsers_pushButton_clicked(); break;
        case 27: _t->on_search_pushButton_clicked(); break;
        case 28: _t->on_changeParametres_pushButton_clicked(); break;
        case 29: _t->on_editUser_pushButton_clicked(); break;
        case 30: _t->on_action_triggered(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 31)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 31;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 31)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 31;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
