#pragma once

#define BUFFER_SIZE 512
#define STR_SIZE 80
#define CHANNEL 5
#define BACKLOG 5
#define FILE_TO_SEND "../../send_files/sound_sended.wav"
#define FILE_TO_RECV "../../recv_files/sound_received.mp3"
//#define FILE_TO_RECV "./sound_received.mp3"
