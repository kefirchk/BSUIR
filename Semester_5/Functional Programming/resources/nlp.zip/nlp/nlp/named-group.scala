import java.io.FileInputStream
import opennlp.tools.namefind.{NameFinderME, TokenNameFinderModel}
import opennlp.tools.tokenize.*
import opennlp.tools.util.Span

object Main25 {
    def main(args:Array[String]): Unit = {
        // Модель токенизатора
        val tokenizerModelIn = new FileInputStream("en-token.bin")
        val tokenizerModel = new opennlp.tools.tokenize.TokenizerModel(tokenizerModelIn)
        val tokenizer = new opennlp.tools.tokenize.TokenizerME(tokenizerModel)

        // Модель для обнаружения имен в тексте
        val nerModelIn = new FileInputStream("en-ner-person.bin")
        val nerModel = new TokenNameFinderModel(nerModelIn)
        val ner = new NameFinderME(nerModel)

  		  // В этом тексте присутствуют 4 имени
        val text = "John is supposed to marry Monica, but Jason Welsh is against this marriage because Fred thinks it's stupid"

        // Деление текста на токены
        val tokens = tokenizer.tokenize(text)
        println(s"Tkens count: ${tokens.length}")

  		  // Поиск имен в тексте
        val spans = ner.find(tokens)
        println(s"Persons count: ${spans.length}")

        // Вывод имен
        for(span <- spans)
        {
            val entityType = span.getType
            val name = tokens.slice(span.getStart, span.getEnd).mkString(" ")
            println(s"$entityType: $name")
        }
    }
} 