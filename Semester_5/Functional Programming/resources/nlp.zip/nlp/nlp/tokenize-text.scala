import java.io.FileInputStream
import opennlp.tools.namefind.{NameFinderME, TokenNameFinderModel}
import opennlp.tools.tokenize.*
import opennlp.tools.util.Span


//import scala.io.File

object Main {

  def main(args: Array[String]): Unit = {
    print("Input text:")
    val text: String = scala.io.StdIn.readLine()

    val tokenizerModelIn = new FileInputStream("en-token.bin")
    val tokenizerModel = new opennlp.tools.tokenize.TokenizerModel(tokenizerModelIn)
    val tokenizer = new opennlp.tools.tokenize.TokenizerME(tokenizerModel)

    // text = "Rayony kvartyaly zhilie massivy."
    val tokens = tokenizer.tokenize(text)               // разделение на токены
    for(token <- tokens) {
      println(s"$token")
    }
  }
}