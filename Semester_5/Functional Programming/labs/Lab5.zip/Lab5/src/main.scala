//import java.awt.event.{ActionEvent, ActionListener}
//
//import javax.swing.{JButton, JFrame, JLabel, JTextArea, JTextField, JComboBox, JPanel, SwingUtilities}
//import java.awt.Dimension
//import java.sql.{Connection, DriverManager, ResultSet}
//import java.awt.Color
//import java.awt.Font
//
//object main {
//    val frame = new JFrame("Grocery Store Application")
//frame.setSize(920, 500)
//frame.setLayout(null)
//frame.getContentPane().setBackground(Color.DARK_GRAY) // Устанавливаем темно-серый цвет фона
//
//def main(args: Array[String]): Unit = {
//  SwingUtilities.invokeLater(() => {        
//    val title = new JLabel("GROCERY STORE") 
//    title.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 44)) 
//    title.setForeground(Color.YELLOW) 
//    title.setBounds(250, 10, 650, 50) 
//    frame.add(title) 
//    
//    val errorMessage = new JLabel("You should fill \"Product\", \"Price\", \"Count\" fields") 
//    errorMessage.setFont(new Font("Arial", Font.BOLD, 18)) 
//    errorMessage.setForeground(Color.RED) 
//    errorMessage.setBounds(200, 400, 450, 50) 
//    frame.add(errorMessage) 
//    errorMessage.setVisible(false)
//    
//    val errorMessage2 = new JLabel("There is no elements in database") 
//    errorMessage2.setFont(new Font("Arial", Font.BOLD, 18)) 
//    errorMessage2.setForeground(Color.RED) 
//    errorMessage2.setBounds(200, 400, 450, 50) 
//    frame.add(errorMessage2) 
//    errorMessage2.setVisible(false)
//    
//    val errorMessage3 = new JLabel("There is no elements with price more then entered") 
//    errorMessage3.setFont(new Font("Arial", Font.BOLD, 18)) 
//    errorMessage3.setForeground(Color.RED) 
//    errorMessage3.setBounds(200, 400, 450, 50) 
//    frame.add(errorMessage3) 
//    errorMessage3.setVisible(false)
//    
//    val errorMessage4 = new JLabel("\"Product\" length must be < 15 characters, \"Price\", \"Count\" must be < 1000") 
//    errorMessage4.setFont(new Font("Arial", Font.BOLD, 18)) 
//    errorMessage4.setForeground(Color.RED)
//    errorMessage4.setBounds(200, 400, 670, 50) 
//    frame.add(errorMessage4) 
//    errorMessage4.setVisible(false)
//    
//    val errorMessage5 = new JLabel("You should fill \"Min price\" field") 
//    errorMessage5.setFont(new Font("Arial", Font.BOLD, 18)) 
//    errorMessage5.setForeground(Color.RED) 
//    errorMessage5.setBounds(200, 400, 670, 50) 
//    frame.add(errorMessage5)
//    errorMessage5.setVisible(false)
//
//    //////////////////////////////LABELS/////////////////////////////////////////////////
//
//    val productLabel = new JLabel("Product")
//    productLabel.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 16))
//    productLabel.setForeground(Color.WHITE)
//    
//    val priceLabel = new JLabel("Price")
//    priceLabel.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 16))
//    priceLabel.setForeground(Color.WHITE)
//    
//    val countLabel = new JLabel("Count")
//    countLabel.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 16))
//    countLabel.setForeground(Color.WHITE)
//    
//    val moreThanLabel = new JLabel("Min price")
//    moreThanLabel.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 16))
//    moreThanLabel.setForeground(Color.WHITE)
//    
//    productLabel.setBounds(25, 70, 145, 30)
//    priceLabel.setBounds(25, 150, 145, 30)
//    countLabel.setBounds(25, 230, 145, 30)
//    moreThanLabel.setBounds(25, 310, 145, 30)
//
//    ///////////////////////////BUTTONS//////////////////////////////////////////////
//    
//    val insertButton = new JButton("Insert")
//    insertButton.setFont(new Font("Arial", Font.BOLD, 16)) 
//    insertButton.setForeground(Color.YELLOW) 
//    insertButton.setBackground(Color.decode("#555555"))
//        
//    val showDBButton = new JButton("Show")
//    showDBButton.setFont(new Font("Arial", Font.BOLD, 16)) 
//    showDBButton.setForeground(Color.YELLOW) 
//    showDBButton.setBackground(Color.decode("#555555"))
//       
//    val getAllMaxButton = new JButton("Max(price*count, all)")
//    getAllMaxButton.setFont(new Font("Arial", Font.BOLD, 16)) 
//    getAllMaxButton.setForeground(Color.YELLOW) 
//    getAllMaxButton.setBackground(Color.decode("#555555"))
//      
//    val findAllByFilterButton = new JButton("Find")
//    findAllByFilterButton.setFont(new Font("Arial", Font.BOLD, 16)) 
//    findAllByFilterButton.setForeground(Color.YELLOW) 
//    findAllByFilterButton.setBackground(Color.decode("#555555"))    
//    
//    val getOneMaxButton = new JButton("Max (price*count, one)")
//    getOneMaxButton.setFont(new Font("Arial", Font.BOLD, 16)) 
//    getOneMaxButton.setForeground(Color.YELLOW) 
//    getOneMaxButton.setBackground(Color.decode("#555555"))
//    
//    val averageByButton = new JButton("Average by price")
//    averageByButton.setFont(new Font("Arial", Font.BOLD, 16)) 
//    averageByButton.setForeground(Color.YELLOW) 
//    averageByButton.setBackground(Color.decode("#555555"))
//    
//    val sortButton = new JButton("Sort")
//    sortButton.setFont(new Font("Arial", Font.BOLD, 16)) 
//    sortButton.setForeground(Color.YELLOW) 
//    sortButton.setBackground(Color.decode("#555555"))
//     
//    insertButton.setBounds(30, 320, 145, 40)
//    showDBButton.setBounds(30, 380, 145, 40)
//    averageByButton.setBounds(570, 100, 295, 40)
//    sortButton.setBounds(570, 160, 145, 40)
//    getAllMaxButton.setBounds(570, 220, 295, 40)
//    getOneMaxButton.setBounds(570, 280, 295, 40)
//    findAllByFilterButton.setBounds(570, 340, 70, 40)
//
//    
//    ///////////////////////////FIELDS//////////////////////////////////////////////////
//    
//    val productField = new JTextField(20)
//    productField.setFont(new Font("Arial", Font.BOLD, 16))
//    productField.setForeground(Color.decode("#f1f4d5"))
//    productField.setBackground(Color.decode("#666666"))
//    
//    val priceField = new JTextField(20)
//    priceField.setFont(new Font("Arial", Font.BOLD, 16)) 
//    priceField.setForeground(Color.decode("#f1f4d5"))
//    priceField.setBackground(Color.decode("#666666"))   
//    
//    val countField = new JTextField(20)
//    countField.setFont(new Font("Arial", Font.BOLD, 16)) 
//    countField.setForeground(Color.decode("#f1f4d5"))
//    countField.setBackground(Color.decode("#666666"))   
//    
//    val greaterFilterField = new JTextField(20)
//    greaterFilterField.setFont(new Font("Arial", Font.BOLD, 16))
//    greaterFilterField.setForeground(Color.decode("#f1f4d5"))
//    greaterFilterField.setBackground(Color.decode("#666666"))   
//    
//    productField.setBounds(30, 100, 145, 40)
//    priceField.setBounds(30, 180, 145, 40)
//    countField.setBounds(30, 260, 145, 40)
//    greaterFilterField.setBounds(800, 340, 65, 40)
//    
//    ////////////////////////////////////////////////////////////////////////////////////
//    
//    val outputTextArea = new JTextArea()
//    outputTextArea.setEditable(false)
//    outputTextArea.setLineWrap(true)
//    outputTextArea.setFont(new Font("Arial", Font.BOLD, 16)) 
//    outputTextArea.setForeground(Color.decode("#f1f4d5"))
//    outputTextArea.setBackground(Color.decode("#666666"))  
//    //outputTextArea.setWrapStyleWord(true)
//    outputTextArea.setBounds(200, 100, 350, 260)
//    
//    
//    ////////////////////////////////COMBOBOX////////////////////////////////////////////////////
//    
//    val sortOptions = Array("by product", "by price", "by count")
//    val sortComboBox = new JComboBox(sortOptions)
//    sortComboBox.setFont(new Font("Arial", Font.BOLD, 16))
//    sortComboBox.setForeground(Color.decode("#f1f4d5"))
//    sortComboBox.setBackground(Color.decode("#666666"))
//    sortComboBox.setBounds(720, 160, 145, 40)
//    
//    val greaterFilterOptions = Array("by price", "by count")
//    val greaterFilterComboBox = new JComboBox(greaterFilterOptions)
//    greaterFilterComboBox.setFont(new Font("Arial", Font.BOLD, 16))
//    greaterFilterComboBox.setForeground(Color.decode("#f1f4d5"))
//    greaterFilterComboBox.setBackground(Color.decode("#666666"))
//    greaterFilterComboBox.setBounds(645, 340, 95, 40)
//    
//    val signsOptions = Array(">=", ">")
//    val signsComboBox = new JComboBox(signsOptions)
//    signsComboBox.setFont(new Font("Arial", Font.BOLD, 16))
//    signsComboBox.setForeground(Color.decode("#f1f4d5"))
//    signsComboBox.setBackground(Color.decode("#666666"))
//    signsComboBox.setBounds(745, 340, 50, 40)
//    
//    
//    ////////////////////////////////////////////////////////////////////////////////////
//    
//    frame.add(insertButton)
//    frame.add(showDBButton)
//    frame.add(getAllMaxButton)
//    frame.add(getOneMaxButton)
//    frame.add(averageByButton)
//    frame.add(sortButton)
//    frame.add(findAllByFilterButton)
//
//    frame.add(productLabel)
//    frame.add(priceLabel)
//    frame.add(countLabel)
//
//    frame.add(productField)
//    frame.add(priceField)
//    frame.add(countField)
//    frame.add(greaterFilterField)
//    
//    frame.getContentPane.add(outputTextArea)
//
//    frame.getContentPane.add(sortComboBox)
//    frame.getContentPane.add(greaterFilterComboBox)
//    frame.getContentPane.add(signsComboBox)
//      
//      insertButton.addActionListener(new ActionListener{        //устанавливаем обработчик insert
//        override def actionPerformed(e: ActionEvent): Unit = {
//          val url = "jdbc:mysql://localhost:3306/scala_db"
//          val username = "root"
//          val password = "1234"       
//          val tableName = "dop_products"
//          
//          Class.forName("org.gjt.mm.mysql.Driver")         
//          val connection = DriverManager.getConnection(url, username, password)
//          errorMessage.setVisible(false)
//          errorMessage2.setVisible(false)
//          errorMessage3.setVisible(false)
//          errorMessage4.setVisible(false)
//          errorMessage5.setVisible(false)
//          
//          try{
//            if(productField.getText().length() == 0 || 
//                priceField.getText().length() == 0 ||
//                countField.getText().length() == 0){
//              errorMessage.setVisible(true)
//              
//            }else if(productField.getText().length() > 15 || 
//                priceField.getText().length() > 3 ||
//                countField.getText().length() > 3){
//              errorMessage4.setVisible(true)
//            }else{
//              val statement = connection.createStatement()
//              val rs = statement.execute("INSERT INTO " + tableName + " VALUES ('" + productField.getText() + "'," + priceField.getText() + "," + countField.getText() + ")")
//              productField.setText("")
//              priceField.setText("")
//              countField.setText("")
//              outputTextArea.append("Product is added\n")
//            }
//            
//          }finally{
//            connection.close()
//          }
//        }
//      })
//      
//      showDBButton.addActionListener(new ActionListener{
//        override def actionPerformed(e: ActionEvent): Unit = {
//          val url = "jdbc:mysql://localhost:3306/scala_db"          
//          val username = "root"          
//          val password = "1234"         
//          val tableName = "dop_products"
//          
//          Class.forName("org.gjt.mm.mysql.Driver")
//          
//          errorMessage.setVisible(false)
//          errorMessage2.setVisible(false)
//          errorMessage3.setVisible(false)
//          errorMessage4.setVisible(false)
//          errorMessage5.setVisible(false)
//          
//          val connection = DriverManager.getConnection(url, username, password)          
//          try{
//            val statement = connection.createStatement()
//            val rs = statement.executeQuery("SELECT * FROM " + tableName)
//            
//            var counter = 0
//            outputTextArea.setText("")
//            outputTextArea.setText("                             \"" + tableName + "\"\n")
//            outputTextArea.append("Product\t" + "Price\t" + "Count\t\n")
//            //println("Products:")
//            while(rs.next()){
//              val product = rs.getString("product")
//              val price = rs.getInt("price")
//              val count = rs.getInt("count")
//              outputTextArea.append(product + "\t" + price + "\t" + count + "\t\n");
//              //println(s"name=$product, price=$price, count=$count")
//              counter = counter + 1
//            }
//            if(counter == 0){
//              errorMessage2.setVisible(true)
//            }
//            //println("\n")
//          }
//          finally{
//            connection.close()
//          }
//        }
//      })
//      
//      findAllByFilterButton.addActionListener(new ActionListener{
//        override def actionPerformed(e: ActionEvent): Unit = {
//          val url = "jdbc:mysql://localhost:3306/scala_db"
//          val username = "root"
//          val password = "1234"                    
//          val tableName = "dop_products"
//
//          Class.forName("org.gjt.mm.mysql.Driver")
//
//          errorMessage.setVisible(false)
//          errorMessage2.setVisible(false)
//          errorMessage3.setVisible(false)
//          errorMessage4.setVisible(false)
//          errorMessage5.setVisible(false)
//          
//          val connection = DriverManager.getConnection(url, username, password)
//          try{
//            val statement = connection.createStatement()
//            if(greaterFilterField.getText().length() == 0){
//              errorMessage5.setVisible(true)
//            }else{
//              
//              val fieldFilter = greaterFilterComboBox.getSelectedItem().toString().substring(3)
//              val minValue = greaterFilterField.getText().toString().trim()
//              val signFilter = signsComboBox.getSelectedItem().toString()
//              
//              val rs = statement.executeQuery("SELECT product, count,  " + fieldFilter + " FROM " + tableName + " WHERE " + fieldFilter + " " + signFilter + " ALL(SELECT " + fieldFilter + " FROM " + tableName + ")")
//              //val rs = statement.executeQuery("SELECT * FROM " + tableName + " GROUP BY " + fieldFilter + " HAVING (" + fieldFilter + " " + signFilter + " " + minValue + ")")
//            
//              var counter = 0
//              outputTextArea.setText("")
//              outputTextArea.append("Products with " + fieldFilter + " " + signFilter + " " + minValue + ":\n");
//              outputTextArea.append("Product\t" + "Price\t" + "Count\t\n")
//             
//              while(rs.next()){
//                val product = rs.getString("product")
//                val price = rs.getInt("price")
//                val count = rs.getInt("count")
//                
//                outputTextArea.append(product + "\t" + price + "\t" + count + "\t\n");
//                //println(s"name=$product, price=$price, count=$count")
//                counter = counter + 1
//              }
//              if(counter == 0){
//                errorMessage3.setVisible(true)
//              }
//              //println("\n")
//              greaterFilterField.setText("")
//            }
//          }
//          finally{
//            connection.close()
//          }
//        }
//      })
//      
//      getAllMaxButton.addActionListener(new ActionListener{
//        override def actionPerformed(e: ActionEvent): Unit = {
//          val url = "jdbc:mysql://localhost:3306/scala_db"
//          val username = "root"
//          val password = "1234"
//          val tableName = "dop_products"
//
//          Class.forName("org.gjt.mm.mysql.Driver")
//
//          errorMessage.setVisible(false)
//          errorMessage2.setVisible(false)
//          errorMessage3.setVisible(false)
//          errorMessage4.setVisible(false)
//          errorMessage5.setVisible(false)
//
//          val connection = DriverManager.getConnection(url, username, password)
//          try{
//            val statement = connection.createStatement()
//            val rs1 = statement.executeQuery("SELECT MAX(price * count) AS maxval FROM " + tableName)
//            
//            var max: Int = 0
//            while(rs1.next()){
//              max = rs1.getInt("maxval")
//            }
//            if(max == 0){
//              errorMessage2.setVisible(true)
//            }else{
//              val rs = statement.executeQuery("SELECT * FROM " + tableName + " WHERE price * count = " + max)
//            
//              outputTextArea.setText("")
//              outputTextArea.append("Max(price*count, all):\n")
//              outputTextArea.append("Product\t" + "Price\t" + "Count\t\n")
//  
//              //println("Max price * count:")
//              while(rs.next()){
//                val product = rs.getString("product")
//                val price = rs.getInt("price")
//                val count = rs.getInt("count")
//                outputTextArea.append(product + "\t" + price + "\t" + count + "\t\n");
//                //println(s"name=$product, price=$price, count=$count")
//             }
//            //println("\n")
//            }
//          }
//          finally{
//            connection.close()
//          }
//        }
//      })
//      
//      getOneMaxButton.addActionListener(new ActionListener{
//        override def actionPerformed(e: ActionEvent): Unit = {
//          val url = "jdbc:mysql://localhost:3306/scala_db"
//          val username = "root"
//          val password = "1234"
//          val tableName = "dop_products"
//
//          Class.forName("org.gjt.mm.mysql.Driver")
//
//          errorMessage.setVisible(false)
//          errorMessage2.setVisible(false)
//          errorMessage3.setVisible(false)
//          errorMessage4.setVisible(false)
//          errorMessage5.setVisible(false)
//          
//          val connection = DriverManager.getConnection(url, username, password)
//          try{
//            val statement = connection.createStatement()   
//            val rs = statement.executeQuery("SELECT * FROM " + tableName + " GROUP BY product HAVING price*count = (SELECT MAX(price*count) FROM " + tableName + ")")      
//
//            outputTextArea.append("Max(price*count, one):\n")
//            outputTextArea.append("Product\t" + "Price\t" + "Count\t\n")
//            outputTextArea.setText("")
//
//            rs.next()
//            val product = rs.getString("product")
//            val price = rs.getInt("price")
//            val count = rs.getInt("count")
//            outputTextArea.append(product + "\t" + price + "\t" + count + "\t\n");
//          }
//          finally{
//            connection.close()
//          }
//        }
//      })
//      
//      averageByButton.addActionListener(new ActionListener{
//        override def actionPerformed(e: ActionEvent): Unit = {
//          val url = "jdbc:mysql://localhost:3306/scala_db"
//          val username = "root"
//          val password = "1234"
//          val tableName = "dop_products"
//
//          Class.forName("org.gjt.mm.mysql.Driver")
//
//          errorMessage.setVisible(false)
//          errorMessage2.setVisible(false)
//          errorMessage3.setVisible(false)
//          errorMessage4.setVisible(false)
//          errorMessage5.setVisible(false)
//          
//          val connection = DriverManager.getConnection(url, username, password)
//          try{
//            val statement = connection.createStatement()
//            val rs = statement.executeQuery("SELECT product, SUM(count) as fullCount, AVG(price) AS average FROM " + tableName + " GROUP BY product")
//            
//            outputTextArea.setText("")
//            outputTextArea.append("Product\t" + "Average price\t" + "Count\t\n")
//  
//            while(rs.next()){
//              val product = rs.getString("product")
//              val count = rs.getInt("fullCount")
//              val averagePrice = rs.getInt("average").toString()
//              outputTextArea.append(product + "\t" + averagePrice + "\t" + count + "\t\n")
//            }
//          }
//          finally{
//            connection.close()
//          }
//        }
//      })      
//           
//      sortButton.addActionListener(new ActionListener{
//        override def actionPerformed(e: ActionEvent): Unit = {
//          val url = "jdbc:mysql://localhost:3306/scala_db"
//          val username = "root"
//          val password = "1234"
//          val tableName = "dop_products"
//
//          Class.forName("org.gjt.mm.mysql.Driver")
//
//          errorMessage.setVisible(false)
//          errorMessage2.setVisible(false)
//          errorMessage3.setVisible(false)
//          errorMessage4.setVisible(false)
//          errorMessage5.setVisible(false)
//          
//          val connection = DriverManager.getConnection(url, username, password)
//          try{
//            val statement = connection.createStatement()
//            val filter = sortComboBox.getSelectedItem().toString().substring(2);
//            val rs = statement.executeQuery("SELECT * FROM " + tableName + " ORDER BY " + filter + " ASC")            
//            
//            var counter = 0
//            outputTextArea.setText("")
//            outputTextArea.setText("                    \"" + tableName + "\" (sorted)\n")
//            outputTextArea.append("Product\t" + "Price\t" + "Count\t\n")
//            while(rs.next()){
//              val product = rs.getString("product")
//              val price = rs.getInt("price")
//              val count = rs.getInt("count")
//              outputTextArea.append(product + "\t" + price + "\t" + count + "\t\n");
//              counter = counter + 1
//            }
//            if(counter == 0){
//              errorMessage2.setVisible(true)
//            }           
//          }
//          finally{
//            connection.close()
//          }
//        }
//      })      
//      
//      
//      frame.setLocationRelativeTo(null)
//      frame.setVisible(true)      
//    })
//  }
//}


























////task 7
//import scala.io.Source
//import java.io.PrintWriter
//
//object main {
//  def main(args: Array[String]): Unit = {
//    val fileName = "file.txt";
//    val writer = new PrintWriter(fileName)
//    writer.write("Hello! My dear friend")
//    writer.write("Hy! Amigo")
//    writer.close()
//    val reader = Source.fromFile(fileName);
//    for(line <- reader.getLines()){
//      print(line)
//    }
//    reader.close()
//    
//  }
//}

////task18
//import org.apache.commons.math3.optim.linear._
//  import org.apache.commons.math3.optim.linear.LinearConstraint
//  import java.util.ArrayList
//  import org.apache.commons.math3.optim.linear.Relationship
//  import org.apache.commons.math3.optim.PointValuePair
//  import org.apache.commons.math3.optim.nonlinear.scalar.GoalType
//  
//  object main {
//  	def main(args:Array[String]):Unit = {
//  		// create a constraint: 2x + 3y <= 4
//  		val coeffs: Array[Double] = Array(2.0, 3.0)
//  		val coeffs1: Array[Double] = Array(-1.0, 3.0)
//  		val coeffs2: Array[Double] = Array(1.0, 3.0) // задаются для целевой ф-ии
//  		val coeffs3: Array[Double] = Array(1.0, 2.0)
//  		val relationship: Relationship = Relationship.LEQ // задаёт отношения
//  		val relationship2: Relationship = Relationship.GEQ
//  		val relationship3: Relationship = Relationship.GEQ
//  		val value: Double = 4.0
//  		val value2: Double = 1.0
//  		val value3: Double = 4.0
//  		val objectiveFunction = new LinearObjectiveFunction(coeffs2, 0.0)
//  		val constraint: LinearConstraint = new LinearConstraint(coeffs, relationship, value)
//  		val constraint2: LinearConstraint = new LinearConstraint(coeffs1, relationship2, value2)
//  		val constraint3: LinearConstraint = new LinearConstraint(coeffs3, relationship3, value3)
//  
//  		// Solve the optimization
//  		val solver = new SimplexSolver() // симплекс-метод
//  
//  		val constraintsList2: java.util.List[LinearConstraint] = new ArrayList[LinearConstraint]()
//  		constraintsList2.add(constraint)
//  		constraintsList2.add(constraint2)
//  		constraintsList2.add(constraint3)
//  		val result: PointValuePair = solver.optimize(objectiveFunction, new LinearConstraintSet(constraintsList2), GoalType.MINIMIZE)  // указывается целевая функция, 																		      //линейные ограничения, тип целевой 																	     // функции - направлена на минимум
//   		// Print the solution
//  		println(s"Minimum value: ${result.getValue}") // это результат целевой функции, в итоге выводит это в точке оптимума
//  		println(s"Solution: ${result.getPoint.mkString(",")}") // значения переменных в точке оптимума
//  		println("good")
//  	}
//  }


////task19
//import org.apache.commons.math3.optim.linear._
//import org.apache.commons.math3.optim.linear.LinearConstraint
//import java.util.ArrayList
//import org.apache.commons.math3.optim.linear.Relationship
//import org.apache.commons.math3.optim.PointValuePair
//import org.apache.commons.math3.optim.nonlinear.scalar.GoalType
//import org.apache.commons.math3.stat.descriptive.{DescriptiveStatistics,SummaryStatistics}
//
//object main {
//  def main(args: Array[String]): Unit = {
//    val data = Array(1.0, 2.0, 3.0, 4.0, 5.0)
//    val stats1 = new DescriptiveStatistics()
//    data.foreach(stats1.addValue)
//    val mean = stats1.getMean()
//    val stdDev = stats1.getStandardDeviation
//    val stats2 = new SummaryStatistics()
//    data.foreach(stats2.addValue)
//    val mean2 = stats2.getMean()
//    val stdDev2 = stats2.getStandardDeviation
//    println(s"Mean1 = ${mean}, stdDev1 = ${stdDev}")
//    println(s"Mean2 = ${mean2}, stdDev2 = ${stdDev2}")
//  }
//}
   

////task20
////import java.sq;.{Connection, DriverManager, ResultSet}
//import java.io.FileInputStream
//import opennlp.tools.namefind.{NameFinderME, TokenNameFinderModel}
////import opennlp.tools.tokenize.*
//import opennlp.tools.util.Span
//
//object main {
//    def main(args:Array[String]): Unit = {
//        val tokenizerModelIn = new FileInputStream("en-token.bin")
//        val tokenizerModel = new opennlp.tools.tokenize.TokenizerModel(tokenizerModelIn)
//        val tokenizer = new opennlp.tools.tokenize.TokenizerME(tokenizerModel)
//        // Load NER model
//        val nerModelIn = new FileInputStream("en-ner-person.bin")
//        val nerModel = new TokenNameFinderModel(nerModelIn)
//        val ner = new NameFinderME(nerModel)
//
//  		  // Define some sample text
//        val text = "John Smith is a software engineer at Google."
//
//        // Tokenize the text
//        val tokens = tokenizer.tokenize(text)
//
//  		  // Find the named entities in the text
//        val spans = ner.find(tokens)
//
//        // Print the named entities and their types
//        for(span <- spans) 
//        {
//            val entityType = span.getType
//            val entity = tokens.slice(span.getStart, span.getEnd).mkString(" ")
//            println(s"$entityType: $entity")
//        }
//    }
//}

////task21
//import java.io.FileInputStream
//import opennlp.tools.namefind.{NameFinderME, TokenNameFinderModel}
////import opennlp.tools.tokenize.*
//import opennlp.tools.util.Span
//
//object main {
//
//  def main(args: Array[String]): Unit = {
//    print("Input text:")
//    val text: String = scala.io.StdIn.readLine()
//
//    val tokenizerModelIn = new FileInputStream("en-token.bin")
//    val tokenizerModel = new opennlp.tools.tokenize.TokenizerModel(tokenizerModelIn)
//    val tokenizer = new opennlp.tools.tokenize.TokenizerME(tokenizerModel)
//
//    // text = "Rayony kvartyaly zhilie massivy."
//    val tokens = tokenizer.tokenize(text)               // разделение на токены
//    for(token <- tokens) {
//      println(s"$token")
//    }
//  }
//}


////task 22
//import java.io.FileInputStream
//import opennlp.tools.namefind.{NameFinderME, TokenNameFinderModel}
////import opennlp.tools.tokenize.*
//import opennlp.tools.util.Span
//
//object main {
//    def main(args:Array[String]): Unit = {
//        // Модель токенизатора
//        val tokenizerModelIn = new FileInputStream("en-token.bin")
//        val tokenizerModel = new opennlp.tools.tokenize.TokenizerModel(tokenizerModelIn)
//        val tokenizer = new opennlp.tools.tokenize.TokenizerME(tokenizerModel)
//
//        // Модель для обнаружения имен в тексте
//        val nerModelIn = new FileInputStream("en-ner-person.bin")
//        val nerModel = new TokenNameFinderModel(nerModelIn)
//        val ner = new NameFinderME(nerModel)
//
//  		  // В этом тексте присутствуют 4 имени
//        val text = "John is supposed to marry Monica, but Jason Welsh is against this marriage because Fred thinks it's stupid"
//
//        // Деление текста на токены
//        val tokens = tokenizer.tokenize(text)
//        println(s"Tkens count: ${tokens.length}")
//
//  		  // Поиск имен в тексте
//        val spans = ner.find(tokens)
//        println(s"Persons count: ${spans.length}")
//
//        // Вывод имен
//        for(span <- spans)
//        {
//            val entityType = span.getType
//            val name = tokens.slice(span.getStart, span.getEnd).mkString(" ")
//            println(s"$entityType: $name")
//        }
//    }
//} 


//task24
//import java.awt.image.BufferedImage
//import java.io.File
//import javax.imageio.ImageIO
//import scala.util.Random
//import org.apache.commons.math3.stat.descriptive.{DescriptiveStatistics, SummaryStatistics}
//  
//  object main {
//  	def main(args:Array[String]): Unit = {
//   		val imagePath = "one.jpg"
//     	// Load image using ImageIO
//      val image: BufferedImage = ImageIO.read(new File(imagePath))
//  
//      // Get the width and height of the image  // Читаем картинку в массив пикселей, после этого случайными образом отбираем 1000 пикселей. 
//  	 	val width = image.getWidth 		 
//      val height = image.getHeight
//  
//      // Get the array of pixels from the image
//      val pixels = Array.ofDim[Int](width * height)
//  	 	image.getRGB(0, 0, width, height, pixels, 0, width)
//  	 	for(i <- 0 until 10){
//  	 	  println(pixels(i))
//  	 	}
//    }
//  }

////task25
//import java.awt.image.BufferedImage
//import java.io.File
//import javax.imageio.ImageIO
//import scala.util.Random
//import org.apache.commons.math3.stat.descriptive.{DescriptiveStatistics, SummaryStatistics}
//  
//  object main {
//  	def main(args:Array[String]): Unit = {
//   	val imagePath = "one.jpg"
//    // Load image using ImageIO
//    val image: BufferedImage = ImageIO.read(new File(imagePath))
//  
//    // Get the width and height of the image  // Читаем картинку в массив пикселей, после этого случайными образом отбираем 1000 пикселей. 
//  	val width = image.getWidth 		 
//    val height = image.getHeight
//  
//    // Get the array of pixels from the image
//    val pixels = Array.ofDim[Int](width * height)
//  	image.getRGB(0, 0, width, height, pixels, 0, width)
//    val count = 1000
//    var numbers = List[Double]() // Тут случайно выбранные пиксели хранятся в списке
//    val random = new Random()
//  	for(i <- 0 until count) {
//      var j = random.nextInt(width * height)
//      numbers = math.abs(pixels(j)) :: numbers // Номера пикселей, пиксель j мы будем добавлять в список numbers
//  	}
//    		
//   	val stats1 = new DescriptiveStatistics() // Находим здесь среднее значение и стандартное отклонение  и дальше выводим
//    numbers.foreach(stats1.addValue) 	// здесь среднее значение и стандартное отклонение 
//    val mean = stats1.getMean()		//
//  	val stdDev = math.sqrt(stats1.getStandardDeviation()) //
//  
//    println(s"Mean value: ${mean}") //  и дальше 
//    println(s"Stdev: ${stdDev}")   // выводим
//   }
//  }


////task26
//import java.awt.image.BufferedImage
//import java.io.File 
//import javax.imageio.ImageIO
//import scala.util.Random
//import org.apache.commons.math3.stat.descriptive.{DescriptiveStatistics, SummaryStatistics}
//  
//  object main {
//   def main(args:Array[String]): Unit = {
//      val imagePath = "one.jpg"
//      // Load the image using ImageIO
//  
//      var image: BufferedImage = ImageIO.read(new File(imagePath))
//    // Get the width and height of image
//      val width = image.getWidth
//      val height = image.getHeight
//      // Get the array of pixels from the image
//    val pixels = Array.ofDim[Int](width * height)
//      image getRGB(0, 0, width, height, pixels, 0, width)
//      val count = 1000
//     var numbers = List[Double]()
//     var nomers = List[Int]()
//     val random = new Random()
//  
//     for(i <- 0 until count) {
//       var j = random.nextInt(width * height)
//        nomers = j :: nomers
//      numbers = math.abs(pixels(j)) :: numbers
//      }
//    
//      val stats1 = new DescriptiveStatistics()
//      numbers.foreach(stats1.addValue)
//     val mean = stats1.getMean()
//      val stdDev = math.sqrt(stats1.getStandardDeviation)
//      println(s"Mean-1 value: ${mean}")
//      println(s"Stdev-1: ${stdDev}")
//      
//    val imagePath2 = "two.jpg"
//      var image2: BufferedImage = ImageIO.read(new File(imagePath2))
//      val pixels2 = Array.ofDim[Int](width * height)
//      image2.getRGB(0, 0, width, height, pixels2, 0, width)
//  
//     var numbers2 = List[Double]()
//      for (i <- 0 until count) {
//        numbers2 = math.abs(pixels2(nomers(i))) :: numbers2
//     }
//         
//      val stats2 = new DescriptiveStatistics()
//      numbers2.foreach(stats2.addValue)
//    val mean2 = stats2.getMean()
//    val stdDev2 = math.sqrt(stats2.getStandardDeviation)
//     println(s"Mean-2 value: ${mean2}") //  и дальше 
//    println(s"Stdev-2: ${stdDev2}")   // выводим
//   }
//  }


