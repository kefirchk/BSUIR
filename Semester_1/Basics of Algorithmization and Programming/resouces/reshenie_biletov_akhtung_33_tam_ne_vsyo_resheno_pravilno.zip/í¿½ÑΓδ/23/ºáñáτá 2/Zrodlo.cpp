//������ 23 ������ 2
#include <iostream>
#include <Windows.h>


void reverse(char*s, int poz1, int poz2)
{
	if (poz1 >= poz2)
		return;
	char t = s[poz1];
	s[poz1] = s[poz2];
	s[poz2] = t;
	reverse(s, poz1 + 1, poz2 - 1);
}
int ch4let(char s)
{
	if (s >= 'A' && s <= 'Z' || s <= 'z' && s >= 'a')
		return 1;
	else
		return 0;
}
void chWrd(char* s)
{
	int i;
	for (i = 0; !ch4let(s[i]) && s[i] != 0; i++);
	if (s[i] == '\0') 
		return;
	int j, jj;
	for (j = 0; s[j] != '\0'; j++);
	for (jj = j; jj > 0; jj--)
		if (ch4let(s[jj]) && !ch4let(s[jj - 1]))
			break;
	if (jj == i)
		return;
	for (; !ch4let(s[j]); j--);
	reverse(s, i, j);
	int ii = i;
	for (; ch4let(s[ii + 1]); ii++);
	for (jj = j; ch4let(s[jj - 1]); jj--);
	reverse(s, i, ii);
	reverse(s, jj, j);
	ii++;
	jj--;
	reverse(s, ii, jj);
	return;
}
int main()
{
	char*s;
	if (!(s = (char*)malloc(sizeof(char))))
		return 0;
	int i = 0;
	while ((s[i] = getchar()) != '\n')
		if (!(s = (char*)realloc(s, sizeof(char)*(++i + 1))))
		{
			free(s);
			return 0;
		}
	s[i] = '\0';
	chWrd(s);
	puts(s);
	system("pause");
	return 0;
}