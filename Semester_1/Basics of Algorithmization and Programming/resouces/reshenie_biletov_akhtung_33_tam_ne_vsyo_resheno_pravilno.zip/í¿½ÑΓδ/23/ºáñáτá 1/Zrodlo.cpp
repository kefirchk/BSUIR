//����� 23 ������ 1
#include <iostream>
#include <Windows.h>

float maxsum(int kl, float *m1, int n1, ...)
{
	if (kl == 0) return 0;
	void **p, *pp;
	p = (void**)&m1;
	pp = &n1;
	float sum = 0, max = 0;
	for (int i = 0; i < n1; i++)
		max += m1[i];
	printf("\nsum of 1st massive is %f\n", max);
	for (int i = 1; i < kl; i++)
	{
		pp = (int*)pp + 1;
		p = (void**)pp;
		pp = (float**)pp + 1;
		for (int j = 0; j < *(int*)pp; j++)
			sum += *(*(float**)p + j);
		printf("sum of %d massive is %f\n", i + 1, sum);
		sum > max ? max = sum : sum = sum;
		sum = 0;
	}
	return max;
}
int main()
{
	float m1[] = { 1,2,3,4,5 },
		m2[] = { 1,2,4,7,8,9 },
		m3[] = { 1,5,9,9,6,2 },
		m4[] = { 5,11,1,5,7 };
	printf("max sum is %f", maxsum(4, m1, 5, m2, 6, m3, 6, m4, 5));
	system("pause");
	return 0;
}