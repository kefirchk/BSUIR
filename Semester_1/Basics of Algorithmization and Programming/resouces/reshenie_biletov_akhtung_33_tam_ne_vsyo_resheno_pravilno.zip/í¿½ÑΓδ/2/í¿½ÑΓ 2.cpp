//����� 2
#include <iostream>
#include <locale.h>
#include <Windows.h>

int ch4let(char s)
{
	if (s >= 'a' && s <= 'z' || s >= 'A' && s <= 'Z')
		return 1;
	else
		return 0;
}
int lenword(char*s, int poz)
{
	int len = 0;
	for (int i = poz; ch4let(s[i]); i++)
		len++;
	return len;
}
void find(char**s, int kl)
{
	int poz1=0, poz2=0;
	for (int i = 0; i < kl; i++)
	{
		for (int j=0;s[i][j]!='\0';j++)
			if (ch4let(s[i][j]))
			{
				poz1 = i;
				poz2 = j;
				i = kl;
				break;
			}
	}
	for (int i = 0; i < kl; i++)
		for (int j = 0; s[i][j] != '\0'; j++)
			if (ch4let(s[i][j]))
			{
				if (lenword(s[poz1], poz2) < lenword(s[i], j))
				{
					poz1 = i;
					poz2 = j;
				}
				j += lenword(s[i], j);
				j--;
			}
	for (int i = poz2; i < poz2 + lenword(s[poz1], poz2); i++)
		printf("%c", s[poz1][i]);
	return;
}
char* input(char**s, int i)
{
	char *st;
	if (!(st = (char*)malloc(sizeof(char))))
	{
		for (int j = 0; j < i; i++)
			free(s[i]);
		free(s);
	}
	int j = 0;
	for (; (st[j] = getchar()) != '\n'; j++)
		if (!(st = (char*)realloc(st, (j + 2) * sizeof(char))))
		{
			for (int j = 0; j < i; i++)
				free(s[i]);
			free(s);
		}
	st[j] = '\0';
	return st;
}
int main()
{
	int n, m, k;
	scanf_s("%d%d%d", &n, &m, &k);
	int **ms1, **ms2;
	if (!(ms1 = (int**)malloc(n * sizeof(int*))))
		return 0;
	if (!(ms2 = (int**)malloc(m * sizeof(int*))))
		return 0;
	for (int i = 0; i < n; i++)
	{
		if (!(ms1[i] = (int*)malloc(m * sizeof(int))))
		{
			for (int j = 0; j <= i; j++)
				free(ms1[i]);
			free(ms1);
			return 0;
		}
		for (int j = 0; j < m; j++)
			scanf_s("%d", &ms1[i][j]);
	}
	for (int i = 0; i < m; i++)
	{
		if (!(ms2[i] = (int*)malloc(k * sizeof(int))))
		{
			for (int j = 0; j <= i; j++)
				free(ms2[i]);
			free(ms2);
			for (int j = 0; j <= i; j++)
				free(ms1[i]);
			free(ms1);
			return 0;
		}
		for (int j = 0; j < k; j++)
			scanf_s("%d", &ms2[i][j]);
	}
	//
	int **ms3;
	if (!(ms3 = (int**)malloc(sizeof(int*)*n)))
		return 0;
	for (int i = 0; i < n; i++)
		if (!(ms3[i] = (int*)malloc(k * sizeof(int))))
			return 0;
	int i = 0, j = 0;
	do
	{
		do 
		{
			ms3[i][j] = 0;
			for (int jj = 0; jj < m; jj++)
				ms3[i][j] += ms1[i][jj] * ms2[jj][j];
			j++;
		} while (j != k);
		j = 0;
		i++;
	} while (i != n);
	//
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
			printf("%4d", ms1[i][j]);
		printf("\n");
	}
	puts("\n\n");
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < k; j++)
			printf("%4d", ms2[i][j]);
		printf("\n");
	}
	puts("\n\n");
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < k; j++)
			printf("%4d", ms3[i][j]);
		printf("\n");
	}
	for (int i = 0; i < n; i++)
		free(ms3[i]);
	free(ms3);
	for (int i = 0; i < n; i++)
		free(ms1[i]);
	free(ms1);
	for (int i = 0; i < m; i++)
		free(ms2[i]);
	free(ms2);
	system("pause");
	////
	char**s;
	int kl;
	scanf_s("%d", &kl);
	rewind(stdin);
	if (!(s = (char**)malloc(kl * sizeof(char*))))
		return 0;
	for (int i = 0; i < kl; i++)
	{
		s[i] = input(s, i);
		if (!s) 
			return 0;
	}
	//
	find(s, kl);
	//
	for (int i = 0; i < n; i++)
		free(s[i]);
	free(s);
	puts("");
	system("pause");
	return 0;
}