//����� 21 ������ 1
#include <iostream>
#include <Windows.h>


void sort(float* ms, int n)
{
	for (int i = 1; i < n; i++)
	{
		int j = i - 1;
		float k = ms[i];
		while (j >= 0 && ms[j] < k)
			ms[j-- + 1] = ms[j];
		ms[j + 1] = k;
	}
}
void sort(float** mt, int n, int m)
{
	for (int i = 0; i < n; i++)
	{
		if (mt[i][0] - (int)mt[i][0] == 0 && (int)mt[i][0] % 2 == 1)
			sort(mt[i], m);
	}
}
int main()
{
	float **mt;
	int n, m;
	scanf_s("%d%d", &n, &m);
	if (!(mt = (float**)malloc(sizeof(float*)*n)))
		return 0;
	for (int i = 0; i < n; i++)
	{
		if (!(*(mt + i) = (float*)malloc(sizeof(float)*m)))
		{
			for (i--; i >= 0; i--)
				free(*(mt + i));
			free(mt);
			return 0;
		}
		for (int j = 0; j < m; j++)
		{
			printf("mt[%d][%d] = ", i, j);
			rewind(stdin);
			scanf_s("%f", *(mt + i) + j);
		}
	}
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
			printf("%6.1f", *(*(mt + i) + j));
		printf("\n");
	}
	//
	sort(mt, n, m);
	//
	puts("\n");
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
			printf("%6.1f", *(*(mt + i) + j));
		printf("\n");
	}
	for (int i = 0; i < n; i++)
		free(mt[i]);
	free(mt);
	system("pause");
	return 0;
}