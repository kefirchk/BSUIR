//����� 21 ������ 2
#include <iostream>
#include <Windows.h>


int ch4let(char s)
{
	if (s >= 'A' && s <= 'Z' || s >= 'a' && s <= 'z')
		return 1;
	else
		return 0;
}
void reverse(char* s, int poz1, int poz2)
{
	if (poz1 >= poz2)
		return;
	char t = s[poz1];
	s[poz1] = s[poz2];
	s[poz2] = t;
	reverse(s, poz1 + 1, poz2 - 1);
	return;
}
int numOfWords(char* s)
{
	int kl = 0;
	if (ch4let(s[0]))
		kl++;
	for (int i = 1; s[i] != '\0'; i++)
		if (ch4let(s[i]) & !ch4let(s[i - 1]))
			kl++;
	return kl;
}
int pozOf(char* s, int num)
{
	if (num <= 0 || num > numOfWords(s))
		return -1;
	int kl = 0;
	if (ch4let(s[0]))
		kl++;
	if (num == kl)
		return 0;
	int i;
	for (i = 1; s[i] != '\0'; i++)
	{
		if (ch4let(s[i]) & !ch4let(s[i - 1]))
			kl++;
		if (kl == num)
			return i;
	}
	return -1;
}
int longOf(char* s, int num)
{
	int i = pozOf(s, num);
	for (; ch4let(s[i]); i++);
	return i - pozOf(s, num);
}
void chMinWrd(char* s)
{
	if (!numOfWords(s))
		return;
	int min = 1;
	for (int i = 1; i <= numOfWords(s); i++)
	{
		if (longOf(s, min) > longOf(s, i))
			min = i;
	}
	if (min == numOfWords(s))
		return;
	reverse(s, pozOf(s, min), pozOf(s, min + 1) + longOf(s, min + 1) - 1);
	reverse(s, pozOf(s, min), pozOf(s, min) + longOf(s, min) - 1);
	reverse(s, pozOf(s, min + 1), pozOf(s, min + 1) + longOf(s, min + 1) - 1);
	reverse(s, pozOf(s, min) + longOf(s, min), pozOf(s, min + 1) - 1);
	return;
}
int main()
{
	char *s;
	if (!(s = (char*)malloc(sizeof(char))))
		return 0;
	int i = 0;
	while ((s[i] = getchar()) != '\n')
		if (!(s = (char*)realloc(s, sizeof(char)*(++i + 1))))
		{
			free(s);
			return 0;
		}
	s[i] = '\0';
	chMinWrd(s);
	puts(s);
	free(s);
	system("pause");
	return 0;
}