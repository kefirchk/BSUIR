//����� 24 ������ 2
#include <iostream>
#include <Windows.h>


int main()
{
	char *s;
	if (!(s = (char*)malloc(sizeof(char))))
		return 0;
	int i = 0;
	while ((s[i] = getchar()) != '\n')
		if (!(s = (char*)realloc(s, sizeof(char)*(++i + 1))))
		{
			free(s);
			return 0;
		}
	s[i] = '\0';
	int poz = -1;
	while (poz >= i || poz < 0)
	{
		rewind(stdin);
		scanf_s("%d", &poz);
	}
	for (; poz < i; poz++)
		s[poz] = s[poz + 1];
	if (!(s = (char*)realloc(s, (--i + 1) * sizeof(char))))
	{
		free(s);
		return 0;
	}
	puts(s);
	system("pause");
	return 0;
}