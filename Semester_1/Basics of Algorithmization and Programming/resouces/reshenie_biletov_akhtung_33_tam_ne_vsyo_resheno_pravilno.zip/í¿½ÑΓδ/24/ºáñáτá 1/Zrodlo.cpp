//����� 24 ������ 1
#include <iostream>
#include <Windows.h>


void transpon(int**mt, int n, int i, int j)
{
	if (j < 0)
		return;
	int t = mt[i][j];
	mt[i][j] = mt[n - 1 - j][n - 1 - i];
	mt[n - 1 - j][n - 1 - i] = t;
	transpon(mt, n, i, j - 1);
}
void transpon(int** mt, int n)
{
	static int i = 0;
	if (i == n)
	{
		i = 0;
		return;
	}
	transpon(mt, n, i, n - 2 - i);
	i++;
	transpon(mt, n);
}
int main()
{
	int **mt, n;
	scanf_s("%d", &n);
	if (!(mt = (int**)malloc(sizeof(int*)*n)))
		return 0;
	for (int i = 0; i < n; i++)
	{
		if (!(mt[i] = (int*)malloc(sizeof(int)*n)))
		{
			for (i--; i >= 0; i--)
				free(mt[i]);
			free(mt);
			return 0;
		}
		for (int j = 0; j < n; j++)
		{
			printf("mt[%d][%d] = ", i, j);
			scanf_s("%d", *(mt + i) + j);
		}	
	}	
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
			printf("%3d", *(*(mt + i) + j));
		printf("\n");
	}
	puts("");
	transpon(mt, n);
	for (int i = 0; i < n; i++)
		{
			for (int j = 0; j < n; j++)
				printf("%3d", *(*(mt + i) + j));
			printf("\n");
		}
		puts("");
	system("pause");
	return 0;
}