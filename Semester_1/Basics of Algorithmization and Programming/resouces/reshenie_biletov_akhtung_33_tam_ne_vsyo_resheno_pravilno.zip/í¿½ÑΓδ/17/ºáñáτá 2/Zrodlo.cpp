//����� 17 ������ 2
#include <iostream>
#include <Windows.h>


int ch4let(char s)
{
	if (s >= 'A' && s <= 'Z' || s >= 'a' && s <= 'z')
		return 1;
	else
		return 0;
}
int ch4bigLet(char s)
{
	if (!ch4let(s))
		return 0;
	else
		if (s >= 'A' && s <= 'Z')
			return  'A' - 1;
		else
			return 'a' - 1;
}
void sort(char**s, int poz1, int poz2, int let)
{
	if (poz1 == poz2)
		return;
	for (int i = poz1 + 1; i <= poz2; i++)
	{
		int j = i - 1;
		char *k = s[i];
		while (j >= poz1 && k[let] - ch4bigLet(k[let]) < s[j][let] - ch4bigLet(s[j][let]))
			s[j-- + 1] = s[j];
		s[j + 1] = k;
	}
	int i = poz1;
	while (i < poz2)
	{
		int j = i;
		for (;; i++)
		{
			if (s[i][let] != s[j][let])
			{
				i--;
				break;
			}
			if (!s[i][let])
				return;
			if (i == poz2 - 1 && s[i][let] == s[poz2][let])
			{
				i++;
				break;
			}

		}
		sort(s, j, i, let + 1);
		i++;
	}
		
}
int main(int argv, char **argc)
{
	for (int i = 1; i < argv; i++)
		puts(argc[i]);
	puts("\n\n");
	//
	sort(argc, 1, argv - 1, 0);
	//
	for (int i = 1; i < argv; i++)
		puts(argc[i]);
	puts("\n\n");
	system("pause");
	return 0;
}