//����� 26 ������ 2
#include <iostream>
#include <Windows.h>


void shift(char* s, int i, int j)
{
	if (i == j)
		return;
	char t = s[i];
	s[i] = s[i + 1];
	s[i + 1] = t;
	shift(s, i + 1, j);
}
char *input()
{
	char *s;
	if (!(s = (char*)malloc(sizeof(char))))
		return nullptr;
	int i = 0;
	while ((s[i] = getchar()) != '\n')
	{
		if (!(s = (char*)realloc(s, (++i + 1) * sizeof(char))))
		{
			free(s);
			return nullptr;
		}
	}
	s[i] = '\0';
	return s;
}
int main()
{
	char *s, *ss;
	if (!(s = input()))
		return 0;
	if (!(ss = input()))
	{
		free(s);
		return 0;
	}
	int poz;
	scanf_s("%d", &poz);
	//
	int i = 0, j = 0;
	for (; s[i] != '\0'; i++);
	for (; ss[j] != '\0'; j++);
	if (!(s = (char*)realloc(s, sizeof(char)*(i + j))))
	{
		free(s);
		free(ss);
		return 0;
	}
	for (int ii = i, jj = i + j; ii >= poz; ii--, jj--)
		shift(s, ii, jj);
	for (int ii = poz; ii < poz + j; ii++)
		s[ii] = ss[ii - poz];
	puts(s);
	//
	system("pause");
	return 0;
}