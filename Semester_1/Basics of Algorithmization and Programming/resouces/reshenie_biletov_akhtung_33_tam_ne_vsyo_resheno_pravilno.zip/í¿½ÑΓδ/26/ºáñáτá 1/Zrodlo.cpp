//����� 26 ������ 1
#include <iostream>
#include <Windows.h>

void transp(int** mt, int n, int i, int j)
{
	if (j == n)
		return;
	int t = mt[i][j];
	mt[i][j] = mt[j][i];
	mt[j][i] = t;
	transp(mt, n, i, j + 1);
}
void transp(int** mt, int n)
{
	static int i = 0;
	if (i == n)
	{
		i = 0;
		return;
	}
	transp(mt, n, i, i + 1);
	i++;
	transp(mt, n);
}
int main()
{
	int n, **mt;
	scanf_s("%d", &n);
	if (!(mt = (int**)malloc(sizeof(int*)*n)))
		return 0;
	for (int i = 0; i < n; i++)
	{
		if (!(mt[i] = (int*)malloc(sizeof(int)*n)))
		{
			i--;
			for (; i >= 0; i--)
				free(mt[i]);
			free(mt);
			return 0;
		}
		for (int j = 0; j < n; j++)
			scanf_s("%d", *(mt + i) + j);
	}
	system("cls");
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
			printf("%3d", mt[i][j]);
		printf("\n");
	}
	//
	transp(mt, n);
	//
	puts("\n\n");
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
			printf("%3d", mt[i][j]);
		printf("\n");
	}
	system("pause");
	return 0;
}