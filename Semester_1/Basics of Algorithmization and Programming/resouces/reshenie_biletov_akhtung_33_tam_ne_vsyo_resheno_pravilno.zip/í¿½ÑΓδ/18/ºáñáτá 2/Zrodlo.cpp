//����� 18 ������ 2
#include <iostream>
#include <Windows.h>




int ch4let(char s)
{
	if (s >= 'A' && s <= 'Z' || s >= 'a' && s <= 'z')
		return 1;
	else
		return 0;
}
int ch4bigLet(char s)
{
	if (!ch4let(s))
		return 0;
	else
		if (s >= 'a' && s <= 'z')
			return 'a' + 1;
		else
			return 'A' + 1;
}
void sort(char **s, int poz1, int poz2, int let)
{
	if (poz1 == poz2)
		return;
	for (int i = poz1 + 1; i <= poz2; i++)
	{
		int j = i - 1;
		char* k = s[i];
		while (j >= poz1 && k[let] - ch4bigLet(k[let]) < s[j][let] - ch4bigLet(s[j][let]))
			s[j-- + 1] = s[j];
		s[j + 1] = k;
	}
	int i = poz1;
	while (i < poz2)
	{
		int j = i;
		for (;; i++)
		{
			if (s[i][let] - ch4bigLet(s[i][let]) != s[j][let] - ch4bigLet(s[j][let]))
			{
				i--;
				break;
			}
			if (!s[i][let])
				return;
			if (i == poz2 - 1 && s[i][let] == s[poz2][let])
			{
				i++;
				break;
			}
		}
		sort(s, j, i, let + 1);
		i++;
	}
}
char* input()
{
	rewind(stdin);
	char *s;
	if (!(s = (char*)malloc(sizeof(char))))
		return 0;
	int i = 0;
	while (ch4let(s[i] = getchar()))
		if (!(s = (char*)realloc(s, (++i + 1) * sizeof(char))))
		{
			free(s);
			return 0;
		}
	s[i] = '\0';
	if (i == 0)
	{
		free(s);
		return input();
	}
	return s;
}
int main()
{
	char **s;
	int n;
	scanf_s("%d", &n);
	if (!(s = (char**)malloc(sizeof(char*)*n)))
		return 0;
	for (int i = 0; i < n; i++)
		if (!(s[i] = input()))
		{
			for (i--; i >= 0; i--)
				free(s[i]);
			free(s);
			return 0;
		}
	system("cls");
	for (int i = 0; i < n; i++)
		puts(s[i]);
	//
	sort(s, 0, n - 1, 0);
	//
	puts("\n\n");
	for (int i = 0; i < n; i++)
		puts(s[i]);
	for (int i = 0; i < n; i++)
		free(s[i]);
	free(s);
	system("pause");
	return 0;
