//����� 18 ������ 1
#include <iostream>
#include <Windows.h>


void sort(int* mt, int poz1, int poz2)
{

	poz1++;
	poz2--;
	int b = poz2;
	do
	{	
		for (int i = poz2; i >= poz1; i--)
			if (mt[i] > mt[i - 1])
			{
				int t = mt[i];
				mt[i] = mt[i - 1];
				mt[i - 1] = t;
				b = i;
			}
		poz1 = b + 1;
		for (int i = poz1; i <= poz2; i++)
			if (mt[i] > mt[i - 1])
			{
				int t = mt[i];
				mt[i] = mt[i - 1];
				mt[i - 1] = t;
				b = i;
			}
		poz2 = b - 1;
	
	} while (poz1 <= poz2);
}
void vyvod(int** mt, int n, int m)
{
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
			printf("%4d", mt[i][j]);
		printf("\n");
	}
}
int main()
{
	int** mt, n;
	scanf_s("%d", &n);
	if (!(mt = (int**)malloc(sizeof(int*)*n)))
		return 0;
	for (int i = 0; i < n; i++)
	{
		if (!(*(mt + i) = (int*)malloc(sizeof(int)*n)))
		{
			for (i--; i >= 0; i--)
				free(*(mt + i));
			free(mt);
			return 0;
		}
		for (int j = 0; j < n; j++)
		{
			printf("mt[%d][%d] = ", i, j);
			scanf_s("%d", *(mt + i) + j);
		}
	}
	vyvod(mt, n, n);
	puts("\n");
	//
	int i;
	scanf_s("%d", &i);
	sort(mt[i], 0, i);
	//shaker(mt[i], i);
	//
	puts("\n");
	vyvod(mt, n, n);
	for (int i = 0; i < n; i++)
	{
		free(mt[i]);
	}
	free(mt);
	system("pause");
	return 0;
}