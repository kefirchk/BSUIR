//����� 6
#include <iostream>
#include <Windows.h>


int ch4let(char s)
{
	if (s >= 'a' && s <= 'z' || s >= 'A' && s <= 'Z')
		return 1;
	else
		return 0;
}
int comparestr(char*s1, char*s2)
{
	static int i = 0, j = 0;
	if (!i && !j)
	{
		for (; s1[i] != '\0'; i++)
			if (ch4let(s1[i]))
				break;
		for (; s2[j] != '\0'; j++)
			if (ch4let(s2[j]))
				break;
	}
	if (s1[i] == s2[j])
	{
		if (s1[i] == '\0')
		{
			i = 0;
			j = 0;
			return 0;
		}
		i++;
		j++;
		return comparestr(s1, s2);
	}
	if (s1[i] < s2[j])
	{
		i = 0;
		j = 0;
		return 1;
	}
	else
	{
		i = 0;
		j = 0;
		return 0;
	}
		
}
void sort(char** s, int c)
{
	for (int i = 2; i < c; i++)
	{
		int j = i - 1;
		char *k;
		k = s[i];
		while (j >= 1 && comparestr(k, s[j]))
			s[j-- + 1] = s[j];
		s[j + 1] = k;
	}
}
void swap(int &n, int &m)
{
	int j = m;
	m = n;
	n = j;
}
void transpon(int** mt, int n)
{
	static int i = 0, j = 0;
	if (j < i)
	{
		swap(mt[i][j], mt[j][i]);
		j++;
		transpon(mt, n);
		return;
	}
	if (j == i && j != n - 1)
	{
		i++;
		j = 0;
		transpon(mt, n);
		return;
	}

}
int main(int argc, char** argv)
{
	int **mt, n;
	scanf_s("%d", &n);
	if (!(mt = (int**)malloc(n * sizeof(int*))))
		return 0;
	for (int i = 0; i < n; i++)
	{
		if (!(mt[i] = (int*)malloc(n * sizeof(int))))
		{
			i--;
			for (; i >= 0; i--)
				free(mt[i]);
			free(mt);
			return 0;
		}
		for (int j = 0; j < n; j++)
			scanf_s("%d", *(mt + i) + j);
	}
	system("cls");
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
			printf("%3d", mt[i][j]);
		printf("\n");
	}
	//
	transpon(mt, n);
	puts("\n\n");
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
			printf("%3d", mt[i][j]);
		printf("\n");
	}
	system("pause");
	////
	sort(argv, argc);
	for (int i = 1; i < argc; i++)
		puts(argv[i]);
	system("pause");
	return 0;
}