//����� 30 ������ 1
#include <iostream>
#include <Windows.h>


int main()
{
	int n, m;
	scanf_s("%d%d", &n, &m);
	int *mt1, *mt2;
	if (!(mt1 = (int*)malloc(sizeof(int)*n)))
		return 0;
	if (!(mt2 = (int*)malloc(sizeof(int)*m)))
	{
		free(mt1);
		return 0;
	}
	for (int i = 0; i < n; i++)
	{
		printf("mt1[%d] = ", i + 1);
		while (!scanf_s("%d", mt1 + i))
		{
			printf("input one more time: ");
			rewind(stdin);
		}
	}
	for (int i = 0; i < m; i++)
	{
		printf("mt2[%d] = ", i + 1);
		while (!scanf_s("%d", mt2 + i))
		{
			printf("input one more time: ");
			rewind(stdin);
		}
	}
	system("cls");
	printf("mt1:\n");
	for (int i = 0; i < n; i++)
		printf(" %d", *(mt1 + i));
	printf("\nmt2:\n");
	for (int i = 0; i < m; i++)
		printf(" %d", *(mt2 + i));
	//
	int *mt3;
	if (!(mt3 = (int*)malloc(sizeof(int)*(m + n))))
	{
		free(mt1);
		free(mt2);
		return 0;
	}
	for (int i1 = n - 1, i2 = m - 1, i3 = 0; i3 < m + n; i3++)
	{
		if (i1 < 0)
			mt3[i3] = mt2[i2--];
		else
			if (i2 < 0)
				mt3[i3] = mt1[i1--];
			else
				if (mt1[i1] < mt2[i2])
					mt3[i3] = mt1[i1--];
				else
					mt3[i3] = mt2[i2--];
	}
	//
	printf("\nmt3:\n");
	for (int i = 0; i < m + n; i++)
		printf(" %d", *(mt3 + i));
	free(mt1);
	free(mt2);
	free(mt3);
	system("pause");
	return 0;
}