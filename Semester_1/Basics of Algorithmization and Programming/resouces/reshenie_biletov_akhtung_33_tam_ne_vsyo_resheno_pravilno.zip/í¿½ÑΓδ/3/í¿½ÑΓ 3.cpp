//����� 3
#include <iostream>
#include <Windows.h>

int ch4let(char s)
{
	if (s >= 'a' && s <= 'z' || s >= 'A' && s <= 'Z')
		return 1;
	else
		return 0;
}
int endword(char *p, int num)
{
	static int i = 0, numm = 0;
	for (; !ch4let(p[i]); i++);
	for (; ch4let(p[i]); i++);
	numm++;
	if (numm != num)
		return endword(p, num);
	numm = 0;
	int ii = i;
	i = 0;
	return ii - 1;
}
int searchword(char*p,  int num)
{
	static int i = 0, numm = 0;
	for (; !ch4let(p[i]); i++);
	numm++;
	if (numm != num)
	{
		for (; ch4let(p[i]); i++);
		return searchword(p, num);
	}
	numm = 0;
	int ii = i;
	i = 0;
	return ii;
}
void swap(char&c1, char&c2)
{
	char t = c1;
	c1 = c2;
	c2 = t;
}
void reverse(char *p, int poz1, int poz2)
{	
	if (poz1 < poz2)
	{
		swap(p[poz1], p[poz2]);
		reverse(p, poz1 + 1, poz2 - 1);
	}
}
void swap(char *p)
{
	reverse(p, searchword(p, 1), endword(p, 2));
	reverse(p, searchword(p, 1), endword(p, 1));
	reverse(p, searchword(p, 2), endword(p, 2));
}
char *input()
{
	char *p;
	if (!(p = (char*)malloc(sizeof(char))))
		return nullptr;
	int i = 0;
	while ((p[i] = getchar()) != '\n')
		if (!(p = (char*)realloc(p, (++i + 1) * sizeof(char))))
			return nullptr;
	p[i] = '\0';
	return p;
}
int fibon(int num)
{
	return num == 1 || num == 2 ? 1 : fibon(num - 1) + fibon(num - 2);
}
int main()
{
	int n;
	do
	{
		rewind(stdin);
		scanf_s("%d", &n);
		printf("%d\n", fibon(n));
		rewind(stdin);
		
	} while (getchar() != 'e');
	system("pause");
	////
	rewind(stdin);
	char *p;
	if (!(p = input()))
		return 0;
	swap(p);
	puts(p);
	free(p);
	system("pause");
	return 0;
}