//����� 16 ������ 1
#include <iostream>
#include <Windows.h>


int main()
{
	long int n;
	scanf_s("%ld", &n);
	long int ll = 0;
	while (n)
	{
		float k = n;
		k /= 10;
		n /= 10;
		k -= n;
		k *= 10;
		k - (int)k >= 0.5 ? k = (int)k, k++ : k = (int)k;
		ll *= 10;
		ll += k;
	}
	printf("\n%ld", ll);
	system("pause");
	return 0;
}