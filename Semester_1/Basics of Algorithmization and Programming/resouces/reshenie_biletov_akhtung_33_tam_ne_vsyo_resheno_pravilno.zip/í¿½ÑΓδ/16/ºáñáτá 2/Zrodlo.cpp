//����� 16 ������ 2
#include <iostream>
#include <locale.h>


int ch4let(char s)
{
	if (s >= 'A' && s <= 'Z' || s >= 'a' && s <= 'z')
		return 1;
	else
		return 0;
}
int numOfWords(char *s)
{
	int kl = 0;
	if (ch4let(s[0]))
		kl++;
	for (int i = 1; s[i]; i++)
		if (ch4let(s[i]) && !ch4let(s[i - 1]))
			kl++;
	return kl;
}
int pozOf(char *s, int num)
{
	int kl = 0;
	int i = 1;
	if (ch4let(s[0]))
		kl++;
	if (kl == num)
		return 0;
	for (;s[i];i++)
		if (ch4let(s[i]) && !ch4let(s[i - 1]))
		{
			kl++;
			if (kl == num)
				return i;
		}
	return i;
}
int lenght(char *s, int num)
{
	int i = pozOf(s, num);
	int j = i;
	for (; ch4let(s[i]); i++);
	return i - j;
}
void reverse(char *s, int poz1, int poz2)
{
	if (poz1 >= poz2)
		return;
	int t = s[poz1];
	s[poz1] = s[poz2];
	s[poz2] = t;
	reverse(s, poz1 + 1, poz2 - 1);
}
void swap(char *s)
{
	if (numOfWords(s) <= 1)
		return;
	int max = 1;
	for (int i = 2; i <= numOfWords(s); i++)
		if (lenght(s, max) < lenght(s, i))
			max = i;
	if (max == 1)
		return;
	reverse(s, pozOf(s, max - 1), pozOf(s, max) + lenght(s, max) - 1);
	reverse(s, pozOf(s, max), pozOf(s, max) + lenght(s, max) - 1);
	reverse(s, pozOf(s, max - 1), pozOf(s, max - 1) + lenght(s, max - 1) - 1);
	reverse(s, pozOf(s, max - 1) + lenght(s, max - 1), pozOf(s, max) - 1);
}
int main()
{
	char*s;
	if (!(s = (char*)malloc(sizeof(char))))
		return 0;
	int i = 0;
	while ((s[i]=getchar())!='\n')
		if (!(s = (char*)realloc(s,sizeof(char)*(++i + 1))))
		{
			free(s);
			return 0;
		}
	s[i] = 0;
	swap(s);
	puts(s);
	free(s);
	system("pause");
	return 0;
}