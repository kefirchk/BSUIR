//����� 29 ������ 2
#include <iostream>
#include <Windows.h>


int ch4Let(char s)
{
	if (s >= 'a' && s <= 'z' || s >= 'A' && s <= 'Z')
		return 1;
	else
		return 0;
}
int numOfWords(char* s)
{
	int kl = 0;
	if (ch4Let(s[0]))
		kl++;
	for (int i = 1; s[i] != '\0'; i++)
		if (!ch4Let(s[i - 1]) && ch4Let(s[i]))
			kl++;
	return kl;
}
int pozOfWord(char** argv, int i, int j)
{
	int ii = 1;
	if (ch4Let(argv[i][0]))
		j--;
	for (; j > 0; ii++)
	{
		if (ch4Let(argv[i][ii]) && !ch4Let(argv[i][ii - 1]))
			j--;
	}
	return ii;
}
int lenghtOfWord(char **argv, int i, int j)
{
	int ii;
	for (ii = pozOfWord(argv, i, j); ch4Let(argv[i][ii]); ii++);
	return ii - pozOfWord(argv, i, j);
}
void find1stWord(char** argv, int argc, int &i, int &j)
{
	i = 0;
	while (!numOfWords(argv[i]) && i < argc)
		i++;
	if (i == argc)
	{
		j = 0;
		return;
	}
	j = 1;
	return;
}
char *input()
{
	char *s;
	if (!(s = (char*)malloc(sizeof(char))))
		return nullptr;
	int i = 0;
	while ((s[i] = getchar()) != '\n')
		if (!(s = (char*)realloc(s, (++i + 1) * sizeof(char))))
			return nullptr;
	s[i] = '\0';
	return s;
}
int main()
{
	char **argv;
	int argc;
	scanf_s("%d", &argc);
	rewind(stdin);
	if (!(argv = (char**)malloc(argc * sizeof(char*))))
		return 0;
	for (int i = 0; i < argc; i++)
		if (!(argv[i] = input()))
		{
			for (i--; i >= 0; i--)
				free(argv[i]);
			free(argv);
			return 0;
		}
	//
	int maxi, maxj;
	find1stWord(argv, argc, maxi, maxj);
	if (!maxj) return 0;
	for (int i = 0; i < argc; i++)
	{
		for (int j = 1; j <= numOfWords(argv[i]); j++)
			lenghtOfWord(argv, i, j) > lenghtOfWord(argv, maxi, maxj) ? maxi = i, maxj = j : i = i;
	}
	for (int i = pozOfWord(argv, maxi, maxj) - 1; i < pozOfWord(argv, maxi, maxj) + lenghtOfWord(argv, maxi, maxj); i++)
		printf("%c", argv[maxi][i]);
	puts("");
	system("pause");
	return 0;
}