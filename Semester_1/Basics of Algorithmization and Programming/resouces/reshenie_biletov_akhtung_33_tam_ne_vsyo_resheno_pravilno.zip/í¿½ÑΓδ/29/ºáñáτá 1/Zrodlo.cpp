//����� 29 ������ 1
#include <iostream>
#include <Windows.h>

void toSS(char* s, int ss, int tch, float nu)
{
	static int i = 0;
	if (i == tch)
	{
		i = 0;
		return;
	}
	nu *= ss;
	s[i] = (int)nu >= 10 ? (int)nu - 10 + 'A' : (int)nu + '0';
	nu -= (int)nu;
	i++;
	toSS(s, ss, tch, nu);
}
int main()
{
	float num;
	int ss, tch;
	scanf_s("%f%d%d", &num, &ss, &tch);
	float nu = num - (int)num;
	char *s;
	if (!(s = (char*)calloc(sizeof(int), tch+1)))
		return 0;
	toSS(s, ss, tch, nu);
	printf("0.%s", s);
	free(s);
	system("pause");
	return 0;
}