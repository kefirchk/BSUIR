//����� 28 ������ 2
#include <iostream>
#include <Windows.h>


int ch4Let(char s)
{
	if (s >= 'A' && s <= 'Z' || s >= 'a' && s <= 'z')
		return 1;
	else 
		return 0;
}
int numOfWord(char *s)
{
	static int kl = 0;
	static int i = 1;
	if (s[i] == '\0')
	{
		int kll = kl;
		kl = 0;
		i = 1;
		return kll;
	}
	if (ch4Let(s[0]) && i == 1)
		kl++;
	if (ch4Let(s[i]) && !ch4Let(s[i - 1]))
		kl++;
	i++;
	return numOfWord(s);
}
int main()
{
	char*s;
	if (!(s = (char*)malloc(sizeof(char))))
		return 0;
	int i = 0;
	while ((s[i] = getchar()) != '\n')
		if (!(s = (char*)realloc(s, (++i + 1) * sizeof(char))))
		{
			free(s);
			return 0;
		}
	s[i] = '\0';
	printf("%d", numOfWord(s));
	puts("");
	system("pause");
	return 0;
}