//����� 28 ������ 1
#include <iostream>
#include <Windows.h>


int main()
{
	int *ms, n;
	scanf_s("%d", &n);
	if (!(ms = (int*)malloc(n * sizeof(int))))
		return 0;
	for (int i = 0; i < n; i++)
	{
		scanf_s("%d", ms + i);
		for (int ii = i; ii > 0; ii--)
			if (ms[ii - 1] > ms[ii])
			{
				int t = ms[ii];
				ms[ii] = ms[ii - 1];
				ms[ii - 1] = t;
			}
			else
				break;
	}
	for (int i = 0; i < n; i++)
		printf(" %d", ms[i]);
	puts("");
	system("pause");
	return 0;
}