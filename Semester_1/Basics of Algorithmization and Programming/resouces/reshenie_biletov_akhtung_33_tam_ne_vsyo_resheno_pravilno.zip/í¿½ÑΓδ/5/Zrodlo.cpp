//����� 5
#include <iostream>
#include <Windows.h>


void shift(char *s, int n, int i)
{
	int ii = 0;
	for (; s[ii] != '\0'; ii++);
	int sz = i - ii;
	for (; ii >= n; i--)
		s[i] = s[ii--];

}
char* input()
{
	char *s;
	if (!(s = (char*)malloc(sizeof(char))))
		return nullptr;
	int i = 0;
	while ((s[i] = getchar()) != '\n')
		if (!(s = (char*)realloc(s, (++i + 1) * sizeof(char))))
		{
			free(s);
			return nullptr;
		}
	s[i] = '\0';
	return s;

}
int minvstr(int* p, int kl)
{
	int min = p[0];
	for (int i = 1; i < kl; i++)
		min > p[i] ? min = p[i] : min = min;
	return min;
}
int maxvst(int **mt, int kl, int poz)
{
	int max = mt[0][poz];
	for (int i = 1; i < kl; i++)
		max < mt[i][poz] ? max = mt[i][poz] : max = max;
	return max;
}
int main()
{
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);
	/*
	int **mt, n, m;
	scanf_s("%d%d", &n, &m);
	if (!(mt = (int**)malloc(n * sizeof(int*))))
		return 0;
	for (int i = 0; i < n; i++)
	{
		if (!(mt[i] = (int*)malloc(m * sizeof(int))))
		{
			for (; i >= 0; i--)
				free(mt[i]);
			free(mt);
			return 0;
		}
		for (int j = 0; j < m; j++)
			scanf_s("%d", *(mt + i) + j);
	}
	system("cls");
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
			printf("%5d", mt[i][j]);
		printf("\n");
	}
	//
	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
		{
			if (minvstr(mt[i], m) == mt[i][j] && maxvst(mt, n, j) == mt[i][j])
				printf("\nmt[%d][%d] = %d - �������� �����\n", i, j, mt[i][j]);
		}
	for (int i = 0; i < n; i++)
		free(mt[i]);
	free(mt);
	system("pause");
	*/
	////
	
	char*s1, *s2;
	if (!(s1 = input()))
		return 0;
	if (!(s2 = input()))
	{
		free(s1);
		return 0;
	}
	//
	int kk;
	rewind(stdin);
	scanf_s("%d", &kk);
	int i = 0, j = 0;
	for (; s1[i] != '\0'; i++);
	for (; s2[j] != '\0'; j++);
	char *ss1, *ss2;
	ss1 = s1;
	ss2 = s2;
	if (i > j)
	{
		int tt = i;
		i = j;
		j = tt;
		char *t;
		t = ss1;
		ss1 = ss2;
		ss2 = t;
	}
	if (!(ss1 = (char*)realloc(ss1, (i + j - 1) * sizeof(char))))
	{
		free(s2);
		return 0;
	}
	shift(ss1, kk, i + j);
	
	for (int i = 0; i < j; i++)
		ss1[kk + i] = ss2[i];
	puts(ss1);
	//free(ss1);
	//free(ss2);
	system("pause"); 
	return 0;
}