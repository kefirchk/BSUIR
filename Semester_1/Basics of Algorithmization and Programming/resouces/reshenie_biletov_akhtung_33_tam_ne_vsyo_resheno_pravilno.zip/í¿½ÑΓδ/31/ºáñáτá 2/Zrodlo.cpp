//����� 31 ������ 2
#include <iostream>
#include <Windows.h>


void clean(char* s)
{
	static int i = 0;
	if (s[i] == '\0')
	{
		i = 0;
		return;
	}
	int fl = 1;
	if (s[i] == ' ' && s[i + 1] == ' ' || i == 0 && s[i] == ' ' || s[i] == ' ' && s[i + 1] == '\0')
	{
		fl = 0;
		int j;
		for (j = i + 1; s[j] != '\0'; j++)
			s[j - 1] = s[j];
		s[j - 1] = s[j];
	}
	if (!fl)
		i--;
	i++;
	clean(s);
	return;
}
int main()
{
	char *s;
	if(!(s = (char*)malloc(sizeof(char))))
		return 0;
	int i = 0;
	while ((s[i] = getchar()) != '\n')
		if (!(s = (char*)realloc(s, (++i + 1) * sizeof(char))))
		{
			free(s);
			return 0;
		}
	s[i] = '\0';
	puts(s);
	//
	clean(s);
	//
	puts(s);
	free(s);
	system("pause");
	return 0;
}