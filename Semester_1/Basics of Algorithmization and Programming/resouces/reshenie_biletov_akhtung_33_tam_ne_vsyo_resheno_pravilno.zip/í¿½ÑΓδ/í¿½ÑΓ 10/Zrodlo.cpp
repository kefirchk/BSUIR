//����� 10
#include <iostream>
#include <Windows.h>


int ch4cirlet(char s)
{
	if (s >= '�' && s <= '�' || s >= '�' && s <= '�')
		return 1;
	else
		return 0;
}
void Check4CirillicsLetter(char **s, int n)
{
	int kl1 = 0, kl2 = 0;
	for (int i = 0; i < n; i++)
	{
		int fl = 0;
		for (int j = 0; s[i][j] != '\0'; j++, kl2++)
			if (ch4cirlet(s[i][j]))
			{
				printf("%c", s[i][j]);
				kl1++;
				fl++;
			}
		if (fl)
			printf("\n");
	}
	printf("\n\n����� ������������� ���� %d\n����� �������� %d\n������� ������������� %d%% �� ����� ������\n", kl1, kl2, (int)((float)kl1 * 100 / (float)kl2));
}
char* input()
{
	char*s;
	if (!(s = (char*)malloc(sizeof(char))))
		return nullptr;
	int i = 0;
	while ((s[i] = getchar()) != '\n')
		if (!(s = (char*)realloc(s, (++i + 1) * sizeof(char))))
			return nullptr;
	s[i] = '\0';
	return s;
}
void sort(short int* s, int kl)
{
	for (int shag = kl / 2; shag > 0; shag /= 2)
	{
		int flag;
		do
		{
			flag = 0;
			for (int i = 0, j = shag; j < kl; j++, i++)
				if (s[i] < s[j])
				{
					int t = s[i];
					s[i] = s[j];
					s[j] = t;
					flag = 1;
				}
		} while (flag);
	}
}
int main()
{
	short int **mt;
	int n, m, num;
	scanf_s("%d%d%d", &n, &m, &num);
	if (!(mt = (short int**)malloc(n * sizeof(short int*))))
		return 0;
	for (int i = 0; i < n; i++)
	{
		if (!(mt[i] = (short int*)malloc(sizeof(short int)*m)))
		{
			i--;
			for (; i >= 0; i--)
				free(mt[i]);
			free(mt);
			return 0;
		}
		for (int j = 0; j < m; j++)
			scanf_s("%hi", &mt[i][j]);
	}
	system("cls");
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
			printf("%3hi", mt[i][j]);
		printf("\n");
	}
	sort(mt[num], m);
	puts("\n");
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
			printf("%3hi", mt[i][j]);
		printf("\n");
	}
	for (int i = 0; i < n; i++)
		free(mt[i]);
	free(mt);
	system("pause");
	////
	char**s;
	scanf_s("%d", &n);
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);
	if (!(s = (char**)malloc(sizeof(char*)*n)))
		return 0;
	for (int i = 0; i < n; i++)
	{
		rewind(stdin);
		if (!(s[i] = input()))
		{
			i--;
			for (; i >= 0; i--)
				free(s[i]);
			free(s);
			return 0;
		}
	}
	Check4CirillicsLetter(s, n);
	system("pause");
	for (int i = 0; i < n; i++)
		free(s[i]);
	free(s);
	return 0;
}