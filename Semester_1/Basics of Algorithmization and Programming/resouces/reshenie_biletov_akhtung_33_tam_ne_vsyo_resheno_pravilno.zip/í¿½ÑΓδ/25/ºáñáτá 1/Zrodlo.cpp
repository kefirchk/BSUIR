//����� 25 ������ 1
#include <iostream>
#include <Windows.h>


int peremn(int **mt1, int **mt2, int n, int m, int k)
{
	int pr = 0;
	for (int i = 0; i < m; i++)
		pr += mt1[n][i] * mt2[i][k];
	return pr;
}
void vyvod(int** mt, int n, int m)
{
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
			printf("%5d", *(*(mt + i) + j));
		printf("\n");
	}
	printf("\n");
}
int main()
{
	int n, m, k;
	scanf_s("%d%d%d", &n, &m, &k);
	int **mt1, **mt2, **mt3;
	if (!(mt1 = (int**)malloc(n * sizeof(int*))))
		return 0;
	for (int i = 0; i < n; i++)
	{
		if (!(mt1[i] = (int*)malloc(m * sizeof(int))))
		{
			for (i--; i >= 0; i--)
				free(mt1[i]);
			free(mt1);
			return 0;
		}
		for (int j = 0; j < m; j++)
		{
			printf("mt1[%d][%d] = ", i, j);
			scanf_s("%d", *(mt1 + i) + j);
		}
	}
	if (!(mt2 = (int**)malloc(m * sizeof(int*))))
	{
		for (int j = 0; j < n; j++)
			free(mt1[j]);
		free(mt1);
		return 0;
	}
	for (int i = 0; i < m; i++)
	{
		if (!(mt2[i] = (int*)malloc(k * sizeof(int))))
		{
			for (i--; i >= 0; i--)
				free(mt2[i]);
			free(mt2);
			for (int j = 0; j < n; j++)
				free(mt1[j]);
			free(mt1);
			return 0;
		}
		for (int j = 0; j < k; j++)
		{
			printf("mt2[%d][%d] = ", i, j);
			scanf_s("%d", *(mt2 + i) + j);
		}
	}
	if (!(mt3 = (int**)malloc(n * sizeof(int*))))
	{
		for (int j = 0; j < n; j++)
			free(mt1[j]);
		free(mt1);
		for (int j = 0; j < n; j++)
			free(mt2[j]);
		free(mt2);
		return 0;
	}
	for (int i = 0; i < n; i++)
	{
		if (!(mt3[i] = (int*)malloc(k * sizeof(int))))
		{
			for (int j = 0; j < m; j++)
				free(mt2[i]);
			free(mt2);
			for (int j = 0; j < n; j++)
				free(mt1[i]);
			free(mt1);
			for (i--; i >= 0; i--)
				free(mt3[i]);
			free(mt3);
			return 0;
		}
	}
	for (int i = 0; i < n; i++)
		for (int j = 0; j < k; j++)
			mt3[i][j] = peremn(mt1, mt2, i, m, j);
	vyvod(mt1, n, m);
	vyvod(mt2, m, k);
	vyvod(mt3, n, k);
	for (int i = 0; i < n; i++)
	{
		free(mt1[i]);
		free(mt3[i]);
	}
	for (int i = 0; i < m; i++)
		free(mt2[i]);
	free(mt1);
	free(mt2);
	free(mt3);
	system("pause");
	return 0;
}