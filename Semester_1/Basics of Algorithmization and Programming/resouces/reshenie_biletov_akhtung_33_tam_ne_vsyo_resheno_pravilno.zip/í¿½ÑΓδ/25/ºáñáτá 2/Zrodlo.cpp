//����� 25 ������ 2
#include <iostream>
#include <Windows.h>


int ch4n(char s)
{
	if (s >= '0' && s <= '9')
		return 1;
	else
		return 0;
}
float chToNum(char*s, int &i)
{
	float num = 0;
	while (ch4n(s[i]))
	{
		num *= 10;
		num += s[i] - '0';
		i++;
	}
	if (ch4n(s[i - 1]) && ch4n(s[i + 1]) && s[i] == ',' || ch4n(s[i - 1]) && ch4n(s[i + 1]) && s[i] == '.')
	{
		int ii = i;
		i++;
		while (ch4n(s[i]))
		{
			int d = 1;
			for (int iii = i - ii; iii > 0; iii--)
				d *= 10;
			num += ((float)(s[i] - '0')) / d;
			i++;
		}
	}
	return num;
}
float *toNum(char* s, int &kl)
{
	float *ms;
	kl = 0;
	if (!(ms = (float*)malloc(sizeof(float))))
		return nullptr;
	int i = 0;
	while (s[i]!='\0')
	{
		while (!ch4n(s[i]) && s[i] != '\0')
		{
			i++;
		}
		if (s[i] == '\0' && kl)
			return ms;
		if (s[i] == '\0' && !kl)
		{
			free(ms);
			return nullptr;
		}
		if (!(ms = (float*)realloc(ms, sizeof(float)*(kl + 1))))
		{
			free(ms);
			return nullptr;
		}
		ms[kl] = chToNum(s, i);
		
		kl++;
	}
	if (kl)
		return ms;
	else
	{
		free(ms);
		return nullptr;
	}

}
int main()
{
	char *s;
	if (!(s = (char*)malloc(sizeof(int))))
		return 0;
	int i = 0;
	rewind(stdin);
	while((s[i]=getchar())!='\n')
		if (!(s = (char*)realloc(s, sizeof(char)*(++i + 1))))
		{
			free(s);
			return 0;
		}
	s[i] = '\0';
	float *ms;
	int rz;
	if (!(ms = toNum(s, rz)))
	{
		free(s);
		return 0;
	}
	for (int i = 0; i < rz; i++)
		printf(" %f", *(ms + i));
	free(s);
	free(ms);
	system("pause");
	return 0;
}