//����� 1
#include <iostream>
#include <Windows.h>
#include <locale.h>

int ch4num(char s)
{
	if (s >= '0' && s <= '9')
		return 1;
	else
		return 0;
}
int* transforme(char*s,int &h)
{
	int *p;
	if(!(p = (int*)malloc(sizeof(int))))
		return 0;
	h = 0;
	for (int i = 0; s[i] != '\0'; i++)
	{
		if (ch4num(s[i]))
		{
			int num = 0;
			for (; ch4num(s[i]); i++)
			{
				num *= 10;
				num += s[i] - '0';
			}
			h++;
			if (!(p = (int*)realloc(p, sizeof(int)*h)))
			return 0;
			p[h - 1] = num;
			i--;
		}
	}
	return p;
}
void swap(int &n, int &j)
{
	int k = n;
	n = j;
	j = k;
	return;
}
int main()
{
	setlocale(LC_ALL, "rus");
	int n;
	scanf_s("%d", &n);
	int**m;
	if (!(m = (int**)malloc(n * sizeof(int*))))
		return 0;
	for (int i = 0; i < n; i++)
	{
		if (!(m[i] = (int*)malloc(n * sizeof(int))))
			return 0;
		for (int j = 0; j < n; j++)
			scanf_s("%d", *(m + i) + j);
	}
	system("cls");
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
			printf("%4d", m[i][j]);
		puts("");
	}
	//
	puts("\n");
	int i = 0, j = 0, sz = n - 1;
	do
	{
		do
		{
			swap(m[i][j], m[n - j - 1][n - i - 1]);
			j++;
		} while (j < sz);
		sz--;
		j = 0;
		i++;
	} while (i<n);
	//
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
			printf("%4d", m[i][j]);
		puts("");
	}
	for (int i = 0; i < n; i++)
		free(m[i]);
	free(m);
	system("pause");
	system("cls");
	////
	char* s;
	if (!(s = (char*)malloc(sizeof(char))))
		return 0;
	i = 0;
	rewind(stdin);
	while ((s[i]=getchar())!='\n')
	{
		if (!(s = (char*)realloc(s,(++i+1) * sizeof(char))))
			return 0;
	}
	s[i] = '\0';
	int h, *p = transforme(s, h);
	for (int i = 0; i < h; i++)
		printf("%7d", p[i]);
	free(s);
	free(p);
	puts("");
	system("pause");
	return 0;
}