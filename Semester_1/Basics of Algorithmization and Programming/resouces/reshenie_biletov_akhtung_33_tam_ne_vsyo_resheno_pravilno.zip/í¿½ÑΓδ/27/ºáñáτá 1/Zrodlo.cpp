//������ 27 ������ 1
#include <iostream>
#include <Windows.h>


int main()
{
	int n, m, *ms1, *ms2, *ms3;
	scanf_s("%d%d", &n, &m);
	if (!(ms1 = (int*)malloc(sizeof(int) * n)))
		return 0;
	if (!(ms2 = (int*)malloc(sizeof(int)*m)))
	{
		free(ms1);
		return 2;
	}
	if (!(ms3 = (int*)malloc(sizeof(int)*(n + m))))
	{
		free(ms1);
		free(ms2);
	}
	printf("ms1[0] = ");
	scanf_s("%d", ms1);
	for (int i = 1; i < n; i++)
	{
		rewind(stdin);
		printf("ms1[%d] = ", i);
		scanf_s("%d", ms1 + i);
		if (ms1[i] >= ms1[i - 1])
			i--;

	}
	rewind(stdin);
	printf("ms2[0] = ");
	scanf_s("%d", ms2);
	for (int i = 1; i < m; i++)
	{
		rewind(stdin);
		printf("ms2[%d] = ", i);
		scanf_s("%d", ms2 + i);
		if (ms2[i] <= ms2[i - 1])
			i--;

	}
	//
	int i1 = 0;
	int i2 = m - 1;
	for (int i = 0; i < m + n; i++)
	{
		if (i2 < 0)
			ms3[i] = ms1[i1++];
		else
			if (i1 >= n)
				ms3[i] = ms2[i2--];
			else
				if (ms2[i2] > ms1[i1])
					ms3[i] = ms2[i2--];
				else
					ms3[i] = ms1[i1++];
	}
	for (int i = 0; i < n + m; i++)
		printf(" %d", ms3[i]);
	puts("");
	//
	system("pause");
	free(ms1);
	free(ms2);
	free(ms3);
	return 0;
}