//����� 27 ������ 2
#include <iostream>
#include <Windows.h>


void shift(char*s, int poz1,int poz2)
{
	if (poz1 == poz2)
		return;
	char t = s[poz1];
	s[poz1] = s[poz1 + 1];
	s[poz1 + 1] = t;
	shift(s, poz1 + 1, poz2);
	return;
}
int ch4let(char s)
{
	if (s >= 'A' && s <= 'Z' || s >= 'a' && s <= 'z')
		return 1;
	else
		return 0;
}
void delete1stWord(char *s)
{
	static int i = 0, fl = 0;
	if (!i && !fl)
	{
		fl++;
		for (i = 0; !ch4let(s[i]) && s[i] != '\0'; i++);
	}
	if (!ch4let(s[i]))
	{
		fl = 0;
		i = 0;
		return;
	}	
	int j;
	for (j = 0; s[j] != '\0'; j++);
	shift(s, i, j);
	delete1stWord(s);
}
int main()
{
	char *s;
	if (!(s = (char*)malloc(sizeof(char))))
		return 0;
	int i = 0;
	while ((s[i]=getchar())!='\n')
		if (!(s = (char*)realloc(s, (++i + 1) * sizeof(char))))
		{
			free(s);
			return 0;
		}
	s[i] = '\0';
	//
	delete1stWord(s);
	//
	puts(s);
	system("pause");
	free(s);
	return 0;
}