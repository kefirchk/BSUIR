//����� 15 ������ 2
#include <iostream>
#include <Windows.h>


int ch4let(char s)
{
	if (s >= 'A' && s <= 'Z' || s >= 'a' && s <= 'z')
		return 1;
	else
		return 0;
}
int  numOf(char *s)
{
	int kl = 0;
	if (ch4let(s[0]))
		kl++;
	if (!s[0])
		return 0;
	for (int i = 1; s[i]; i++)
		if (ch4let(s[i]) && !ch4let(s[i - 1]))
			kl++;
	return kl;
}
int pozOf(char *s, int num)
{
	int i = 1;
	int kl = 0;
	if (ch4let(s[0]))
		kl++;
	if (kl == num)
		return 0;
	for (; s[i]; i++)
		if (ch4let(s[i]) && !ch4let(s[i - 1]))
		{
			kl++;
			if (kl == num)
				return i;
		}
	return i;
}
int longOf(char *s, int num)
{
	int i = pozOf(s, num);
	int j = i;
	for (; ch4let(s[i]); i++);
	return i - j;
}
void func(int kl, ...)
{
	char **p;
	p = (char**)&kl;
	p = (char**)((int*)p + 1);
	int min[3];
	min[0] = min[1] = min[2] = 0;
	
	for (int i = 0; i < kl; i++)
	{
		for (int j = 1; j <= numOf(*p); j++)
			if (!min[2])
			{
				min[2] = longOf(*p, j);
			}
			else
				if (longOf(*p, j) < min[2])
				{
					min[0] = i;
					min[1] = j;
					min[2] = longOf(*p, i);
				}
		p++;
	}
	if (!min[2])
		printf("\nthere are not any words!\n");
	else
	{
		printf("\n");
		p = (char**)&kl;
		p = (char**)((int*)p + 1);
		for (int i = 0; i < min[0]; i++)
			p++;
		for (int i = 0; i < min[2]; i++)
			printf("%c", *(*p + pozOf(*p, min[1]) + i));
	}
}
int main()
{
	char **s;
	int n = 4;
	//scanf_s("%d", &n);

	if (!(s = (char**)malloc(sizeof(char*)*n)))
		return 0;
	for (int i = 0; i < n; i++)
	{
		if (!(*(s + i) = (char*)malloc(sizeof(char))))
		{
			for (i--; i >= 0; i--)
				free(*(s + i));
			free(s);
			return 0;
		}
		int j = 0;
		while ((s[i][j]=getchar())!='\n')
			if (!(*(s + i) = (char*)realloc(*(s + i), sizeof(char)*(++j + 1))))
			{
				for (; i >= 0; i--)
					free(s[i]);
				free(s);
				return 0;
			}
		s[i][j] = 0;
	}
	//
	func(4, s[0], s[1], s[2], s[3]);
	//
	for (int i = 0; i < n; i++)
		free(s[i]);
	free(s);
	system("pause");
	return 0;
}