//����� 15 ������ 1
#include <iostream>
#include <Windows.h>


int main()
{
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);
	int n, *ms;
	long long int dz;
	scanf_s("%d", &n);
	if (!(ms = (int*)calloc(n, sizeof(int))))
		return 0;
	for (int i = 0; i < n; i++)
	{
		printf("ms[%d] =", i);
		scanf_s("%d", ms + i);
	}
	system("cls");
	for (int i = 0; i < n; i++)
		printf("%d ", *(ms + i));
	//
	dz = 0;
	for (int i = 0; i < n; i++)
	{
		int j, ii;
		for (j = 0, ii = 1; j <= ms[i]; j += 10, ii *= 10);
		ii /= 10;
		dz += ii;
	}
	for (int i = 1; i < 10; i++)
	{
		long long int dzyn = dz;
		dzyn /= 10;
		printf("\n� %d��� ������� �� ��������� %i\n", i, (int)(dz - dzyn * 10));
		dz /= 10;
	}
	//
	free(ms);
	system("pause");
	return 0;
}