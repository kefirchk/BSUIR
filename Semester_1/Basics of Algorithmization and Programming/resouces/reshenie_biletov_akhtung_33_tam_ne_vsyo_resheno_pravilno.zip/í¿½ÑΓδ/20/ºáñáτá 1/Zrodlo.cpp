//����� 20 ������ 1
#include <iostream>
#include <Windows.h>


void transpon(int** mt, int n)
{
	for (int i = 0; i < n; i++)
		for (int j = n - 1 - i; j >= 0; j--)
		{
			int t = mt[i][j];
			mt[i][j] = mt[n - 1 - j][n - 1 - i];
			mt[n - 1 - j][n - 1 - i] = t;
		}
	return;
}
void vyvod(int** mt, int n, int m)
{
	for (int i = 0; i < n; i++)
	{
		for (int j=0;j<m;j++)
			printf("%3d", *(*(mt + i) + j));
		printf("\n");
	}
}
int main()
{
	int** mt, n;
	scanf_s("%d", &n);
	if (!(mt = (int**)malloc(sizeof(int*)*n)))
		return 0;
	for (int i = 0; i < n; i++)
	{
		if (!(*(mt + i) = (int*)malloc(sizeof(int)*n)))
		{
			for (i--; i >= 0; i--)
				free(mt[i]);
			free(mt);
			return 0;
		}
		for (int j = 0; j < n; j++)
		{
			printf("mt[%d][%d] = ", i, j);
			scanf_s("%d", *(mt + i) + j);
		}
	}
	vyvod(mt, n, n);
	//
	transpon(mt, n);
	//
	puts("\n");
	vyvod(mt, n, n);
	for (int i = 0; i < n; i++)
		free(*(mt + i));
	free(mt);
	system("pause");
	return 0;
}