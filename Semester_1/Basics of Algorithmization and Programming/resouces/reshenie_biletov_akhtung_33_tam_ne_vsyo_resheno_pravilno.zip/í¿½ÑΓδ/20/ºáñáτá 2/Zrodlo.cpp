//����� 20 ������ 2
#include <iostream>
#include <Windows.h>


char* input(char *s)
{
	free(s);
	if (!(s = (char*)malloc(sizeof(char))))
		return nullptr;
	int i = 0;
	while((s[i]=getchar())!='\n')
		if (!(s = (char*)realloc(s, (++i + 1) * sizeof(char))))
		{
			free(s);
			return nullptr;
		}
	s[i] = '\0';
	return s;
}
int lenght(char *s)
{
	int i;
	for (i = 0; s[i]; i++);
	return i;
}
int insert(char* s1, char* s2)
{
	int i = lenght(s1);
	if (!(s1 = (char*)realloc(s1, sizeof(char)*(i + lenght(s2)))))
		return 0;
	int j;
	for (j = 0; j < lenght(s2); j++, i++)
		s1[i] = s2[j];
	s1[i] = '\0';
	return 1;
}
int main()
{
	char *s1 = nullptr, *s2 = nullptr;
	if (!(s1 = input(s1)))
		return 0;
	if (!(s2 = input(s2)))
	{
		free(s1);
		return 0;
	}
	printf("\n");
	puts(s1);
	puts(s2);
	printf("\nlenght of 1st string is %d\nlenght of 2nd string is %d", lenght(s1), lenght(s2));
	if (!insert(s1, s2))
		return 0;
	printf("\n");
	puts(s1);
	printf("new lenght of 1st string is %d\n", lenght(s1));
	system("pause");
	return 0;
}