//����� 13
#include <iostream>
#include <windowsx.h>
#include <stdarg.h>

int ch4let(char s)
{
	if (s >= 'a' && s <= 'z' || s >= 'A' && s <= 'Z')
		return 1;
	else
		return 0;
}
int poz(char *s, int num)
{
	int kl = 0;
	if (ch4let(s[0]))
		kl++;
	if (kl == num)
		return 0;
	int i;
	for (i = 1; s[i] != '\0'; i++)
	{
		if (ch4let(s[i]) && !ch4let(s[i - 1]))
			kl++;
		if (kl == num)
			break;
	}
	return i;
}
int len(char*s, int num)
{
	int i = poz(s, num);
	int j;
	for (j = i; ch4let(s[j]); j++);
	return j - i;
}
int numofwords(char* s)
{
	int kl = 0;
	if (ch4let(s[0]))
		kl++;
	for (int i = 1; s[i] != '\0'; i++)
		if (ch4let(s[i]) && !ch4let(s[i - 1]))
			kl++;
	return kl;
}
char* find(char* s)
{
	int sl = 1;
	for (int i = 2; i <= numofwords(s); i++)
		if (len(s, sl) < len(s, i))
			sl = i;
	char *t;
	if (!(t = (char*)calloc(len(s, sl) + 1, sizeof(char))))
		return nullptr;
	for (int i = 0; i < len(s, sl); i++)
		t[i] = s[poz(s, sl) + i];
	return t;
}
char* input()
{
	char*s;
	if (!(s = (char*)malloc(sizeof(char))))
		return nullptr;
	int i = 0;
	while ((s[i] = getchar()) != '\n')
		if (!(s = (char*)realloc(s, sizeof(char)*(++i + 1))))
			return nullptr;
	s[i] = '\0';
	return s;
}
enum types { INT, FLOAT };
void sum(types typ, int kl, ...)
{
	int sum = 0;
	float summ = 0;
	switch (typ)
	{
	case INT:
		va_list p;
		va_start(p, kl);
		for (int i = 0; i < kl; i++)
			sum += va_arg(p, int);
		*va_arg(p, int*) = sum;
		va_end(p);
		break;
	case FLOAT:
		va_list pp;
		va_start(pp, kl);
		for (int i = 0; i < kl; i++)
			summ += va_arg(pp, double);
		*va_arg(pp, double*) = summ;
		va_end(pp);
		break;
	}
}
int main()
{
	int summa;
	double summaa;
	sum(INT, 3, 54, 45, 56, &summa);
	sum(FLOAT, 2, (double)54.23, (double)466.4, &summaa);
	printf("%d  %.3lf\n", summa, summaa);
	system("pause");
	////
	char *s;
	if (!(s = input()))
		return 0;
	char *t;
	if (!(t = find(s)))
	{
		free(s);
		return 0;
	}
	puts(t);
	free(s);
	free(t);
	system("pause");
	return 0;
}