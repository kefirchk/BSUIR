//����� 11
#include <iostream>
#include <Windows.h>


int ch4let(char s)
{
	if (s >= 'a' && s <= 'z' || s >= 'A' && s <= 'Z')
		return 1;
	else
		return 0;
}
int numofwords(char *s)
{
	int kl = 0;
	if (ch4let(s[0]))
		kl++;
	for (int i = 1; s[i] != '\0'; i++)
		if (!ch4let(s[i - 1]) && ch4let(s[i]))
			kl++;
	return kl;
}
int getpozofword(char *s, int num)
{
	int kl = 0, i = 1;
	if (ch4let(s[0]))
		kl++;
	if (kl == num)
		return 0;
	for (; s[i] != '\0'; i++)
	{
		if (ch4let(s[i]) && !ch4let(s[i - 1]))
			kl++;
		if (kl == num)
			return i;
	}
}
int compare(char *s, int num1, int num2)
{
	int i = getpozofword(s, num1), j = getpozofword(s, num2);
	int fl = 1;
	for (; ch4let(s[i]); i++, j++)
		if (s[i] != s[j])
			fl = 0;
	if (ch4let(s[i]) != ch4let(s[j]))
		fl = 0;
	return fl;
}
void shift(char *s, int poz1, int poz2, int topoz)
{
	for(;poz1<=poz2;poz1++, topoz++)
		s[topoz] = s[poz1];
}
void deleteword(char *s, int num)
{
	int i = getpozofword(s, num);
	int len = 0;
	for (; s[len] != '\0'; len++);
	int len2 = 0;
	for (; ch4let(s[i + len2]); len2++);
	shift(s, i + len2, len, i);
}
int nod(int n, int m, int i)
{
	if (n%i == 0 && m%i == 0)
		return i;
	else
		return nod(n, m, i - 1);
}
int nod(int n, int m)
{
	return nod(n, m, n);
}
int nok(int n, int m)
{
	static int i = 1;
	if ((n * i) % m == 0 && (n * i) % n == 0)
	{	
		int ii = i;
		i = 1;
		return n * ii;
	}
	else
	{
		i++;
		return nok(n, m);
	}
}
int main(int argc, char** argv)
{
	int n, m;
	do
	{
		rewind(stdin);
		scanf_s("%d%d", &n, &m);
		printf("the least commune diviser of %d & %d is %d\n", n, m, nod(n, m));
		rewind(stdin);
	} while (getchar() != 'e');
	////
	puts(argv[1]);
	for (int i = 2; i <= numofwords(argv[1]); i++)
		if (compare(argv[1], 1, i))
		{
			deleteword(argv[1], i);
			i--;
		}
	deleteword(argv[1], 1);
	puts(argv[1]);
	system("pause");
	return 0;
}