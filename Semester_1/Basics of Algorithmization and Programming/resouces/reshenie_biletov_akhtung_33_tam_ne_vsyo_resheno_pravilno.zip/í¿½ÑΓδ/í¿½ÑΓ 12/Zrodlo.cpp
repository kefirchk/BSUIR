//����� 12
#include <iostream>
#include <Windows.h>
#include <locale.h>


int ch4let(char s)
{
	if (s >= 'a' && s <= 'z' || s >= 'A' && s <= 'Z')
		return 1;
	else
		if (s >= -32 && s <= -1 || s >= -64 && s <= -33)
			return 1;
		else
			return 0;
}
int numofwords(char *s)
{
	int kl = 0;
	if (ch4let(s[0]))
		kl++;
	for (int i = 1; s[i] != '\0'; i++)
		if (!ch4let(s[i - 1]) && ch4let(s[i]))
			kl++;
	return kl;
}
int pozofword(char *s, int num)
{
	int kl = 0;
	if (ch4let(s[0]))
		kl++;
	if (kl == num)
		return 0;
	for (int i = 1; s[i] != '\0'; i++)
		if (ch4let(s[i]) && !ch4let(s[i - 1]))
		{
			kl++;
			if (kl == num)
				return i;
		}
	return 0;
}
int endofword(char *s, int num)
{
	int i = pozofword(s, num);
	for (; ch4let(s[i]); i++);
	i--;
	return i;
}
int poszuk(char *s, int num)
{
	int i = pozofword(s, num), j = endofword(s, num), fl = 0;
	for (int ii = 0; ii < 10; ii++)
	{
		for (int jj = i; jj <= j; jj++)
			if (s[jj] == ('�' + ii))
			{
				fl++;
				break;
			}
		if (fl == 10)
			break;
	}
		if (fl == 10)
			return 1;
		else
			return 0;

}
void poszuk(char **s, int n)
{
	for (int i = 0; i < n; i++)
	{
		for (int j = 1; j <= numofwords(s[i]); j++)
		{
			if (poszuk(s[i], j))
			{
				for (int ii = pozofword(s[i],j); ii <= endofword(s[i],j); ii++)
					printf("%c", s[i][ii]);
				printf("\n");
				break;
			}
		}
	}
}
char* input()
{
	rewind(stdin);
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);
	char *s;
	if (!(s = (char*)malloc(sizeof(char))))
		return nullptr;
	int i = 0;
	while ((s[i] = getchar()) != '\n')
		if (!(s = (char*)realloc(s, (++i + 1) * sizeof(char))))
			return nullptr;
	s[i] = 0;
	return s;
}
void sortdiag(int** mt, int n)
{
	for (int i = 0; i < n; i++)
	{
		int i1 = i;
		for (int j = i + 1; j < n; j++)
			if (mt[j][n-1-j] < mt[i1][n-1-i1])
				i1 = j;
		if (i1 != i)
		{
			int t = mt[i][n-1-i];
			mt[i][n-1-i] = mt[i1][n-1-i1];
			mt[i1][n-1-i1] = t;
		}
	}

}
int main()
{
	setlocale(LC_ALL, "rus");
	int** p, n;
	scanf_s("%d", &n);
	if (!(p = (int**)malloc(sizeof(int*)*n)))
		return 0;
	for (int i = 0; i < n; i++)
	{
		if (!(p[i] = (int*)malloc(sizeof(int)*n)))
		{
			i--;
			for (; i >= 0; i--)
				free(p[i]);
			free(p);
		}
		for (int j = 0; j < n; j++)
			scanf_s("%d", *(p + i) + j);
	}
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
			printf("%4d", *(*(p + i) + j));
		printf("\n");
	}
	printf("\n\n");
	sortdiag(p, n);
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
			printf("%4d", *(*(p + i) + j));
		printf("\n");
	}
	for (int i = 0; i < n; i++)
		free(p[i]);
	free(p);
	system("pause");
	////
	char **s;
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);
	scanf_s("%d", &n);
	if (!(s = (char**)malloc(n * sizeof(char*))))
		return 0;
	for (int i = 0; i < n; i++)
		if (!(s[i] = input()))
		{
			i--;
			for (; i >= 0; i--)
				free(s[i]);
			free(s);
			return 0;
		}
	poszuk(s, n);
	system("pause");
	return 0;
}