//����� 4
#include <iostream>
#include <Windows.h>


char* input();
void reverse(char*);
int main()
{
	int *p, *o, n, m;
	scanf_s("%d%d", &n, &m);
	if (!(p = (int*)malloc(n * sizeof(int))))
		return 0;
	if (!(o = (int*)malloc(m * sizeof(int))))
		return 0;
	for (int i = 0; i < n; i++)
		scanf_s("%d", p + i);
	for (int i = 0; i < m; i++)
		scanf_s("%d", &o[i]);
	system("cls");
	for (int i = 0; i < n; i++)
		printf("%d ", p[i]);
	printf("\n");
	for (int i = 0; i < m; i++)
		printf("%d ", o[i]);
	//
	int *op;
	if (!(op = (int*)malloc((n + m) * sizeof(int))))
		return 0;
	int i = n - 1, j = m - 1;
	int k = 0;
	while (k != n + m)
	{
		if (i >= 0 && j >= 0 && o[j] < p[i])
			op[k++] = p[i--];
		else
			op[k++] = o[j--];
		if (i < 0)
			for (; j >= 0; j--)
				op[k++] = o[j];
		if (j < 0)
			for (; i >= 0; i--)
				op[k++] = p[i];
	}
	puts("");
	for (int i = 0; i < m + n; i++)
		printf("%d ", op[i]);
	free(o);
	free(p);
	free(op);
	system("pause");
	////
	char *s;
	if (!(s = input()))
		return 0;
	reverse(s);
	puts(s);
	free(s);
	system("pause");
	return 0;
}
char *input()
{
	rewind(stdin);
	char*s;
	if (!(s = (char*)malloc(sizeof(char))))
		return nullptr;
	int i = 0;
	while ((s[i] = getchar()) != '\n')
		if (!(s = (char*)realloc(s, (++i + 1) * sizeof(char))))
			return nullptr;
	s[i] = '\0';
	return s;
}
int ch4num(char s)
{
	if (s >= 'a' && s <= 'z' || s >= 'A' && s <= 'Z')
		return 1;
	else 
		return 0;
}
int firstlet(char *s,int num)
{
	int numm = 0;
	if (ch4num(s[0]))
		numm++;
	if (numm == num)
		return 0;
	for (int i = 1; s[i] != '\0'; i++)
		if (ch4num(s[i]) && !ch4num(s[i - 1]))
		{
			numm++;
			if (numm == num)
				return i;
		}

}
int lastlet(char*s, int num)
{
	int i = firstlet(s, num);
	for (; ch4num(s[i]); i++);
	return i - 1;
}
int numofword(char*s)
{
	int num = 0;
	if (ch4num(s[0]))
		num++;
	for (int i = 1; s[i] != '\0'; i++)
		if (ch4num(s[i]) && !ch4num(s[i - 1]))
			num++;
	return num;
}
void reverse(char*s, int poz1, int poz2)
{
	if (poz1 < poz2)
	{
		char t = s[poz1];
		s[poz1] = s[poz2];
		s[poz2] = t;
		reverse(s, poz1 + 1, poz2 - 1);
	}
}
void reverse(char*s)
{
	for (int i = 1; i <= numofword(s); i++)
		reverse(s, firstlet(s, i), lastlet(s, i));
}
