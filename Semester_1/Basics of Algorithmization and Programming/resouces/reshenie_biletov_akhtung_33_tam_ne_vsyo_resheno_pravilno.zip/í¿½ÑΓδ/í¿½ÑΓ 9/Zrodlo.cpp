//����� 9
#include <iostream>
#include <Windows.h>


int ch4let(char s)
{
	if (s >= 'a' && s <= 'z' || s >= 'A' && s <= 'Z')
		return 1;
	else
		return 0;
}
void shift(char*s, int topoz, int poz1, int poz2)
{
	if (topoz > poz2)
	{
		for (; poz2 >= poz1; poz2--, topoz--)
			s[topoz] = s[poz2];
	}
	else
	{
		for (; poz1 <= poz2; poz1++, topoz++)
			s[topoz] = s[poz1];
	}
}
char*zamiena(char*s)
{
	printf("1st word:\n");
	int i = 0, j = 0;
	for (; s[j] != '\0'; j++);
	for (; s[i]; i++);
	for (j = 0; s[j] != '\0'; j++);
	for (i = j; i > 0; i--)
		if (ch4let(s[i]) && !ch4let(s[i - 1]))
			break;
	i--;
	for (; !ch4let(s[i]) && i >= 0; i--);
	for (; ch4let(s[i - 1]) && i >= 0; i--);
	char k;
	while (ch4let(s[i]))
	{
		shift(s, i, i + 1, j--);
		if (!(s = (char*)realloc(s,sizeof(char)*(j + 1))))
			return 0;
	}
	rewind(stdin);
	while (ch4let(k = getchar()))
	{
		if (!(s = (char*)realloc(s,sizeof(char)*(++j + 1))))
			return 0;
		shift(s, j, i++, j - 1);
		s[i - 1] = k;
	}
	rewind(stdin);
	printf("2nd word:\n");
	for (j = 0; s[j] != '\0'; j++);
	for (i = j; i > 0; i--)
		if (ch4let(s[i]) && !ch4let(s[i - 1]))
			break;
	for (; !ch4let(s[i]) && i >= 0; i--);
	for (; ch4let(s[i - 1]) && i >= 0; i--);
	while (ch4let(s[i]))
	{
		shift(s, i, i + 1, j--);
		if (!(s = (char*)realloc(s, sizeof(char)*(j + 1))))
			return 0;
	}
	while (ch4let(k = getchar()))
	{
		if (!(s = (char*)realloc(s, sizeof(char)*(++j + 1))))
			return 0;
		shift(s, j, i++, j - 1);
		s[i - 1] = k;
	}
	return s;

}
char*input()
{
	char *s;
	if (!(s = (char*)malloc(sizeof(char))))
		return 0;
	int i = 0;
	while ((s[i] = getchar()) != '\n')
		if (!(s = (char*)realloc(s, (++i + 1) * sizeof(char))))
			return 0;
	s[i] = '\0';
	return s;
}
void reverse(char*s, int poz1, int poz2)
{
	if (poz1 < poz2)
	{
		char p = s[poz1];
		s[poz1] = s[poz2];
		s[poz2] = p;
		reverse(s, poz1 + 1, poz2 - 1);
	}
}
char* celcz(int num, int syst)
{
	char *s;
	if (!(s = (char*)calloc(1, sizeof(char))))
		return 0;
	int kl = 0;
	while (num)
	{
		
		s[kl] = num % syst >= 10 ? 'A' + num % syst - 10 : '0' + num % syst;
		if (!(s = (char*)realloc(s, (++kl + 1) * sizeof(char))))
			return 0;
		num /= syst;
	}
	s[kl] = '\0';
	reverse(s, 0, kl - 1);
	return s;
}
char*drcz(float num, int syst, int tc)
{
	char *s;
	if (!(s = (char*)calloc(tc + 1, sizeof(char))))
		return 0;
	for (int i = 0; i < tc; i++)
	{
		num *= syst;
		int numm = num;
		s[i] = numm >= 10 ? 'A' + numm - 10: '0' + numm;
		num -= numm;
	}
	return s;
}
int main()
{ 
	char*s;
	if (!(s = input()))
		return 0;
	if (!(s = zamiena(s)))
		return 0;
	puts(s);
	free(s);
	system("pause");
	////
	float num;
	scanf_s("%f", &num);
	int num1 = num, tc, syst;
	scanf_s("%d%d", &syst, &tc);
	float num2 = num - num1;
	char *cel, *ost;
	if (!(cel = celcz(num1, syst)))
		return 0;
	if (!(ost = drcz(num2, syst, tc)))
	{
		free(cel);
		return 0;
	}
	printf("%s.%s", cel, ost);
	puts("");
	free(cel);
	free(ost);
	system("pause");
	return 0;
}