//������ 14 ������ 2
#include <iostream>
#include <Windows.h>


int ch4n(char s)
{
	if (s >= '0' && s <= '9')
		return 1;
	else
		return 0;
}
int sumatoi(char*s)
{
	static int i = 0, sum = 0;
	for (; s[i] && !ch4n(s[i]); i++);
	if (!s[i])
	{
		i = 0;
		int summ = sum;
		sum = 0;
		return summ;
	}
	int ch = 0;
	for (; s[i] >= '0' && s[i] <= '9'; i++)
		ch = ch * 10 + s[i] - '0';
	sum += ch;
	return sumatoi(s);
}
char* input()
{
	char *s;
	if (!(s = (char*)malloc(sizeof(char))))
		return 0;
	int i = 0;
	while ((s[i]=getchar())!='\n')
		if (!(s = (char*)realloc(s, sizeof(char)*(++i + 1))))
		{
			free(s);
			return 0;
		}
	s[i] = '\0';
	return s;
}
int main()
{
	char *s;
	if (!(s = input()))
		return 0;
	printf("%d", sumatoi(s));
	system("pause");
	return 0;
}