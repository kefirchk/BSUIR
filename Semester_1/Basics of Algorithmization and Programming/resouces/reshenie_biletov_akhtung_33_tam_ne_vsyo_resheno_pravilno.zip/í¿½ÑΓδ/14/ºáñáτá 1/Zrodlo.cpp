//����� 14 ������ 1
#include <iostream>
#include <Windows.h>


int transff(char*s, int ss1, int ss2, int i)
{
	if (s[i] == ',' || s[i] == '.')
		return transff(s, ss1, ss2, i + 1);
	if (!s[i])
		return 0;
	s[i] *= ss2;
	s[i] += transff(s, ss1, ss2, i + 1);
	int k = s[i] / ss1;
	s[i] -= k * ss1;
	return k;
}
void transf(char *s)
{
	int i = 0;
	for (; s[i] != '.' && s[i] != ',' && s[i]; i++);
	i++;
	if (!s[i])
		return;
	for (; s[i]; i++)
		s[i] >= 'A' && s[i] <= 'Z' ? s[i] -= 'A' - 10 : s[i] -= '0';
	return;
}
void transf(char *s, int ss1)
{
	int i = 0;
	for (; s[i] != '.' && s[i] != ',' && s[i]; i++);
	if (!s[i])
		return;
	for (; s[i]; i++)
		s[i] >= 10 ? s[i] += 'A' - 10 : s[i] += '0';
	return;
}
void transf(char* s, int ss1, int ss2, int tch)
{
	transf(s);
	printf("real part of number in %d is 0.", ss2);
	for (int i = 0; i < tch; i++)
	{
		int j;
		for (j = 0; s[j] && s[j] != ',' && s[j] != '.'; j++);
		char k = transff(s, ss1, ss2, j);
		k >= 10 ? k += 'A' - 10 : k += '0';
		printf("%c", k);
	}
	transf(s, ss1);
}
char * input()
{
	char *s;
	if (!(s = (char*)malloc(sizeof(char))))
		return nullptr;
	int i = 0;
	while ((s[i] = getchar()) != '\n')
		s = (char*)realloc(s, sizeof(char) * (++i + 1));
	s[i] = 0;
	return s;
}
int main()
{
	char* s;
	if (!(s = input()))
		return 0;
	int ss1, ss2, tch;
	rewind(stdin);
	scanf_s("%d%d%d", &ss1, &ss2, &tch);
	transf(s, ss1, ss2, tch);
	puts("");
	system("pause");
	return 0;
}