//����� 22 ������  2
#include <iostream>
#include <Windows.h>

int ch4let(char s)
{
	if (s >= 'A' && s <= 'Z' || s >= 'a' && s <= 'z')
		return 1;
	else
		return 0;
}
void reverse(char *s, int poz1, int poz2)
{
	if (poz1 >= poz2)
		return;
	char t = s[poz1];
	s[poz1] = s[poz2];
	s[poz2] = t;
	reverse(s, poz1 + 1, poz2 - 1);
}
void reverse(char *s)
{
	int i, j;
	for (j = 0; s[j] != '\0'; j++);
	for (; !ch4let(s[j]) && j >= 0; j--);
	for (i = j; i >= 0 && ch4let(s[i]); i--);
	i++;
	reverse(s, i, j);
}
int main()
{
	char *s;
	if (!(s = (char*)malloc(sizeof(char))))
		return 0;
	int i = 0;
	while ((s[i] = getchar()) != '\n')
		if (!(s = (char*)realloc(s, (++i + 1) * sizeof(char))))
		{
			free(s);
			return 0;
		}
	s[i] = 0;
	reverse(s);
	puts(s);
	system("pause");
	return 0;
}