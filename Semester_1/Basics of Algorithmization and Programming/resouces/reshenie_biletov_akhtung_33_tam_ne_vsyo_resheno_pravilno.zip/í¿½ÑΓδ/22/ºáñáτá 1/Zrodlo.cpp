//����� 22 ������ 1
#include <iostream>
#include <Windows.h>


enum types {intnum, doublenum};
void sum(int kl, ...)
{
	if (kl == 0)
		return;
	void *p;
	p = &kl;
	p = (int*)p + 1;
	int sumint = 0;
	double sumdouble = 0;
	for (int i = 0; i < kl; i++)
	{
		switch (*(types*)p)
		{
		case intnum:
			p = (types*)p + 1;
			sumint += *(int*)p;
			p = (int*)p + 1;
			break;
		case doublenum:
			p = (types*)p + 1;
			sumdouble += *(double*)p;
			p = (double*)p + 1;
			break;
		}
	}
	printf("sum of integer numbers is %d\n", sumint);
	printf("sum of double numbers is %lf\n", sumdouble);

}
int main()
{
	double q = 1, w = 234, e = 34;
	int qq = 12, ww = 11, ee = 10;
	sum(6, doublenum, q, doublenum, w, intnum, ee, intnum, qq, doublenum, e, intnum, ww);
	system("pause");
	return 0;
}