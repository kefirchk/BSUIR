-- Вывести уникальные названия городов из таблицы адресов проживания.

SELECT DISTINCT city 
FROM main_scheme.residential_address;
