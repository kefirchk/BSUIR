import socket
import datetime
import time
import sys
import os

HOST = "192.168.14.213"
PORT = 8080
BACKLOG = 1

BUFFER_SIZE = 512

UPLOAD_PATH = "./upload_files"
SERVER_FILES_PATH = "./server_files/"

KEEPALIVE_INTERVAL = 10
KEEPALIVE_PACKET_COUNT = 6

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)


def progress_bar(full, current):
    percent = (current / full) * 100
    s = f"{round(percent, 2)}%"
    print("Progress: " + s, end="\r")

#######################################################################################
class File:
    def __init__(self, file_name, mode, socket):
        self.file_name = file_name
        self.mode = mode
        self.socket = socket
    
    def send_file(self, offset):
        sended_data_size = 0
        with open(self.file_name, self.mode) as file:
            file.seek(int(offset), 0)
            file_size = os.path.getsize(self.file_name)
            start_time = time.time()
            while True:
                data = file.read(BUFFER_SIZE)
                if not data:
                    break
                progress_bar(file_size - offset, sended_data_size)
                self.socket.send(data)
                sended_data_size += len(data)
            print("\n")
            end_time = time.time()
            return (end_time - start_time)
        
    def recv_file(self, file_size, offset):
        recv_data_size = 0
        with open(self.file_name, self.mode) as file:
            file.seek(0, os.SEEK_END)
            offset = os.path.getsize(self.file_name)
            while file_size > offset:
                #progress_bar(file_size, recv_data_size)
                data = self.socket.recv(BUFFER_SIZE)
                recv_data_size += len(data)
                offset += len(data)
                if not data or offset > file_size:
                    break
                file.write(data)
            print("\n")



class ServerCommander:
    def __init__(self, server_socket):
        self.server_socket = server_socket
        self.client_is_active = True

    
    def send_msg(self, data):
        client_socket.send(str(data).encode("utf-8"))


    def recv_msg(self):
        return client_socket.recv(BUFFER_SIZE).decode("utf-8")


    def exec_quit(self):
        self.client_is_active = False


    def exec_time(self):
        current_time_formatted = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print(f"Now time: {current_time_formatted}")
        self.send_msg(current_time_formatted)


    def exec_echo(self, args):
        self.send_msg(args)


    def exec_download(self, file_name):
        if not os.path.exists(SERVER_FILES_PATH + file_name):
            print(f"File name: {file_name}")
            print("File status: NOT FOUND")
            print("File size: 0")
            self.send_msg("0")
        else:
            print(f"File name: {file_name}")
            print("File status: IS FOUND")

            file_size = os.path.getsize(SERVER_FILES_PATH + file_name)
            self.send_msg(file_size)
            print(f"File size: {file_size}")
            
            file_offset = int(self.recv_msg())
            print(f"File offset: {file_offset}")

            file = File(SERVER_FILES_PATH + file_name, "rb", client_socket)
            send_time = file.send_file(file_offset)
            confirmation = self.recv_msg()
            speed = "{:.2f}".format((file_size - file_offset) / send_time / 1024)
            self.send_msg(speed)
            print("Download Speed: {} KB/s".format(speed))



    def exec_upload(self, args):
        path_parts = ' '.join(args.split()[:-1]).split("/")
        full_file_name = os.path.join(UPLOAD_PATH, path_parts[-1])

        if os.path.exists(full_file_name):
            print(f"File name: {full_file_name}")
            print("File status: IS FOUND")
            mode = 'ab'
            file_offset = os.path.getsize(full_file_name)
            print(f"Old file size: {file_offset}")
        else:
            print(f"File name: {full_file_name}")
            print("File status: NOT FOUND")
            mode = 'wb+'
            file_offset = 0 
            print("Old file size: 0")
            
        file_size = int(args.split()[-1])
        print(f"New file size: {file_size}")

        self.send_msg(file_offset)

        file = File(full_file_name, mode, client_socket)
        file.recv_file(file_size, file_offset)
        self.send_msg("File uploaded successfully")
        speed = self.recv_msg()
        print(f"Upload Speed: {speed} KB/s")


    def handle_command(self, msg):
        if len(msg) == 0:
            return
        print('---------------REQUEST---------------')
        print(f"Get Request: {msg}")
        
        full_cmd = msg.split(maxsplit=1)
        command = full_cmd[0].strip().upper()
        arguments = "" if len(full_cmd) == 1 else full_cmd[1].strip()

        if command == "QUIT":  
            self.exec_quit()
        elif command == "TIME":
            self.exec_time()
        elif msg.startswith("ECHO"):
            self.exec_echo(msg[5:])
        elif command == "DOWNLOAD":
            self.exec_download(arguments)
        elif command == "UPLOAD":
            self.exec_upload(arguments)
        else:
            print("Error: unknown command")
        print('-------------------------------------')

#######################################################################################
        
class Server:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_running = True
    

    def start(self):
        global client_socket

        self.server_socket.bind((self.host, self.port))
        self.server_socket.listen(BACKLOG)
        print(f"Server is listening on {self.host}:{self.port}")

        #while self.server_running:
        client_socket, client_address = self.server_socket.accept()
        print(f"Client {client_address} was connected!\n")
        self.client_handler()


    def reconnect(self):
        global client_socket

        print(f"Connection with {client_socket.getsockname()} have been lost. Reconnecting...\n")
        client_socket.close()

        client_socket, client_address = self.server_socket.accept()
        
        client_socket = self.set_connetion_settings(client_socket)
        print("Reconnection completed!")


    def set_connetion_settings(self, client_socket):
        client_socket.settimeout(KEEPALIVE_INTERVAL * KEEPALIVE_PACKET_COUNT)
        client_socket.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        client_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, KEEPALIVE_INTERVAL)
        client_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, int(KEEPALIVE_INTERVAL / 8))
        client_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, KEEPALIVE_PACKET_COUNT)
        return client_socket


    def stop(self):
        global client_socket

        self.server_running = False
        client_socket.close()
        self.server_socket.close()
        print("Server is off. Goodbye!")

    
    def client_handler(self):
        global client_socket

        client_socket = self.set_connetion_settings(client_socket)

        commander = ServerCommander(self.server_socket)
        
        while commander.client_is_active:
            try:
                msg = client_socket.recv(BUFFER_SIZE).decode('utf-8')
                # print(f"Client socket: {client_socket}")
                commander.handle_command(msg)
            except socket.error as exception:
                self.reconnect()
        
        print(f"Client {client_socket.getsockname()} was disconnected!\n")
        client_socket.close()

#######################################################################################

if __name__ == "__main__":
    try:
        PORT = int(input("Enter a port number: "))
        server = Server(HOST, PORT)
        server.start()
    except KeyboardInterrupt:
        server.stop()
        sys.exit()
   
