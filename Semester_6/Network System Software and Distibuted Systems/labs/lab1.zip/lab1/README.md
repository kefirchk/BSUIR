# TASK
- Create TCP client-server application

# CLIENT

На клиенте должен присутствовать каталог download_files, куда будут помещаться скачанные файлы с сервера

# SERVER
