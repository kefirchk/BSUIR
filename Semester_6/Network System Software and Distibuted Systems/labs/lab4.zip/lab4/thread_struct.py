import threading
import time
from threading import Thread
from config import client_id

class ThreadStruct:
    def __init__(self, thread, is_active):
        self.thread = thread
        self.is_active = is_active
        self.del_time = time.time()
        self.client_id = client_id
    
    def start(self):
        self.thread.start()
    
    def close(self):
        self.thread.join()
    
    def get_id(self):
        return self.thread.ident