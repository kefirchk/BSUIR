import threading

HOST = "192.168.123.213"
PORT = 12345

UPLOAD_PATH = "./upload_files"
SERVER_FILES_PATH = "./server_files/"

READ_BUFFER_SIZE = 4096 # размер буфера чтения 425984
WRITE_BUFFER_SIZE = 1024 # размер буфера записи 2048
BUFFER_SIZE = 1024
SIZE_FOR_READ = 425984
SIZE_FOR_WRITE = 16384

SERVER_RUNNING = True

N_MIN = 1      # мин. кол-во потоков
N_MAX = 2      # макс. кол-во потоков
TIMEOUT = 10
threads = []
stdout_mutex = threading.Lock()
client_id = 1

file_recv_mutex = threading.Lock()

file_mutex = threading.Lock()
blocked_files = []