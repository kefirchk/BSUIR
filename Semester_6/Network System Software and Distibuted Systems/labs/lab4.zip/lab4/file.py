import os
import select
import time
import socket
from config import READ_BUFFER_SIZE, WRITE_BUFFER_SIZE, file_mutex

#######################################################################################
def progress_bar(full, current):
    percent = (current / full) * 100
    s = f"{round(percent, 2)}%"
    print("Progress: " + s, end="\r")

#######################################################################################
class File:
    def __init__(self, file_name, mode, socket, address):
        self.file_name = file_name
        self.mode = mode
        self.socket = socket
        self.address = address

    def wait(self, socket):
        readyToRead, _, _ = select.select([socket], [], [], 1)
        return readyToRead

    def send_file(self, offset):
        sended_data_size = 0
        send_time = 0
        with open(self.file_name, self.mode) as file:
            file.seek(int(offset), 0)
            file_size = os.path.getsize(self.file_name)
            while True:
                data = file.read(WRITE_BUFFER_SIZE)
                if not data:
                    break
                progress_bar(file_size - offset, sended_data_size)
                start_time = time.time()
                self.socket.sendto(data, self.address)
                end_time = time.time()
                send_time += end_time - start_time
                sended_data_size += len(data)
            print("\n")
            return (send_time)
        
    def recv_file(self, file_size, offset):
        recv_data_size = 0
        with open(self.file_name, self.mode) as file:
            file.seek(0, os.SEEK_END)
            offset = os.path.getsize(self.file_name)
            while self.wait(self.socket):
                data, address = self.socket.recvfrom(READ_BUFFER_SIZE)
                recv_data_size += len(data)
                #progress_bar(file_size - offset, recv_data_size)
                if not data:
                    break
                file.write(data)
            print("\n")