import datetime
import time
import sys
import os
import socket
from file import File
from config import BUFFER_SIZE, SERVER_FILES_PATH, UPLOAD_PATH, file_mutex, blocked_files


class ServerCommander:
    def __init__(self, server_socket):
        self.server_socket = server_socket
        self.client_is_active = True

    
    def send_msg(self, data):
        self.server_socket.sendto(str(data).encode("utf-8"), self.client_address)


    def recv_msg(self):
        recv_data, recv_address = self.server_socket.recvfrom(BUFFER_SIZE)
        return (recv_data.decode("utf-8"), recv_address)


    def exec_quit(self):
        self.client_is_active = False


    def exec_time(self):
        current_time_formatted = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print(f"Now time: {current_time_formatted}")
        self.send_msg(current_time_formatted)


    def exec_echo(self, args):
        self.send_msg(args)


    def exec_download(self, file_name):
        global blocked_files
        for el in blocked_files:
            if el == file_name:
                print("FILE IS BLOCKED!")
                return

        if not os.path.exists(SERVER_FILES_PATH + file_name):
            print(f"File name: {file_name}")
            print("File status: NOT FOUND")
            print("File size: 0")
            self.send_msg("0")
        else:
            print(f"File name: {file_name}")
            print("File status: IS FOUND")

            file_size = os.path.getsize(SERVER_FILES_PATH + file_name)
            self.send_msg(file_size)
            print(f"File size: {file_size}")
            
            file_offset, _ = self.recv_msg()
            file_offset = int(file_offset)
            print(f"File offset: {file_offset}")

            file = File(SERVER_FILES_PATH + file_name, "rb", self.server_socket, self.client_address)
            send_time = file.send_file(file_offset)
            speed = "{:.2f}".format((file_size - file_offset) / send_time / 1024)
            print("Download Speed: {} KB/s".format(speed))


    def exec_upload(self, args):
        global blocked_files
        path_parts = ' '.join(args.split()[:-1]).split("/")

        file_mutex.acquire()
        blocked_files.append(path_parts[-1])
        file_mutex.release()

        full_file_name = os.path.join(UPLOAD_PATH, path_parts[-1])

        if os.path.exists(full_file_name):
            print(f"File name: {full_file_name}")
            print("File status: IS FOUND")
            mode = 'ab'
            file_offset = os.path.getsize(full_file_name)
            print(f"Old file size: {file_offset}")
        else:
            print(f"File name: {full_file_name}")
            print("File status: NOT FOUND")
            mode = 'wb+'
            file_offset = 0 
            print("Old file size: 0")
            
        file_size = int(args.split()[-1])
        print(f"New file size: {file_size}")

        self.send_msg(file_offset)

        file = File(full_file_name, mode, self.server_socket, self.client_address)
        file.recv_file(file_size, file_offset)

        file_mutex.acquire()
        blocked_files = [el for el in blocked_files if el == path_parts[-1]]
        file_mutex.release()


    def handle_command(self, msg):
        if len(msg) == 0:
            return
        print('---------------REQUEST---------------')
        print(f"Get Request: {msg}")
        
        full_cmd = msg.split(maxsplit=1)
        command = full_cmd[0].strip().upper()
        arguments = "" if len(full_cmd) == 1 else full_cmd[1].strip()

        if command == "QUIT":  
            self.exec_quit()
        elif command == "TIME":
            self.exec_time()
        elif msg.startswith("ECHO"):
            self.exec_echo(msg[5:])
        elif command == "DOWNLOAD":
            self.exec_download(arguments)
        elif command == "UPLOAD":
            self.exec_upload(arguments)
        else:
            print("[ERROR]: unknown command")
        print('-------------------------------------')

    def set_client_address(self, client_address):
        self.client_address = client_address
