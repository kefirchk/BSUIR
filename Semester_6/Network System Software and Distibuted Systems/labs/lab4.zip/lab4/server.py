import socket
import time
import sys
import threading
from threading import Thread
from server_commander import ServerCommander
from thread_struct import ThreadStruct
from config import \
    HOST, \
    PORT, \
    WRITE_BUFFER_SIZE, \
    BUFFER_SIZE, \
    SIZE_FOR_READ, \
    SIZE_FOR_WRITE, \
    SERVER_RUNNING, \
    N_MIN, N_MAX, \
    TIMEOUT, threads, stdout_mutex, client_id, file_recv_mutex

message = None

def get_active_thread_amount():
    amount = 0
    for thread in threads:
        if thread.is_active == True:
            amount += 1
    return amount


def find_current_thread(thread_id):
    for thread in threads:
        if thread.get_id() == thread_id:
            return thread
    return None


def delete_this_thread(thread_id):
    global threads
    for thread in threads:
        if thread.get_id() == thread_id:
            threads.remove(thread)
            

#######################################################################################
class Server:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, SIZE_FOR_WRITE)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, SIZE_FOR_READ)
        self.server_socket.settimeout(2)

        self.server_socket.bind((self.host, self.port))
    

    def start(self):
        global threads

        print(f"[INFO]: UDP Server is listening on {self.host}:{self.port}")

        # Создание начального пула потоков
        for _ in range(N_MIN):
            new_thread = ThreadStruct(thread=Thread(target=self.client_handler), is_active=False)
            threads.append(new_thread)
            new_thread.start()

        # Главный цикл по обработке клиентов
        while SERVER_RUNNING == True:
            stdout_mutex.acquire()
            print(f"[INFO]: Active threads: {get_active_thread_amount()}")
            print(f"[INFO]: Threads ({len(threads)}):")
            for thread in threads:
                print(f"\tthread id={thread.get_id()}, active status={thread.is_active}")
            stdout_mutex.release()

            # Если закончились потоки, то нужно создать новый поток
            if get_active_thread_amount() == len(threads) and len(threads) < N_MAX:
                new_thread = ThreadStruct(thread=Thread(target=self.client_handler), is_active=False)
                threads.append(new_thread)
                new_thread.start()

            time.sleep(2)
        

    def stop(self):
        global SERVER_RUNNING
        SERVER_RUNNING = False

        for thread in threads:
            thread.close()

        self.server_socket.close()
        print("Server is off. Goodbye!")  

    
    def client_handler(self):
        global client_id
        global threads

        commander = ServerCommander(self.server_socket)
        
        stdout_mutex.acquire()
        print(f"[INFO]: START THREAD={threading.get_ident()}")
        stdout_mutex.release()

        current_thread = find_current_thread(threading.get_ident())
        current_thread.del_time = time.time()

        # while True:
        #     try:
        #         msg, client_address = self.server_socket.recvfrom(BUFFER_SIZE)
        #         if msg.decode("utf-8") == "INITIALIZE":
        #             self.server_socket.sendto(str(client_id).encode("utf-8"), client_address)
        #             current_thread.client_id = client_id
        #             client_id += 1
        #             break
        #     except socket.timeout:
        #         if not commander.client_is_active or not SERVER_RUNNING:
        #             break

        while commander.client_is_active and SERVER_RUNNING:
            try:
                #file_recv_mutex.acquire()
                msg, client_address = self.server_socket.recvfrom(BUFFER_SIZE)
                #file_recv_mutex.release()
                #full_cmd = msg.split(maxsplit=1)
                #client_id = int(full_cmd[0].strip())
                #msg = "" if len(full_cmd) == 1 else full_cmd[1].strip()

                #if client_id == current_thread.client_id:
                current_thread.is_active = True
                
                self.client_address = client_address
                commander.set_client_address(client_address)
                commander.handle_command(msg.decode("utf-8"))

                current_thread.del_time = time.time()
                current_thread.is_active = False

            except socket.timeout:
                if not commander.client_is_active or not SERVER_RUNNING:
                    break
                if time.time() - current_thread.del_time > TIMEOUT and current_thread.is_active == False and len(threads) > N_MIN:
                    delete_this_thread(threading.get_ident())
                    break
            except OSError as err:
                print(f"[ERROR]: {err}")
                break
                                  
        print(f"[INFO]: CLOSE THREAD={threading.get_ident()}...")

        

#######################################################################################

if __name__ == "__main__":
    try:
        # HOST = socket.gethostbyname(socket.gethostname())
        # PORT = int(input("Enter a port number: "))
        server = Server(HOST, PORT)
        server.start()
    except KeyboardInterrupt:
        server.stop()
        sys.exit()
   
