import cv2
import numpy as np
import sys
import time
from pathlib import Path
from mpi4py import MPI

def apply_laplace_filter_cpu(frame):
    # Преобразуем кадр в оттенки серого
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY).astype(np.float32)
    height, width = gray.shape
    output = np.zeros_like(gray, dtype=np.uint8)
    
    # Ядро фильтра Лапласа
    for y in range(1, height - 1):
        for x in range(1, width - 1):
            # Вычисляем сумму с использованием float32
            sum = (gray[y-1, x-1] +
                  gray[y-1, x] +
                  gray[y-1, x+1] +
                  gray[y, x-1] -
                  8 * gray[y, x] +
                  gray[y, x+1] +
                  gray[y+1, x-1] +
                  gray[y+1, x] +
                  gray[y+1, x+1])
            
            # Нормализация и усиление контраста
            normalized = sum / 255.0
            enhanced = np.sign(normalized) * np.sqrt(abs(normalized))
            
            # Преобразуем в диапазон [0, 255] и ограничиваем значения
            pixel_value = np.clip(enhanced * 127.5 + 127.5, 0, 255).astype(np.uint8)
            output[y, x] = pixel_value
    
    # Применяем дополнительное усиление контраста
    output = cv2.equalizeHist(output)
    
    # Преобразуем обратно в BGR
    return cv2.cvtColor(output, cv2.COLOR_GRAY2BGR)

def process_video_mpi(input_path: Path, output_path: Path):
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()
    
    if size < 2:
        raise Exception("Необходимо минимум 2 процесса для работы (1 мастер + 1 рабочий)")
    
    try:
        if rank == 0:
            # Мастер процесс
            print(f"[Master] Запуск CPU обработки с {size} процессами")
            print(f"[Master] Входной файл: {input_path}")
            
            cap = cv2.VideoCapture(str(input_path))
            if not cap.isOpened():
                raise Exception(f"Не удалось открыть видео: {input_path}")
            
            # Получаем параметры видео
            width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            fps = int(cap.get(cv2.CAP_PROP_FPS))
            total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            
            print(f"[Master] Параметры видео: {width}x{height} @ {fps}fps, всего кадров: {total_frames}")
            
            # Создаем VideoWriter
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            out = cv2.VideoWriter(str(output_path), fourcc, fps, (width, height))
            
            # Отправляем параметры видео рабочим
            video_params = (width, height, fps, total_frames)
            for worker in range(1, size):
                comm.send(video_params, dest=worker, tag=10)
                status = comm.recv(source=worker, tag=11)
                if not status:
                    raise Exception(f"Worker {worker} не готов к работе")
            
            # Распределяем кадры
            frames_per_worker = total_frames // (size - 1)
            remaining_frames = total_frames % (size - 1)
            
            for worker in range(1, size):
                start_frame = (worker - 1) * frames_per_worker
                end_frame = start_frame + frames_per_worker
                if worker == size - 1:
                    end_frame += remaining_frames
                
                work_data = (start_frame, end_frame)
                comm.send(work_data, dest=worker, tag=0)
            
            # Получаем и сохраняем обработанные кадры
            frame_buffer = {}
            next_frame_to_write = 0
            frames_processed = 0
            last_progress_time = time.time()
            
            while frames_processed < total_frames:
                frame_data = comm.recv(source=MPI.ANY_SOURCE, tag=1)
                frame_idx, processed_frame = frame_data
                
                frame_buffer[frame_idx] = processed_frame
                frames_processed += 1
                
                # Записываем кадры в правильном порядке
                while next_frame_to_write in frame_buffer:
                    out.write(frame_buffer[next_frame_to_write])
                    del frame_buffer[next_frame_to_write]
                    next_frame_to_write += 1
                
                # Выводим прогресс каждую секунду
                current_time = time.time()
                if current_time - last_progress_time >= 1.0:
                    progress = (frames_processed / total_frames) * 100
                    print(f"[Master] Прогресс: {progress:.1f}% ({frames_processed}/{total_frames} кадров)")
                    last_progress_time = current_time
            
            cap.release()
            out.release()
            print("[Master] Обработка завершена")
            
        else:
            # Worker процесс
            try:
                # Получаем параметры видео
                video_params = comm.recv(source=0, tag=10)
                width, height, fps, total_frames = video_params
                comm.send(True, dest=0, tag=11)
                
                # Получаем задание
                work_data = comm.recv(source=0, tag=0)
                start_frame, end_frame = work_data
                print(f"[Worker {rank}] Получено задание: кадры {start_frame}-{end_frame}")
                
                cap = cv2.VideoCapture(str(input_path))
                if not cap.isOpened():
                    raise Exception("Не удалось открыть видео")
                
                cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
                frames_read = 0
                
                last_progress_time = time.time()
                start_time = time.time()
                
                for frame_idx in range(start_frame, end_frame):
                    ret, frame = cap.read()
                    if not ret:
                        raise Exception(f"Ошибка чтения кадра {frame_idx}")
                    
                    processed = apply_laplace_filter_cpu(frame)
                    comm.send((frame_idx, processed), dest=0, tag=1)
                    frames_read += 1
                    
                    # Выводим прогресс каждую секунду
                    current_time = time.time()
                    if current_time - last_progress_time >= 1.0:
                        progress = (frames_read / (end_frame - start_frame)) * 100
                        fps = frames_read / (current_time - start_time)
                        print(f"[Worker {rank}] Прогресс: {progress:.1f}% ({frames_read}/{end_frame - start_frame} кадров), {fps:.1f} fps")
                        last_progress_time = current_time
                
                total_time = time.time() - start_time
                avg_fps = frames_read / total_time
                print(f"[Worker {rank}] Завершено. Среднее FPS: {avg_fps:.1f}")
                
            finally:
                if 'cap' in locals():
                    cap.release()
                print(f"[Worker {rank}] Завершено")
    
    except Exception as e:
        print(f"[Process {rank}] Ошибка: {str(e)}")
        comm.Abort(1)

def main():
    if len(sys.argv) != 3:
        print("Использование: mpiexec -n <num_processes> python laplace_filter_cpu_mpi.py input_video.mp4 output_video.mp4")
        sys.exit(1)
    
    input_path = Path(sys.argv[1])
    output_path = Path(sys.argv[2])
    
    start_time = time.time()
    process_video_mpi(input_path, output_path)
    end_time = time.time()
    
    if MPI.COMM_WORLD.Get_rank() == 0:
        print(f"\nВремя выполнения (CPU): {end_time - start_time:.2f} секунд")

if __name__ == "__main__":
    main() 