#!/bin/bash

echo "=== Запуск GPU EVDEC/EVENC версии ==="
mpiexec --hostfile /etc/hostfile python3 /app/laplace_filter_cuda_mpi_ev.py /app/input/input.mp4 /app/output/output_gpu_ev.mp4

echo -e "\n=== Запуск CPU версии ==="
mpiexec --hostfile /etc/hostfile python3 /app/laplace_filter_cpu_mpi.py /app/input/input.mp4 /app/output/output_cpu.mp4 
