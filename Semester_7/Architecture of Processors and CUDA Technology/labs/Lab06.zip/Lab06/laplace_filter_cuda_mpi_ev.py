import cv2
import numpy as np
import sys
import time
from pathlib import Path
import subprocess
from mpi4py import MPI
import pycuda.driver as cuda
import pycuda.autoinit
from pycuda.compiler import SourceModule

def debug_cuda_env():
    print("=== Debug CUDA Environment ===")
    import os
    import subprocess
    import sys
    
    print(f"Process rank: {MPI.COMM_WORLD.Get_rank()}")
    print(f"Hostname: {MPI.Get_processor_name()}")
    print(f"Python executable: {sys.executable}")
    print(f"Working directory: {os.getcwd()}")
    print(f"PATH: {os.environ.get('PATH')}")
    print(f"LD_LIBRARY_PATH: {os.environ.get('LD_LIBRARY_PATH')}")
    print(f"CUDA_HOME: {os.environ.get('CUDA_HOME')}")
    
    try:
        nvcc_path = subprocess.check_output(['which', 'nvcc']).decode().strip()
        print(f"nvcc path: {nvcc_path}")
        nvcc_version = subprocess.check_output(['nvcc', '--version']).decode()
        print(f"nvcc version:\n{nvcc_version}")
    except Exception as e:
        print(f"Error checking nvcc: {str(e)}")
    
    try:
        import pycuda
        print(f"PyCUDA version: {pycuda.VERSION}")
        print(f"PyCUDA path: {pycuda.__file__}")
    except Exception as e:
        print(f"Error importing PyCUDA: {str(e)}")
    
    print("=== End Debug ===\n") 

def init_cuda():
    # Инициализация CUDA
    cuda.init()
    # Выбираем первое доступное устройство
    dev = cuda.Device(0)
    # Создаем контекст
    ctx = dev.make_context()
    return ctx

def cleanup_cuda(ctx):
    # Очищаем контекст CUDA
    ctx.pop()

def apply_laplace_filter_cuda(frame):
    # Установка переменных окружения для PyCUDA
    import os
    os.environ['PATH'] = '/usr/local/cuda/bin:' + os.environ.get('PATH', '')
    os.environ['LD_LIBRARY_PATH'] = '/usr/local/cuda/lib64:' + os.environ.get('LD_LIBRARY_PATH', '')
    os.environ['CUDA_HOME'] = '/usr/local/cuda'
    os.environ['PYCUDA_NVCC_PATH'] = '/usr/local/cuda/bin/nvcc'
    
    # Добавляем логи о размерах обрабатываемого кадра
    height, width = frame.shape[:2]
    print(f"Обработка кадра размером {width}x{height}")
    
    # CUDA kernel для фильтра Лапласа
    kernel_code = """
    __global__ void laplace_filter(unsigned char *input, unsigned char *output, int width, int height)
    {
        int idx = blockIdx.x * blockDim.x + threadIdx.x;
        int idy = blockIdx.y * blockDim.y + threadIdx.y;
        
        if (idx < width && idy < height) {
            int pos = idy * width + idx;
            float sum = 0.0f;
            
            // Ядро фильтра Лапласа
            if (idx > 0 && idx < width-1 && idy > 0 && idy < height-1) {
                sum += input[pos - width - 1];
                sum += input[pos - width];
                sum += input[pos - width + 1];
                sum += input[pos - 1];
                sum -= 8 * input[pos];
                sum += input[pos + 1];
                sum += input[pos + width - 1];
                sum += input[pos + width];
                sum += input[pos + width + 1];
                
                // Нормализация и усиление контраста
                float normalized = sum / 255.0f;
                float enhanced = (normalized >= 0) ? 
                    pow(normalized, 0.5f) : -pow(-normalized, 0.5f);
                output[pos] = (unsigned char)((enhanced * 127.5f + 127.5f));
            }
        }
    }
    """
    
    # Преобразуем кадр в оттенки серого
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    # Компилируем CUDA kernel
    mod = SourceModule(kernel_code)
    laplace_filter_kernel = mod.get_function("laplace_filter")
    
    # Подготавливаем данные для GPU
    input_gpu = cuda.mem_alloc(gray.nbytes)
    output_gpu = cuda.mem_alloc(gray.nbytes)
    cuda.memcpy_htod(input_gpu, gray)
    
    # Запускаем kernel
    block_size = (16, 16, 1)
    grid_size = ((gray.shape[1] + block_size[0] - 1) // block_size[0],
                 (gray.shape[0] + block_size[1] - 1) // block_size[1])
    
    laplace_filter_kernel(input_gpu, output_gpu, np.int32(gray.shape[1]), np.int32(gray.shape[0]),
                         block=block_size, grid=grid_size)
    
    # Получаем результат
    output = np.empty_like(gray)
    cuda.memcpy_dtoh(output, output_gpu)
    
    # Применяем дополнительное усиление контраста
    output = cv2.equalizeHist(output)
    
    # Преобразуем обратно в BGR
    return cv2.cvtColor(output, cv2.COLOR_GRAY2BGR)

def init_video_capture(input_path):
    """Инициализация захвата видео и получение параметров"""
    cap = cv2.VideoCapture(str(input_path))
    if not cap.isOpened():
        raise Exception(f"Не удалось открыть видео: {input_path}")
    
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = int(cap.get(cv2.CAP_PROP_FPS))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    
    if width <= 0 or height <= 0 or fps <= 0 or total_frames <= 0:
        raise Exception("Некорректные параметры видео")
        
    return cap, (width, height, fps, total_frames)

def distribute_work(size, total_frames):
    """Распределение работы между процессами"""
    workers = size - 3
    frames_per_worker = total_frames // workers
    remaining_frames = total_frames % workers
    
    work_distribution = []
    for worker in range(3, size):
        start_frame = (worker - 3) * frames_per_worker
        end_frame = start_frame + frames_per_worker
        if worker == size - 1:
            end_frame += remaining_frames
        work_distribution.append((worker, start_frame, end_frame))
        
    return work_distribution

def print_progress(current, total, start_time, prefix=""):
    """Вывод прогресса обработки"""
    progress = (current / total) * 100
    current_time = time.time()
    fps = current / (current_time - start_time)
    print(f"{prefix} Прогресс: {progress:.1f}% ({current}/{total} кадров), {fps:.1f} fps")

def master_process(comm, size, input_path, video_params):
    """Логика мастер-процесса"""
    width, height, fps, total_frames = video_params
    
    # Отправка параметров видео
    for dest in [1, 2]:  # декодер и энкодер
        comm.send(video_params, dest=dest, tag=10)
        if not comm.recv(source=dest, tag=11):
            raise Exception("Декодер или энкодер не готовы к работе")
    
    # Распределение работы
    work_distribution = distribute_work(size, total_frames)
    for worker, start_frame, end_frame in work_distribution:
        comm.send((start_frame, end_frame), dest=worker, tag=0)
        print(f"[Master] Отправлено задание процессу {worker}: кадры {start_frame}-{end_frame}")
    
    # Координация обработки
    frames_processed = 0
    last_progress_time = time.time()
    start_time = time.time()
    
    while frames_processed < total_frames:
        frame_data = comm.recv(source=MPI.ANY_SOURCE, tag=1)
        frame_idx, processed_frame = frame_data
        
        comm.send((frame_idx, processed_frame), dest=2, tag=2)
        frames_processed += 1
        
        if time.time() - last_progress_time >= 1.0:
            print_progress(frames_processed, total_frames, start_time, "[Master]")
            last_progress_time = time.time()
    
    # Завершение работы
    comm.send(("END", None), dest=2, tag=2)
    print_final_stats(frames_processed, start_time, "[Master]")

def decoder_process(comm, size, input_path, video_params):
    """Логика процесса-декодера"""
    width, height, fps, total_frames = video_params
    comm.send(True, dest=0, tag=11)
    
    cap = cv2.VideoCapture(str(input_path))
    if not cap.isOpened():
        raise Exception("Не удалось открыть видео для декодирования")
    
    try:
        process_frames_decoder(comm, cap, size, total_frames)
    finally:
        cap.release()
        print("[Decoder] Ресурсы освобождены")

def process_frames_decoder(comm, cap, size, total_frames):
    """Обработка кадров в декодере"""
    frame_idx = 0
    workers = size - 3
    start_time = time.time()
    last_progress_time = time.time()
    
    while frame_idx < total_frames:
        ret, frame = cap.read()
        if not ret:
            break
            
        worker = 3 + (frame_idx % workers)
        comm.send((frame_idx, frame), dest=worker, tag=3)
        frame_idx += 1
        
        if time.time() - last_progress_time >= 1.0:
            print_progress(frame_idx, total_frames, start_time, "[Decoder]")
            last_progress_time = time.time()
    
    # Отправка сигналов завершения
    for worker in range(3, size):
        comm.send(("END", None), dest=worker, tag=3)
    print_final_stats(frame_idx, start_time, "[Decoder]")

def encoder_process(comm, output_path, video_params):
    """Логика процесса-энкодера"""
    width, height, fps, total_frames = video_params
    comm.send(True, dest=0, tag=11)
    
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(str(output_path), fourcc, fps, (width, height))
    
    try:
        process_frames_encoder(comm, out, total_frames)
    finally:
        out.release()
        print("[Encoder] Ресурсы освобождены")

def process_frames_encoder(comm, out, total_frames):
    """Обработка кадров в энкодере"""
    frame_buffer = {}
    next_frame_to_write = 0
    frames_received = 0
    start_time = time.time()
    last_progress_time = time.time()
    
    while True:
        frame_idx, processed_frame = comm.recv(source=0, tag=2)
        
        if frame_idx == "END":
            break
            
        frame_buffer[frame_idx] = processed_frame
        frames_received += 1
        
        while next_frame_to_write in frame_buffer:
            out.write(frame_buffer[next_frame_to_write])
            del frame_buffer[next_frame_to_write]
            next_frame_to_write += 1
        
        if time.time() - last_progress_time >= 1.0:
            print_progress(frames_received, total_frames, start_time, "[Encoder]")
            last_progress_time = time.time()
    
    print_final_stats(frames_received, start_time, "[Encoder]")

def worker_process(comm, rank):
    """Логика рабочего процесса"""
    ctx = init_cuda()
    try:
        process_frames_worker(comm, rank)
    finally:
        cleanup_cuda(ctx)
        print(f"[Worker {rank}] Ресурсы освобождены")

def process_frames_worker(comm, rank):
    """Обработка кадров в рабочем процессе"""
    frames_processed = 0
    start_time = time.time()
    last_progress_time = time.time()
    
    while True:
        frame_idx, frame = comm.recv(source=1, tag=3)
        
        if frame_idx == "END":
            break
            
        processed_frame = apply_laplace_filter_cuda(frame)
        comm.send((frame_idx, processed_frame), dest=0, tag=1)
        frames_processed += 1
        
        if time.time() - last_progress_time >= 1.0:
            fps = frames_processed / (time.time() - start_time)
            print(f"[Worker {rank}] Обработано кадров: {frames_processed}, {fps:.1f} fps")
            last_progress_time = time.time()
    
    print_final_stats(frames_processed, start_time, f"[Worker {rank}]")

def print_final_stats(frames_processed, start_time, prefix):
    """Вывод финальной статистики"""
    total_time = time.time() - start_time
    avg_fps = frames_processed / total_time
    print(f"{prefix} Завершено. Обработано {frames_processed} кадров. "
          f"Общее время: {total_time:.1f} сек, среднее FPS: {avg_fps:.1f}")

def process_video_mpi(input_path: Path, output_path: Path):
    """Основная функция обработки видео с MPI"""
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()
    
    if size < 4:
        raise Exception("Необходимо минимум 4 процесса")
    
    try:
        if rank == 0:
            cap, video_params = init_video_capture(input_path)
            try:
                master_process(comm, size, input_path, video_params)
            finally:
                cap.release()
        elif rank == 1:
            video_params = comm.recv(source=0, tag=10)
            decoder_process(comm, size, input_path, video_params)
        elif rank == 2:
            video_params = comm.recv(source=0, tag=10)
            encoder_process(comm, output_path, video_params)
        else:
            worker_process(comm, rank)
    
    except Exception as e:
        print(f"[Process {rank}] Критическая ошибка: {str(e)}")
        comm.Abort(1)

def main():
    check_gpu()
    if len(sys.argv) != 3:
        print("Использование: mpiexec -n <num_processes> python laplace_filter_cuda_mpi.py input_video.mp4 output_video.mp4")
        sys.exit(1)
    
    input_path = Path(sys.argv[1])
    output_path = Path(sys.argv[2])
    
    process_video_mpi(input_path, output_path)

def check_gpu():
    try:
        import pycuda.autoinit
        import pycuda.driver as cuda
        
        print(f"CUDA version: {cuda.get_version()}")
        print(f"Available GPU devices: {cuda.Device.count()}")
        
        device = cuda.Device(0)
        print(f"Using GPU: {device.name()}")
        print(f"Compute Capability: {device.compute_capability()}")
        print(f"Total Memory: {device.total_memory() / (1024*1024):.2f} MB")
        
        # Проверка доступной памяти
        free, total = cuda.mem_get_info()
        print(f"Free Memory: {free / (1024*1024):.2f} MB")
        print(f"Memory Usage: {(total-free) / (1024*1024):.2f} MB")
        
        # Проверка характеристик устройства
        attrs = device.get_attributes()
        print("\nDevice Attributes:")
        print(f"Max Threads per Block: {attrs[cuda.device_attribute.MAX_THREADS_PER_BLOCK]}")
        print(f"Max Block Dimensions: {attrs[cuda.device_attribute.MAX_BLOCK_DIM_X]}, "
              f"{attrs[cuda.device_attribute.MAX_BLOCK_DIM_Y]}, "
              f"{attrs[cuda.device_attribute.MAX_BLOCK_DIM_Z]}")
        
    except Exception as e:
        print(f"Error checking GPU: {str(e)}")
        raise

if __name__ == "__main__":
    main() 