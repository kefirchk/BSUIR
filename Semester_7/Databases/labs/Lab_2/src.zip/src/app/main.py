from app.database import Database
from app.gui import MainWindow


def main():
    database = Database()
    app = MainWindow(database)
    app.mainloop()


if __name__ == "__main__":
    main()
