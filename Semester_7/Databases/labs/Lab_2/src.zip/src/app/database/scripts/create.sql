-- Удаление таблиц, если они уже существуют
DROP TABLE IF EXISTS public.student_subject CASCADE;
DROP TABLE IF EXISTS public.class_teacher CASCADE;
DROP TABLE IF EXISTS public.student CASCADE;
DROP TABLE IF EXISTS public.teacher CASCADE;
DROP TABLE IF EXISTS public.class CASCADE;
DROP TABLE IF EXISTS public.subject CASCADE;

-- Таблица для хранения предметов
CREATE TABLE public.subject (
    id SERIAL PRIMARY KEY,
    subject_name VARCHAR NOT NULL UNIQUE
);

-- Таблица для хранения классов
CREATE TABLE public.class (
    id SERIAL PRIMARY KEY,
    class_name VARCHAR NOT NULL UNIQUE,
    class_teacher_id INTEGER
);

-- Таблица для хранения учителей
CREATE TABLE public.teacher (
    id SERIAL PRIMARY KEY,
    first_name VARCHAR NOT NULL,
    last_name VARCHAR NOT NULL,
    age INTEGER NOT NULL,
    phone_no VARCHAR NOT NULL UNIQUE,
    gender_type VARCHAR NOT NULL,
    subject_id INTEGER NOT NULL
);

-- Таблица для хранения студентов
CREATE TABLE public.student (
    id SERIAL PRIMARY KEY,
    first_name VARCHAR NOT NULL,
    last_name VARCHAR NOT NULL,
    gender_type VARCHAR NOT NULL,
    class_id INTEGER NOT NULL,
    email VARCHAR NOT NULL UNIQUE
);

-- Таблица для связи студентов с предметами (многие ко многим)
CREATE TABLE public.student_subject (
    student_id INTEGER NOT NULL,
    subject_id INTEGER NOT NULL,
    PRIMARY KEY (student_id, subject_id)
);

-- Таблица для связи классов с учителями (многие ко многим)
CREATE TABLE public.class_teacher (
    class_id INTEGER NOT NULL,
    teacher_id INTEGER NOT NULL,
    PRIMARY KEY (class_id, teacher_id)
);

-- Добавление внешних ключей после создания таблиц
ALTER TABLE public.class
    ADD CONSTRAINT fk_teacher FOREIGN KEY (class_teacher_id) REFERENCES public.teacher (id)
    ON UPDATE CASCADE ON DELETE SET NULL;

ALTER TABLE public.teacher
    ADD CONSTRAINT fk_subject_teacher FOREIGN KEY (subject_id) REFERENCES public.subject (id)
    ON UPDATE CASCADE ON DELETE CASCADE;

ALTER TABLE public.student
    ADD CONSTRAINT fk_class FOREIGN KEY (class_id) REFERENCES public.class (id)
    ON UPDATE CASCADE ON DELETE CASCADE;

ALTER TABLE public.student_subject
    ADD CONSTRAINT fk_student FOREIGN KEY (student_id) REFERENCES public.student (id)
    ON DELETE CASCADE,
    ADD CONSTRAINT fk_subject FOREIGN KEY (subject_id) REFERENCES public.subject (id)
    ON DELETE CASCADE;

ALTER TABLE public.class_teacher
    ADD CONSTRAINT fk_class_teacher FOREIGN KEY (class_id) REFERENCES public.class (id)
    ON DELETE CASCADE,
    ADD CONSTRAINT fk_teacher_class FOREIGN KEY (teacher_id) REFERENCES public.teacher (id)
    ON DELETE CASCADE;
