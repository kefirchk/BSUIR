import sys
from contextlib import contextmanager

import psycopg2
from sqlalchemy import create_engine
from sqlalchemy.exc import NoResultFound
from sqlalchemy.orm import sessionmaker

from app.logger import logger
from app.database import Base, TABLE_MODEL_MAP
from app.configs import db_settings


class Database:
    def __init__(self):
        self.connection = psycopg2.connect(
            host=db_settings.DB_HOST,
            user=db_settings.DB_USER,
            password=db_settings.DB_PASS,
            database=db_settings.DB_NAME
        )
        self.connection.autocommit = True

        self.engine = create_engine(db_settings.DATABASE_URL, echo=False)
        self.Session = sessionmaker(bind=self.engine)

        # Создаем таблицы, если их нет
        Base.metadata.create_all(self.engine)

        logger.info("Соединение с PostgreSQL установлено")

    def __del__(self):
        self.connection.close()
        logger.info("Соединение с PostgreSQL закрыто")

    @contextmanager
    def get_session(self):
        session = self.Session()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            raise
        finally:
            session.close()

    def get_table(self, table_name: str):
        model, schema = TABLE_MODEL_MAP.get(table_name)
        if model:
            with self.get_session() as session:
                table_orm_list = session.query(model).all()
                table = []
                logger.info(f"Таблица {table_name}:")
                for table_orm in table_orm_list:
                    logger.info(schema.from_orm(table_orm))
                    table.append(schema.from_orm(table_orm))

                return table
        else:
            logger.error(f"Таблица {table_name} не найдена")
            sys.exit(1)

    def get_first_row(self, table_name: str):
        """Получает первую строку из таблицы по названию."""
        model, schema = TABLE_MODEL_MAP.get(table_name)
        try:
            with self.get_session() as session:
                first_row_orm = session.query(model).first()
                return schema.from_orm(first_row_orm)
        except NoResultFound:
            return None

    def get_tables(self):
        with self.connection.cursor() as cursor:
            # Выполняем SQL-запрос для получения списка таблиц
            cursor.execute("""
                SELECT table_name 
                FROM information_schema.tables
                WHERE table_schema = 'public'
            """)
            tables = cursor.fetchall()
            table_names = [table[0] for table in tables]

            return table_names

    def execute_query(self, query: str):
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(query)
                rows = None
                column_names = None
                if query.lower().startswith('select'):
                    rows = cursor.fetchall()
                    column_names = [desc[0] for desc in cursor.description]
                logger.info(f"Запрос успешно выполнен")
                return {
                    "status": True,
                    "rows": rows,
                    "column_names": column_names,
                    "error": None
                }
        except Exception as e:
            logger.error(f"Запрос не выполнен: {e}")
            return {
                "status": False,
                "rows": None,
                "column_names": None,
                "error": e
            }

    def get_table_fields(self, table_name: str):
        """Возвращает метаданные полей таблицы."""
        table = self.get_table(table_name)
        return table[0].__fields__
