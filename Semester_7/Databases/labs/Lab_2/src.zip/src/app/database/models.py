from sqlalchemy import Integer, String, Enum as SQLAlchemyEnum, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship, DeclarativeBase

from app.schemas import GenderType, StudentWithRelations, SubjectWithRelations, TeacherWithRelations, ClassWithRelations


class Base(DeclarativeBase):
    pass


class SubjectOrm(Base):
    __tablename__ = "subject"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    subject_name: Mapped[str] = mapped_column(String, nullable=False, unique=True)

    # Отношение многие ко многим с таблицей StudentOrm через StudentSubjectOrm
    students = relationship(
        "StudentOrm",
        secondary="student_subject",
        back_populates="subjects",
        lazy="selectin"
    )
    teachers = relationship(
        "TeacherOrm",
        back_populates="subject",
        cascade="all, delete-orphan",
        lazy="joined"
    )

    def __repr__(self):
        return f"<SubjectOrm(id={self.id}, subject_name={self.subject_name})>"


class StudentOrm(Base):
    __tablename__ = "student"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    first_name: Mapped[str] = mapped_column(String, nullable=False)
    last_name: Mapped[str] = mapped_column(String, nullable=False)
    gender_type: Mapped[GenderType] = mapped_column(SQLAlchemyEnum(GenderType), nullable=False)
    email: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    class_id: Mapped[int] = mapped_column(ForeignKey('class.id', onupdate="CASCADE", ondelete="CASCADE"), nullable=False)

    subjects = relationship(
        "SubjectOrm",
        secondary="student_subject",
        back_populates="students",
        cascade="save-update, merge",
        lazy="selectin"
    )

    class_ = relationship(
        "ClassOrm",
        back_populates="students",
        lazy="joined"
    )

    def __repr__(self):
        return (f"<StudentOrm(id={self.id}, first_name={self.first_name}, last_name={self.last_name}, "
                f"gender_type={self.gender_type}, class_id={self.class_id})>")


class StudentSubjectOrm(Base):
    __tablename__ = "student_subject"

    student_id: Mapped[int] = mapped_column(ForeignKey('student.id', ondelete="CASCADE"), primary_key=True, nullable=False)
    subject_id: Mapped[int] = mapped_column(ForeignKey('subject.id', ondelete="CASCADE"), primary_key=True, nullable=False)

    def __repr__(self):
        return f"<StudentSubjectOrm(student_id={self.student_id}, subject_id={self.subject_id})>"


class ClassOrm(Base):
    __tablename__ = "class"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    class_name: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    class_teacher_id: Mapped[int] = mapped_column(ForeignKey('teacher.id', onupdate="CASCADE", ondelete="SET NULL"), nullable=False)

    students = relationship(
        "StudentOrm",
        back_populates="class_",
        cascade="all, delete-orphan",
        lazy="selectin"
    )

    teacher = relationship(
        "TeacherOrm",
        back_populates="class_",
        uselist=False,
        lazy="joined"
    )

    def __repr__(self):
        return f"<ClassOrm(id={self.id}, class_name={self.class_name}, class_teacher_id={self.class_teacher_id})>"


class TeacherOrm(Base):
    __tablename__ = "teacher"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    first_name: Mapped[str] = mapped_column(String, nullable=False)
    last_name: Mapped[str] = mapped_column(String, nullable=False)
    age: Mapped[int] = mapped_column(Integer, nullable=False)
    phone_no: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    gender_type: Mapped[GenderType] = mapped_column(SQLAlchemyEnum(GenderType), nullable=False)
    subject_id: Mapped[int] = mapped_column(ForeignKey('subject.id', onupdate="CASCADE", ondelete="CASCADE"), nullable=False)

    class_ = relationship(
        "ClassOrm",
        back_populates="teacher",
        uselist=False,
        lazy="joined"
    )

    subject = relationship(
        "SubjectOrm",
        back_populates="teachers",
        lazy="joined"
    )

    def __repr__(self):
        return (f"<TeacherOrm(id={self.id}, first_name={self.first_name}, last_name={self.last_name}, "
                f"age={self.age}, phone_no={self.phone_no}, gender_type={self.gender_type}, subject_id={self.subject_id})>")


class ClassTeacherOrm(Base):
    __tablename__ = "class_teacher"

    class_id: Mapped[int] = mapped_column(ForeignKey('class.id', ondelete="CASCADE"), primary_key=True, nullable=False)
    teacher_id: Mapped[int] = mapped_column(ForeignKey('teacher.id', ondelete="CASCADE"), primary_key=True, nullable=False)

    class_ = relationship("ClassOrm", lazy="selectin")
    teacher = relationship("TeacherOrm", lazy="selectin")

    def __repr__(self):
        return f"<ClassTeacherOrm(class_id={self.class_id}, teacher_id={self.teacher_id})>"


# Маппинг имен таблиц на соответствующие модели
TABLE_MODEL_MAP = {
    'student': (StudentOrm, StudentWithRelations),
    'subject': (SubjectOrm, SubjectWithRelations),
    'teacher': (TeacherOrm, TeacherWithRelations),
    'class': (ClassOrm, ClassWithRelations)
}
