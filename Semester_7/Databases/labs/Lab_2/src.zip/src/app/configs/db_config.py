from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class DBConfig(BaseSettings):
    DB_HOST: str
    DB_PORT: str
    DB_PASS: str
    DB_USER: str
    DB_NAME: str
    DB_DRIVER: str = Field("postgresql")
    DB_SCHEMA: str = Field("public")
    EXCLUDE_TABLES: list = ["alembic_version", "student_subject", "class_teacher"]

    # Поля, которые не нужно отображать в таблицах
    EXCLUDED_FIELDS: dict = {
        'student': ("id", "class_id", "subjects", "class_"),
        'subject': ("id", "students", "teachers"),
        'teacher': ("id", "subject_id", "class_", "subject"),
        'class': ("id", "class_teacher_id", "students", "teacher")
    }

    # Определяем соответствие моделей и их ключевых полей для поиска
    RELATED_FIELD_MAP: dict = {
        'student': {'field': 'email', 'relation': 'students'},
        'subject': {'field': 'subject_name', 'relation': 'subjects'},
        'class': {'field': 'class_name', 'relation': 'class_'},
        'teacher': {'field': 'phone_no', 'relation': 'teacher'}
    }

    @property
    def DATABASE_URL(self):
        return f'{self.DB_DRIVER}://{self.DB_USER}:{self.DB_PASS}@{self.DB_HOST}:{self.DB_PORT}/{self.DB_NAME}'

    model_config = SettingsConfigDict(env_file='_envs/.env-db')


db_settings = DBConfig()
