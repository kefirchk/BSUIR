from pydantic import BaseModel, Field
from typing import List, Optional
from app.schemas import GenderType


class SubjectBase(BaseModel):
    id: int = Field(default=0)
    subject_name: str = Field(default="")

    class Config:
        from_attributes = True


class StudentBase(BaseModel):
    id: int = Field(default=0)
    first_name: str = Field(default="")
    last_name: str = Field(default="")
    gender_type: GenderType = Field(default=GenderType.MALE)
    email: str = Field(default="")
    class_id: int = Field(default=0)

    class Config:
        from_attributes = True


class StudentSubjectBase(BaseModel):
    student_id: int = Field(default=0)
    subject_id: int = Field(default=0)

    class Config:
        from_attributes = True


class ClassBase(BaseModel):
    id: int = Field(default=0)
    class_name: str = Field(default="")
    class_teacher_id: Optional[int] = None

    class Config:
        from_attributes = True


class TeacherBase(BaseModel):
    id: int = Field(default=0)
    first_name: str = Field(default="")
    last_name: str = Field(default="")
    age: int = Field(default=0)
    phone_no: str = Field(default="")
    gender_type: GenderType = Field(default=GenderType.MALE)
    subject_id: int = Field(default=0)

    class Config:
        from_attributes = True


class ClassTeacherBase(BaseModel):
    class_id: int = Field(default=0)
    teacher_id: int = Field(default=0)

    class Config:
        from_attributes = True


# Расширенные модели, включающие отношения
class SubjectWithRelations(SubjectBase):
    students: List[StudentBase] = []
    teachers: List[TeacherBase] = []

    class Config:
        from_attributes = True


class StudentWithRelations(StudentBase):
    subjects: List[SubjectBase] = []
    class_: ClassBase

    class Config:
        from_attributes = True


class ClassWithRelations(ClassBase):
    students: List[StudentBase] = []
    teacher: TeacherBase | None


class TeacherWithRelations(TeacherBase):
    class_: ClassBase | None
    subject: SubjectBase
