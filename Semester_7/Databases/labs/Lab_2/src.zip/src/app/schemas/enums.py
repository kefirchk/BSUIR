from enum import Enum


class DBCommandType(str, Enum):
    UPDATE = "UPDATE",
    DELETE = "DELETE",
    INSERT = "INSERT",
    TRUNCATE = "TRUNCATE"


class GenderType(str, Enum):
    MALE = "MALE",
    FEMALE = "FEMALE"
