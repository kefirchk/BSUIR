from enum import Enum
from tkinter import ttk, messagebox, Tk, FALSE, Menu, RIGHT, BOTTOM, Y, X, Toplevel, BOTH, StringVar, NW
from tkinter.font import Font
from tkinter.ttk import Label

from pydantic import BaseModel

from app.gui import EditWindow
from app.logger import logger
from app.database import Database
from app.configs import db_settings


class TableWindow(Tk):
    def __init__(self, parent_window, table_name: str, db: Database):
        super().__init__()

        self.db = db
        self.table_name = table_name
        self.table = self.db.get_table(table_name)
        self.id_mapping = {}  # Соответсвие id в таблице БД с id в таблице виджета TreeView
        self.main_window = parent_window  # Ссылка на главное окно

        self.title(table_name)
        self.option_add("*tearOff", FALSE)
        self.geometry("600x500")
        self.resizable(False, False)

        # Вызов методов для создания меню и таблицы
        self.create_menu()
        self.create_search()
        self.create_table(self.table)

        self.bind("<Control-Tab>", self.main_window.switch_focus_to_next_window)
        self.bind("<Control-e>", lambda event: self.edit_menu.post(self.winfo_rootx(), self.winfo_rooty()))
        self.bind("<Control-t>", self.focus_table)
        self.bind("<Escape>", self.close_window)

    def close_window(self, event=None):
        """Удаление окна и обновление списка окон в главном окне."""
        self.main_window.table_windows.remove(self)
        self.destroy()

    def on_search_key_release(self, event=None):
        search_query = self.search_entry.get().lower()

        # Сначала чистим всю таблицу
        for item in self.table_widget.get_children():
            self.table_widget.delete(item)

        i = 0
        # Добавление данных в основной виджет
        for record in self.table:
            row_data = []
            possible_row_data = []
            text_in_search = False
            for field_name in self.columns:
                value = getattr(record, field_name)
                if isinstance(value, Enum):
                    value = value.value
                if search_query in value.lower():
                    text_in_search = True
                possible_row_data.append(value)
            if text_in_search:
                self.id_mapping[i] = record.id
                i += 1
                row_data = possible_row_data
                tags = ('evenrow',) if i % 2 == 0 else ('oddrow',)
                self.table_widget.insert('', 'end', values=row_data, tags=tags)

    def create_search(self):
        self.search_entry = ttk.Entry(self, textvariable=StringVar(), width=95)
        self.search_entry.bind("<KeyRelease>", self.on_search_key_release)
        self.search_entry.pack(anchor=NW, pady=10, padx=5)

    def create_menu(self):
        """Создает меню редактирования таблицы."""
        table_menu = Menu(self)
        self.edit_menu = Menu(self)
        self.edit_menu.add_command(label="Insert", command=lambda: self.open_edit_window("INSERT"))
        self.edit_menu.add_command(label="Delete", command=self.delete_selected_row)
        self.edit_menu.add_command(label="Update", command=self.update_selected_row)
        table_menu.add_cascade(label="Edit", menu=self.edit_menu)
        self.config(menu=table_menu)

    def create_table(self, table):
        """Создает таблицу и заполняет ее данными с подстройкой ширины столбцов и вертикальными разделителями."""
        style = ttk.Style(self)
        style.configure("Treeview", rowheight=25, borderwidth=1)
        style.configure("Treeview.Heading", borderwidth=1)

        self.columns = []  # Основные колонки для текущей таблицы
        excluded_columns = []  # Колонки, которые исключены и будут отображены в отдельных окнах

        # Определение основных и исключенных колонок
        for field_name in table[0].__fields__.keys():
            if field_name in db_settings.EXCLUDED_FIELDS[self.table_name]:
                excluded_columns.append(field_name)
            else:
                self.columns.append(field_name)

        # Создание основного Treeview
        self.table_widget = ttk.Treeview(self, selectmode='browse', columns=self.columns, show="headings", height=20, style="Treeview")
        table_yscrollbar = ttk.Scrollbar(self, orient="vertical", command=self.table_widget.yview)
        table_xscrollbar = ttk.Scrollbar(self, orient="horizontal", command=self.table_widget.xview)
        table_yscrollbar.pack(side=RIGHT, fill=Y)
        table_xscrollbar.pack(side=BOTTOM, fill=X)
        self.table_widget.configure(yscrollcommand=table_yscrollbar.set, xscrollcommand=table_xscrollbar.set)

        if not table:
            label = Label(self, text="No data in the table")
            label.pack()
        else:
            # Настройка колонок в основном виджете
            for col_name in self.columns:
                self.table_widget.heading(col_name, text=col_name)
                max_content_width = max(Font().measure(col_name), Font().measure(str(getattr(table[0], col_name))))
                self.table_widget.column(col_name, width=max_content_width + 20, stretch=True)

            # Добавление данных в основной виджет
            for i, record in enumerate(table):
                self.id_mapping[i] = record.id

                # Обработка значений для отображения
                row_data = []
                for field_name in self.columns:
                    value = getattr(record, field_name)
                    if isinstance(value, Enum):
                        row_data.append(value.value)  # Добавляем только значение Enum
                    else:
                        row_data.append(value)  # Добавляем значение без изменений

                tags = ('evenrow',) if i % 2 == 0 else ('oddrow',)
                self.table_widget.insert('', 'end', values=row_data, tags=tags)

        # Чередование цветов строк
        self.table_widget.tag_configure('evenrow', background='#f0f0f0')
        self.table_widget.tag_configure('oddrow', background='#ffffff')

        self.table_widget.bind("<Left>", self.scroll_left)
        self.table_widget.bind("<Right>", self.scroll_right)

        self.table_widget.pack(fill="both")

        # Добавляем обработчик нажатия клавиши Enter
        self.table_widget.bind("<Return>", lambda event: self.on_enter_press(excluded_columns))

    def open_edit_window(self, command, record=None):
        """Открывает окно для добавления/редактирования записи."""
        logger.info(f"Открытие окна редактирования для таблицы '{self.table_name}'")

        edit_window = EditWindow(
            main_window=self.main_window,
            db=self.db,
            table_name=self.table_name,
            command=command,
            db_record=record
        )
        self.main_window.table_windows.append(edit_window)  # Сохраняем ссылку на окно
        edit_window.lift()
        edit_window.focus_force()
        edit_window.mainloop()

    def get_selected_record(self):
        selected_items = self.table_widget.selection()  # Получаем выделенный элемент
        if not selected_items:
            return None, None
        selected_item = selected_items[0]
        widget_record_id = self.table_widget.index(selected_item)
        db_record_id = self.id_mapping[widget_record_id]

        logger.info(f"Номер выделенной строки в TreeView: {widget_record_id}")
        logger.info(f"Номер (id) выделенной строки в БД: {db_record_id}")

        current_record = None
        for record in self.table:
            if db_record_id == record.id:
                current_record = record
                break

        logger.info(f"Запись из БД: {current_record}")

        return current_record, selected_item

    def delete_selected_row(self):
        """Удаляет выделенную строку."""
        record, selected_item = self.get_selected_record()
        if selected_item is None:
            messagebox.showerror("Ошибка", "Пожалуйста, выберите строку для удаления")
        else:
            query = f"""DELETE FROM {db_settings.DB_SCHEMA}.{self.table_name} WHERE id = {record.id};"""
            result = self.db.execute_query(query)
            if result['status']:
                logger.info("Строка успешно удалена!")
                messagebox.showinfo("Информация", "Строка успешно удалена!")
                self.table_widget.delete(selected_item)
            else:
                logger.error(f"Удаление не выполнено.\n{result['error']}")
                messagebox.showerror("Ошибка", f"Удаление не выполнено.\n{result['error']}")

    def update_selected_row(self):
        """Открывает окно для обновления выделенной строки."""
        record, selected_item = self.get_selected_record()
        if selected_item is None:
            messagebox.showerror("Ошибка", "Пожалуйста, выберите строку для обновления")
        else:
            self.open_edit_window("UPDATE", record)

    def focus_table(self, event=None):
        """Фокусировка в таблице на первом элементе."""
        self.table_widget.focus_set()  # Фокус на Treeview
        if self.table_widget.get_children():  # Проверяем, есть ли строки
            first_item = self.table_widget.get_children()[0]  # Получаем первую строку
            self.table_widget.focus(first_item)  # Фокус на первой строке
            self.table_widget.selection_set(first_item)  # Выделяем первую строку

    def scroll_left(self, event):
        """Обработчик скроллинга влево по клавише Left."""
        self.table_widget.xview_scroll(-10, "units")
        return "break"

    def scroll_right(self, event):
        """Обработчик скроллинга вправо по клавише Right."""
        self.table_widget.xview_scroll(10, "units")
        return "break"

    def on_enter_press(self, event):
        """Обрабатывает нажатие клавиши Enter для отображения дополнительной информации."""
        selected_item = self.table_widget.focus()
        if not selected_item:
            return

        selected_index = self.table_widget.index(selected_item)
        selected_record = self.table[selected_index]

        # Проход по полям, указанным в EXCLUDED_FIELDS
        for field_name in db_settings.EXCLUDED_FIELDS[self.table_name]:
            if field_name == "id" or field_name.endswith("_id"):
                continue

            field_value = getattr(selected_record, field_name)

            # Открытие отдельного окна для отображения информации
            if isinstance(field_value, list) and field_value:
                # Если поле — список Pydantic объектов, отображаем несколько строк
                if all(isinstance(item, BaseModel) for item in field_value):
                    self.show_multiple_records_window(field_name, field_value)
            elif isinstance(field_value, BaseModel):
                # Если поле — одиночная Pydantic модель, отображаем одну строку
                self.show_single_record_window(field_name, field_value)
            else:
                # Если это не Pydantic объект, просто выводим как текст
                messagebox.showwarning(f"{field_name} Предупреждение", f"{field_name}: {field_value}")

    def show_multiple_records_window(self, field_name, records):
        """Открывает окно для отображения списка записей (множество Pydantic объектов)."""
        new_window = Toplevel(self)
        new_window.title(f"{field_name} | Details")

        # Получаем список полей без 'id' и полей с суффиксом '_id'
        columns = [field for field in records[0].__fields__.keys() if field != 'id' and not field.endswith('_id')]

        tree = ttk.Treeview(new_window, columns=columns, show="headings")
        tree.pack(fill=BOTH, expand=True)

        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=Font().measure(col) + 20, stretch=True)

        for record in records:
            row_data = [getattr(record, field) for field in columns]
            tree.insert('', 'end', values=row_data)

    def show_single_record_window(self, field_name, record):
        """Открывает окно для отображения одной Pydantic модели (одна запись)."""
        new_window = Toplevel(self)
        new_window.title(f"{field_name} | Details")

        # Получаем список полей без 'id' и полей с суффиксом '_id'
        columns = [field for field in record.__fields__.keys() if field != 'id' and not field.endswith('_id')]

        tree = ttk.Treeview(new_window, columns=columns, show="headings")
        tree.pack(fill=BOTH, expand=True)

        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=Font().measure(col) + 20, stretch=True)

        row_data = [getattr(record, field) for field in columns]
        tree.insert('', 'end', values=row_data)
