from enum import Enum
from tkinter import Tk, Canvas, Scrollbar, messagebox, StringVar, Entry
from tkinter.ttk import Label, Combobox, Button

from pydantic import BaseModel
from sqlalchemy import inspect
from sqlalchemy.orm import Session

from typing import Type

from app.database import Database, TABLE_MODEL_MAP
from app.logger import logger
from app.schemas import (
    DBCommandType, ClassBase, TeacherBase, StudentBase, SubjectBase,
    SubjectWithRelations, StudentWithRelations, TeacherWithRelations
)
from app.configs import db_settings


class EditWindow(Tk):
    def __init__(self, main_window, db: Database, table_name: str, command: str, db_record=None):
        super().__init__()
        self.main_window = main_window
        self.db = db
        self.table_name = table_name
        self.command = command
        self.db_record = db_record  # Значения для обновления (Pydantic модель)
        self.field_counters = {}

        self.title(f"{command} {self.table_name}")
        self.resizable(False, False)

        # Создание Canvas и Scrollbar
        self.canvas = Canvas(self)
        self.canvas.grid(row=0, column=0, sticky='nsew')

        self.scrollbar = Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.scrollbar.grid(row=0, column=1, sticky='ns')

        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        # Создание внутреннего фрейма для размещения элементов ввода
        self.inner_frame = Canvas(self.canvas)
        self.canvas.create_window((0, 0), window=self.inner_frame, anchor='nw')

        # Обновляем геометрию фрейма при изменении размеров
        self.inner_frame.bind("<Configure>", lambda event: self.canvas.configure(scrollregion=self.canvas.bbox("all")))

        self.buttons = []
        self.create_widgets()
        self.focus_button_index = 0
        self.focus_field_index = 0
        self.bind("<Escape>", self.close_window)
        self.bind("<Control-f>", self.focus_on_field)
        self.bind("<Control-b>", self.focus_on_button)
        self.bind("<Control-s>", self.execute_edit)
        self.bind("<Control-Tab>", self.main_window.switch_focus_to_next_window)

        # Привязка Enter к кнопкам
        self.bind("<Return>", self.handle_enter)

        # Обработчик для скроллинга колесиком мыши
        self.bind_all("<MouseWheel>", lambda event: self.canvas.yview_scroll(int(-1 * (event.delta // 120)), "units"))

    def close_window(self, event=None):
        self.main_window.table_windows.remove(self)
        self.destroy()

    def focus_on_field(self, event=None):
        if self.entries:
            if self.focus_field_index == len(self.entries):
                self.focus_field_index = 0
            self.entries[self.focus_field_index].focus_set()
            self.focus_field_index += 1

    def focus_on_button(self, event=None):
        if self.buttons:
            if self.focus_button_index == len(self.buttons):
                self.focus_button_index = 0
            self.buttons[self.focus_button_index].focus_set()
            self.focus_button_index += 1

    def handle_enter(self, event):
        # Проверяем, какой элемент сейчас в фокусе
        widget = self.focus_get()
        if isinstance(widget, Button):
            widget.invoke()  # Срабатывание кнопки

    def create_widgets(self):
        """Создает и размещает виджеты в окне редактирования."""
        self.entries = []
        self.labels = []
        self.row_index = 0  # Индекс для размещения полей
        self.create_fields(self.db_record, indent=0)

        # Кнопка для выполнения операции
        button = Button(self, text=self.command, width=30, command=self.execute_edit)
        button.grid(row=1, column=0, columnspan=2, pady=10)  # Центрируем кнопку
        self.buttons.append(button)

    @staticmethod
    def get_related_table_name(field_type):
        if field_type == ClassBase or field_type == (ClassBase | None):
            return 'class'
        elif field_type == TeacherBase or field_type == (TeacherBase | None) or field_type == TeacherWithRelations:
            return 'teacher'
        elif field_type == StudentBase or field_type == StudentWithRelations:
            return 'student'
        elif field_type == SubjectBase or field_type == SubjectWithRelations:
            return 'subject'
        return None

    def get_related_values(self, table_name):
        """Получает значения для Combobox для указанной таблицы."""
        table = self.db.get_table(table_name)
        values = []
        for obj in table:
            obj_values = []
            field_value_display = obj.dict()[db_settings.RELATED_FIELD_MAP[table_name]['field']]
            obj_values.append(field_value_display)
            values.append(obj_values)
        return values

    def create_fields(self, record, indent=0):
        """Создает поля для текущей записи, включая пустые списки моделей и пустые поля."""
        if self.command == DBCommandType.INSERT and record is None:  # INSERT
            fields = self.db.get_table_fields(self.table_name)
            for field_name, field_info in fields.items():
                if field_name == 'id' or field_name.endswith('_id'):
                    continue
                self.create_field_widget(field_name, field_info.annotation, indent)
        else:  # UPDATE
            for field_name, field_info in record.__fields__.items():
                if field_name == 'id' or field_name.endswith('_id'):
                    continue
                field_value = getattr(record, field_name)
                self.create_field_widget(field_name, field_info.annotation, indent, field_value)

    def add_model_entry(self, field_name, item_type):
        """Добавляет новый объект Pydantic в список."""
        model = item_type()
        table_name = self.get_related_table_name(type(model))
        first_row = self.db.get_first_row(table_name)
        self.create_combobox(field_name, first_row, indent=20)

    def create_field_widget(self, field_name, field_type, indent, field_value=None):
        """Создает виджет для поля."""
        # Проверка на Enum
        if isinstance(field_type, type) and issubclass(field_type, Enum):
            label = Label(self.inner_frame, text=field_name)
            label.grid(row=self.row_index, column=0, sticky="e", padx=indent)

            enum_values = [e.value for e in field_type]  # Получаем значения Enum
            combo_var = StringVar()
            combobox = Combobox(self.inner_frame, textvariable=combo_var, values=enum_values, width=30,
                                state="readonly")
            combobox.grid(row=self.row_index, column=1, pady=5)

            if field_value is not None:
                display_value = field_value.value  # Показываем значение Enum
                combobox.set(display_value)
            elif enum_values:
                combobox.set(enum_values[0])

            self.labels.append(field_name)
            self.entries.append(combobox)
            self.row_index += 1

        # Если поле — список моделей (Pydantic объектов)
        elif hasattr(field_type, '__origin__') and field_type.__origin__ is list:
            item_type = field_type.__args__[0]
            label = Label(self.inner_frame, text=f"{field_name}")
            label.grid(row=self.row_index, column=0, sticky="e", padx=indent)
            add_button = Button(self.inner_frame, text=f"+",
                                command=lambda: self.add_model_entry(field_name, item_type))
            add_button.grid(row=self.row_index, column=1, pady=5)
            self.row_index += 1
            self.buttons.append(add_button)

            # Инициализация списка для хранения Pydantic объектов
            if field_value is not None and isinstance(field_value, list) and all(
                    isinstance(i, BaseModel) for i in field_value):
                for idx, model in enumerate(field_value):
                    self.create_combobox(field_name, model, indent + 20)

        # Если это отдельная Pydantic модель
        elif isinstance(field_value, BaseModel) or issubclass(field_type, BaseModel):
            label = Label(self.inner_frame, text=field_name)
            label.grid(row=self.row_index, column=0, sticky="e", padx=indent)

            table_name = self.get_related_table_name(field_type)
            values = self.get_related_values(table_name)

            combo_var = StringVar()
            combobox = Combobox(self.inner_frame, textvariable=combo_var, values=values, width=30, state="readonly")
            combobox.grid(row=self.row_index, column=1, pady=5)

            if field_value is not None:
                display_value = []
                field_value_display = field_value.dict()[db_settings.RELATED_FIELD_MAP[table_name]['field']]
                display_value.append(field_value_display)
                combobox.set(display_value)  # Устанавливаем текущее значение

            self.labels.append(field_name)
            self.entries.append(combobox)
            self.row_index += 1

        # Если значение None, создаем пустое поле ввода
        elif field_value is None:
            label = Label(self.inner_frame, text=field_name)
            label.grid(row=self.row_index, column=0, sticky="e", padx=indent)

            entry = Entry(self.inner_frame, width=30)
            self.labels.append(field_name)
            self.entries.append(entry)

            entry.grid(row=self.row_index, column=1, pady=5)
            self.row_index += 1

        # В противном случае, создаем поле ввода с текущим значением
        else:
            label = Label(self.inner_frame, text=field_name)
            label.grid(row=self.row_index, column=0, sticky="e", padx=indent)

            entry = Entry(self.inner_frame, width=30)

            if self.command == DBCommandType.UPDATE and self.db_record:
                entry.insert(0, field_value if field_value is not None else "")

            self.labels.append(field_name)
            self.entries.append(entry)

            entry.grid(row=self.row_index, column=1, pady=5)

            self.row_index += 1

    def create_combobox(self, field_name, model, indent):
        """Создает виджет для Pydantic объекта."""
        # Проверяем, есть ли уже счетчик для этого поля
        if field_name not in self.field_counters:
            self.field_counters[field_name] = 0

        # Используем значение счетчика для индекса
        model_label = Label(self.inner_frame, text=f"{field_name}[{self.field_counters[field_name]}]")
        model_label.grid(row=self.row_index, column=0, sticky="e", padx=indent)

        # Получаем возможные значения для этого типа объекта, исключая id и foreign ключи
        table_name = self.get_related_table_name(type(model))
        values = self.get_related_values(table_name)

        combo_var = StringVar()
        combobox = Combobox(self.inner_frame, textvariable=combo_var, values=values, width=30, state="readonly")
        combobox.grid(row=self.row_index, column=1, pady=5)

        display_value = []
        if self.command == DBCommandType.UPDATE:
            # Устанавливаем текущее значение для объекта
            display_value = []
            field_value_display = model.dict()[db_settings.RELATED_FIELD_MAP[table_name]['field']]
            display_value.append(field_value_display)
        elif self.command == DBCommandType.INSERT:
            # Устанавливаем значение первой строки из соответствующей таблицы
            display_value = values[0] if values else []

        combobox.set(display_value)

        # Кнопка удаления Pydantic объекта
        delete_button = Button(self.inner_frame, text="-", command=lambda: self.delete_model_entry(model_label, combobox, delete_button, field_name))
        delete_button.grid(row=self.row_index, column=2, pady=5)

        self.buttons.append(delete_button)
        self.labels.append(f"{field_name}[{self.field_counters[field_name]}]")  # Сохраняем метку с индексом
        self.entries.append(combobox)

        # Увеличиваем счетчик для этого поля
        self.field_counters[field_name] += 1
        self.row_index += 1  # Увеличиваем row_index после добавления нового элемента

    def redistribute_widgets_after_removal(self, start_row):
        """Сдвигает все элементы, находящиеся ниже start_row, на одну строку вверх."""
        for widget in self.inner_frame.grid_slaves():
            row = int(widget.grid_info()["row"])
            if row > start_row:
                widget.grid(row=row - 1, column=widget.grid_info()["column"])
        self.update_idletasks()  # Принудительно обновляем интерфейс

    def delete_model_entry(self, model_label, combobox, delete_button, field_name):
        """Удаляет виджет Pydantic объекта."""
        start_row = model_label.grid_info()["row"]
        label_text = model_label.cget("text")

        self.buttons.remove(delete_button)

        # Теперь безопасно уничтожаем виджеты
        model_label.destroy()
        combobox.destroy()
        delete_button.destroy()

        if label_text in self.labels:
            index = self.labels.index(label_text)
            self.labels.pop(index)
            self.entries.pop(index)

            if field_name in self.field_counters:
                self.field_counters[field_name] -= 1

            # Вызываем перераспределение строк после удаления элемента
            self.redistribute_widgets_after_removal(start_row)

        self.row_index -= 1  # Уменьшаем общий счетчик строк

    def execute_edit(self, event=None):
        """Выполняет вставку или обновление данных в таблице."""
        data = {}
        lists = {}  # Словарь для хранения списков

        for label, entry in zip(self.labels, self.entries):
            value = entry.get()  # Получаем введенные данные
            if value == "":
                value = None  # Заменяем пустые строки на None

            # Проверяем, является ли метка частью списка
            if "[" in label and "]" in label:
                base_label = label.split("[")[0]  # Получаем базовое имя поля
                index = int(label.split("[")[1].rstrip("]"))  # Извлекаем индекс из метки

                # Инициализируем список, если его ещё нет
                if base_label not in lists:
                    lists[base_label] = []

                # Убедимся, что у нас достаточно места в списке
                while len(lists[base_label]) <= index:
                    lists[base_label].append(None)

                lists[base_label][index] = value  # Сохраняем значение в списке
            else:
                data[label] = value  # Сохраняем остальные значения

        # Объединяем списки в общий словарь данных
        for key, values in lists.items():
            data[key] = [item for item in values if item is not None]  # Убираем None значения

        logger.info(f'Выполнение команды {self.command}: {data}')
        orm_model, _ = TABLE_MODEL_MAP[self.table_name]
        try:
            self.update_or_insert(orm_model, data)
            message = "Новая запись успешно добавлена!" if self.command == DBCommandType.INSERT else "Запись успешно обновлена!"
            messagebox.showinfo("Информация", message)
        except Exception as e:
            logger.error(f'Ошибка добавления/обновления записи: {e}')
            messagebox.showerror("Ошибка", "Не удалось добавить/обновить запись. Проверьте корректность введенных данных.")

    def update_or_insert(self, model_class: Type, data: dict):
        with self.db.get_session() as session:
            processed_data, mapper = self.process_data_for_model(session, model_class, data)

            logger.info(f"Новые данные: {processed_data}")

            unique_field_name = db_settings.RELATED_FIELD_MAP[self.table_name]['field']
            instance = session.query(model_class).filter_by(**{unique_field_name: processed_data[unique_field_name]}).first()

            if instance:
                for key, value in processed_data.items():
                    setattr(instance, key, value)
            else:
                instance = model_class(**processed_data)
                session.add(instance)

            session.commit()

    @staticmethod
    def process_data_for_model(session: Session, model_class: Type, data: dict):
        mapper = inspect(model_class)
        processed_data = {}
        relations = {}

        # Обрабатываем каждое поле данных
        for key, value in data.items():
            # Проверяем, является ли поле отношением (ForeignKey или Many-to-Many)
            if key in mapper.relationships:
                relations[key] = value  # Отношения сохраняем отдельно для дальнейшей обработки
            # Если это обычное поле (например, строка, число, перечисление)
            elif key in mapper.columns:
                processed_data[key] = value

        # Обработка отношений
        for relation_name, related_data in relations.items():
            relationship = mapper.relationships[relation_name]
            related_model = relationship.mapper.class_

            # Получаем соответствующее поле для текущей модели
            related_info = db_settings.RELATED_FIELD_MAP.get(related_model.__tablename__)
            if related_info is None:
                raise ValueError(f"Неизвестная модель: {related_model.__tablename__}")

            related_field = related_info['field']

            # Если отношение "многие ко многим"
            if relationship.uselist:
                related_objs = []
                for item in related_data:
                    if isinstance(item, str):
                        related_obj = session.query(related_model).filter(
                            getattr(related_model, related_field) == item).first()
                        if not related_obj:
                            related_obj = related_model(**{related_field: item})
                            session.add(related_obj)
                        related_objs.append(related_obj)
                    else:
                        raise ValueError(f"Неподдерживаемый тип данных для списка: {type(item)}")

                processed_data[relation_name] = related_objs

            # Если это отношение "один ко многим" или "один к одному"
            else:
                if isinstance(related_data, str):
                    related_obj = session.query(related_model).filter(
                        getattr(related_model, related_field) == related_data).first()
                    if not related_obj:
                        related_obj = related_model(**{related_field: related_data})
                        session.add(related_obj)
                elif isinstance(related_data, dict):
                    # Если это словарь, создаем или обновляем вложенный объект
                    related_obj = session.query(related_model).filter_by(**related_data).first()
                    if not related_obj:
                        related_obj = related_model(**related_data)
                        session.add(related_obj)
                else:
                    raise ValueError(f"Неподдерживаемый тип данных для отношения: {type(related_data)}")

                # Присваиваем внешний ключ или сам объект в зависимости от типа отношения
                processed_data[relation_name] = related_obj

        return processed_data, mapper
