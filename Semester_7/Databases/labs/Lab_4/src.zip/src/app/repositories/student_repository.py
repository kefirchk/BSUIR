import hashlib
from typing import Any

from database.exceptions import InvalidDataException
from repositories import BaseRepository
from schemas import StudentBase, Condition, StudentSubjectBase


class StudentRepository(BaseRepository):
    TABLE_NAME = 'student'
    EXCLUDED_FIELDS = ["id", "class_id", "subjects", "class_"]
    INCLUDED_FIELDS = ["first_name", "last_name", "gender_type", "email"]

    def add_one(self, student_id: int, data: dict[str, Any]) -> None:
        from repositories.unit_of_work import UnitOfWork
        uw = UnitOfWork()

        # Ученик с таким email уже существует?
        if self.get_all_by_conditions([Condition(field_name='email', value=data['email'])]):
            raise InvalidDataException("Ученик с данным email уже существует")

        if data.get('subjects'):
            student_subject_repo = uw.get_repository('student_subject')
            subject_repo = uw.get_repository('subject')
            for s_name in data['subjects']:
                subject_id = subject_repo.get_all_by_conditions([
                    Condition(field_name='subject_name', value=s_name)
                ])[0][0]
                bytes = (f"{student_id}{subject_id}").encode()
                obj_id = int(hashlib.sha256(bytes).hexdigest(), 16)
                student_subject_repo.add_one(
                    obj_id,
                    StudentSubjectBase(student_id=student_id, subject_id=subject_id).model_dump()
                )

        class_id = None
        if data.get('class_'):
            class_repo = uw.get_repository('class')
            class_id = class_repo.get_all_by_conditions([
                Condition(field_name='class_name', value=data['class_'])
            ])[0][0]

        new_student = StudentBase(
            id=student_id,
            first_name=data.get('first_name'),
            last_name=data.get('last_name'),
            gender_type=data.get('gender_type'),
            email=data.get('email'),
            class_id=class_id,
        )
        self.db.create(student_id, new_student.model_dump())


    def update_one(self, data: dict) -> None:
        from repositories.unit_of_work import UnitOfWork
        uw = UnitOfWork()

        if data.get('subjects'):
            student_subject_repo = uw.get_repository('student_subject')
            subject_repo = uw.get_repository('subject')

            student_subject_records = student_subject_repo.get_all_by_conditions([
                Condition(field_name='student_id', value=data['id'])
            ])
            for r in student_subject_records:
                student_subject_repo.delete_one(r[0])

            for s_name in data['subjects']:
                subject_id = subject_repo.get_all_by_conditions([
                    Condition(field_name='subject_name', value=s_name)
                ])[0][0]
                bytes = (f"{data['id']}{subject_id}").encode()
                obj_id = int(hashlib.sha256(bytes).hexdigest(), 16)
                student_subject_repo.add_one(
                    obj_id,
                    StudentSubjectBase(student_id=data['id'], subject_id=subject_id).model_dump()
                )

        class_id = None
        if data.get('class_'):
            class_repo = uw.get_repository('class')
            class_id = class_repo.get_all_by_conditions([
                Condition(field_name='class_name', value=data['class_'])
            ])[0][0]
        elif data.get('class_id'):
            class_id = data['class_id']

        updated_student = StudentBase(
            id=data['id'],
            first_name=data.get('first_name'),
            last_name=data.get('last_name'),
            gender_type=data.get('gender_type'),
            email=data.get('email'),
            class_id=class_id,
        )
        self.db.update(data['id'], updated_student.model_dump())


    def delete_one(self, student_id: int) -> None:
        from repositories.unit_of_work import UnitOfWork
        uw = UnitOfWork()

        student_subject_repo = uw.get_repository('student_subject')
        student_subject_records = student_subject_repo.get_all_by_conditions([
            Condition(field_name='student_id', value=student_id)
        ])
        for r in student_subject_records:
            student_subject_repo.delete_one(r[0])

        self.db.delete(student_id)


    def get_linked_records(self, this_record: dict, field: str) -> list[tuple]:
        from repositories.unit_of_work import UnitOfWork
        uw = UnitOfWork()

        result = []
        if field == "class_":
            teacher_repo = uw.get_repository("class")
            result = teacher_repo.get_all_by_conditions([
                Condition(field_name="id", value=this_record["class_id"])
            ])
        elif field == "subjects":
            student_subject_repo = uw.get_repository("student_subject")
            student_subjects = student_subject_repo.get_all_by_conditions([
                Condition(field_name="student_id", value=this_record["id"])
            ])
            subject_repo = uw.get_repository("subject")
            subjects = []
            for student_subject in student_subjects:
                subjects.extend(
                    subject_repo.get_all_by_conditions([
                        Condition(field_name="id", value=student_subject[1]["subject_id"])
                    ])
                )
            result = subjects

        return result
