from typing import Any

from database.exceptions import InvalidDataException
from repositories import BaseRepository
from schemas.entities import Condition, ClassBase


class ClassRepository(BaseRepository):
    TABLE_NAME = 'class'
    EXCLUDED_FIELDS = ["id", "class_teacher_id", "students", "class_teacher"]
    INCLUDED_FIELDS = ["class_name"]

    def add_one(self, class_id: int, data: dict[str, Any]) -> None:
        from repositories.unit_of_work import UnitOfWork
        uw = UnitOfWork()

        # Класс с таким именем уже существует?
        if self.get_all_by_conditions([Condition(field_name='class_name', value=data['class_name'])]):
            raise InvalidDataException("Класс с данным именем уже существует")

        teacher_id = None
        if data.get('class_teacher'):
            teacher_repo = uw.get_repository('teacher')
            teacher_id = teacher_repo.get_all_by_conditions([
                Condition(field_name='phone_no', value=data['class_teacher'])
            ])[0][0]

        if data.get('students'):
            student_repo = uw.get_repository('student')
            for s_email in data['students']:
                student = student_repo.get_all_by_conditions([
                    Condition(field_name='email', value=s_email)
                ])[0]
                student[1]["class_id"] = class_id
                student_repo.update_one(student[1])

        new_class = ClassBase(
            id=class_id,
            class_name=data.get("class_name"),
            class_teacher_id=teacher_id
        )
        self.db.create(class_id, new_class.model_dump())


    def update_one(self, data: dict) -> None:
        from repositories.unit_of_work import UnitOfWork
        uw = UnitOfWork()

        teacher_id = None
        if data.get('class_teacher'):
            teacher_repo = uw.get_repository('teacher')
            teacher_id = teacher_repo.get_all_by_conditions([
                Condition(field_name='phone_no', value=data['class_teacher'])
            ])[0][0]
        elif data.get('class_teacher_id'):
            teacher_id = data['class_teacher_id']

        if data.get('students'):
            student_repo = uw.get_repository('student')
            for s_email in data['students']:
                student = student_repo.get_all_by_conditions([
                    Condition(field_name='email', value=s_email)
                ])[0]
                student[1]["class_id"] = data['id']
                student_repo.update_one(student[1])

        updated_class = ClassBase(
            id=data['id'],
            class_name=data.get("class_name"),
            class_teacher_id=teacher_id
        )
        self.db.update(data['id'], updated_class.model_dump())


    def delete_one(self, class_id: int) -> None:
        from repositories.unit_of_work import UnitOfWork
        uw = UnitOfWork()

        student_repo = uw.get_repository('student')
        students = student_repo.get_all_by_conditions([
            Condition(field_name='class_id', value=class_id)
        ])
        for s in students:
            student_repo.delete_one(s[0])

        teacher_repo = uw.get_repository('teacher')
        teachers = teacher_repo.get_all_by_conditions([
            Condition(field_name='class_id', value=class_id)
        ])
        for t in teachers:
            teacher_repo.delete_one(t[0])

        self.db.delete(class_id)


    def get_linked_records(self, this_record: dict, field: str) -> list[tuple]:
        from repositories.unit_of_work import UnitOfWork
        uw = UnitOfWork()

        result = []
        if field == "class_teacher":
            teacher_repo = uw.get_repository("teacher")
            result = teacher_repo.get_all_by_conditions([
                Condition(field_name="id", value=this_record["class_teacher_id"])
            ])
        elif field == "students":
            student_repo = uw.get_repository("student")
            result = student_repo.get_all_by_conditions([
                Condition(field_name="class_id", value=this_record["id"])
            ])
        return result
