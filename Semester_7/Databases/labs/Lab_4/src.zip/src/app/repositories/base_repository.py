from typing import Any

from database import Database
from interfaces import IBaseRepository
from schemas import Condition


class BaseRepository(IBaseRepository):
    TABLE_NAME = None
    INCLUDED_FIELDS = []
    EXCLUDED_FIELDS = []

    def __init__(self) -> None:
        self.db = Database(self.TABLE_NAME)

    def add_one(self, id: int, data: dict[str, Any]) -> None:
        self.db.create(id, data)

    def get_one(self, id: int) -> dict:
        return self.db.read(id)

    def get_first(self) -> tuple:
        return self.db.read_all()[0]

    def get_all(self) -> list[tuple]:
        return self.db.read_all()

    def delete_one(self, id: int) -> None:
        self.db.delete(id)

    def update_one(self, data: dict) -> None:
        self.db.update(data['id'], data)

    def get_all_by_conditions(self, conditions: list[Condition]) -> list[tuple]:
        return self.db.read_all_by_conditions(conditions)

    def get_linked_records(self, this_record: dict, field: str) -> list[tuple]:
        pass
