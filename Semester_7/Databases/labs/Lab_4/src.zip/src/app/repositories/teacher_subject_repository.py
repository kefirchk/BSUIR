from repositories import BaseRepository


class TeacherSubjectRepository(BaseRepository):
    TABLE_NAME = 'teacher_subject'
