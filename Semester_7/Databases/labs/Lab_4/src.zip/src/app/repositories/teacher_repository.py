import hashlib
from typing import Any

from database.exceptions import InvalidDataException
from repositories import BaseRepository
from schemas import Condition, TeacherSubjectBase, TeacherBase


class TeacherRepository(BaseRepository):
    TABLE_NAME = 'teacher'
    EXCLUDED_FIELDS = ["id", "class_", "subjects"]
    INCLUDED_FIELDS = ["first_name", "last_name", "age", "phone_no", "gender_type"]

    def add_one(self, teacher_id: int, data: dict[str, Any]) -> None:
        from repositories.unit_of_work import UnitOfWork
        uw = UnitOfWork()

        # Учитель с таким номером телефона уже существует?
        if self.get_all_by_conditions([Condition(field_name='phone_no', value=data['phone_no'])]):
            raise InvalidDataException("Учитель с данным номером телефона уже существует")

        if data.get("class_"):
            class_repo = uw.get_repository('class')
            class_ = class_repo.get_all_by_conditions([
                Condition(field_name='class_name', value=data['class_'])
            ])[0]
            class_[1]['class_teacher_id'] = teacher_id
            class_repo.update_one(class_[1])

        if data.get("subjects"):
            teacher_subject_repo = uw.get_repository('teacher_subject')
            subject_repo = uw.get_repository('subject')
            for s_name in data['subjects']:
                subject_id = subject_repo.get_all_by_conditions([
                    Condition(field_name='subject_name', value=s_name)
                ])[0][0]
                bytes = (str(data['id']) + str(subject_id)).encode()
                obj_id = int(hashlib.sha256(bytes).hexdigest(), 16)
                teacher_subject_repo.add_one(
                    obj_id,
                    TeacherSubjectBase(teacher_id=teacher_id, subject_id=subject_id).model_dump()
                )

        new_teacher = TeacherBase(
            id=teacher_id,
            first_name=data.get('first_name'),
            last_name=data.get('last_name'),
            age=data.get('age'),
            phone_no=data.get('phone_no'),
            gender_type=data.get('gender_type')
        )
        self.db.create(teacher_id, new_teacher.model_dump())


    def update_one(self, data: dict) -> None:
        from repositories.unit_of_work import UnitOfWork
        uw = UnitOfWork()

        if data.get("class_"):
            class_repo = uw.get_repository('class')
            class_ = class_repo.get_all_by_conditions([
                Condition(field_name='class_name', value=data['class_'])
            ])[0]
            class_[1]['class_teacher_id'] = data['id']
            class_repo.update_one(class_[1])

        if data.get("subjects"):
            teacher_subject_repo = uw.get_repository('teacher_subject')
            subject_repo = uw.get_repository('subject')

            teacher_subject_records = teacher_subject_repo.get_all_by_conditions([
                Condition(field_name='teacher_id', value=data['id'])
            ])
            for r in teacher_subject_records:
                teacher_subject_repo.delete_one(r[0])

            for s_name in data['subjects']:
                subject_id = subject_repo.get_all_by_conditions([
                    Condition(field_name='subject_name', value=s_name)
                ])[0][0]
                bytes = (f"{data['id']}{subject_id}").encode()
                obj_id = int(hashlib.sha256(bytes).hexdigest(), 16)
                teacher_subject_repo.add_one(
                    obj_id,
                    TeacherSubjectBase(teacher_id=data['id'], subject_id=subject_id).model_dump()
                )

        updated_teacher = TeacherBase(
            id=data['id'],
            first_name=data.get('first_name'),
            last_name=data.get('last_name'),
            age=data.get('age'),
            phone_no=data.get('phone_no'),
            gender_type=data.get('gender_type')
        )
        self.db.update(data['id'], updated_teacher.model_dump())


    def delete_one(self, teacher_id: int) -> None:
        from repositories.unit_of_work import UnitOfWork
        uw = UnitOfWork()

        teacher_subject_repo = uw.get_repository('teacher_subject')
        teacher_subject_records = teacher_subject_repo.get_all_by_conditions([
            Condition(field_name='teacher_id', value=teacher_id)
        ])
        for r in teacher_subject_records:
            teacher_subject_repo.delete_one(r[0])

        class_repo = uw.get_repository('class')
        classes = class_repo.get_all_by_conditions([
            Condition(field_name='class_teacher_id', value=teacher_id)
        ])
        for c in classes:
            class_dict = class_repo.get_one(c[0])
            class_dict['class_teacher_id'] = None
            class_repo.update_one(class_dict)

        self.db.delete(teacher_id)


    def get_linked_records(self, this_record: dict, field: str) -> list[tuple]:
        from repositories.unit_of_work import UnitOfWork
        uw = UnitOfWork()

        result = []
        if field == "class_":
            class_repo = uw.get_repository("class")
            result = class_repo.get_all_by_conditions([
                Condition(field_name="class_teacher_id", value=this_record["id"])
            ])
        elif field == "subjects":
            teacher_subject_repo = uw.get_repository("teacher_subject")
            teacher_subjects = teacher_subject_repo.get_all_by_conditions([
                Condition(field_name="teacher_id", value=this_record["id"])
            ])
            subject_repo = uw.get_repository("subject")
            subjects = []
            for teacher_subject in teacher_subjects:
                subjects.extend(
                    subject_repo.get_all_by_conditions([
                        Condition(field_name="id", value=teacher_subject[1]["subject_id"])
                    ])
                )
            result = subjects

        return result
