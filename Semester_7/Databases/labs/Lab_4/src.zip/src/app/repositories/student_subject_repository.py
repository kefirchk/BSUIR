from repositories import BaseRepository


class StudentSubjectRepository(BaseRepository):
    TABLE_NAME = 'student_subject'
