from interfaces import IBaseRepository
from repositories import ClassRepository, TeacherSubjectRepository, StudentRepository, StudentSubjectRepository, \
    SubjectRepository, TeacherRepository


class UnitOfWork:
    repositories = [
        ClassRepository,
        TeacherSubjectRepository,
        StudentRepository,
        StudentSubjectRepository,
        SubjectRepository,
        TeacherRepository,
    ]

    def get_repository(self, table_name: str) -> IBaseRepository | None:
        for repository in self.repositories:
            if repository.TABLE_NAME == table_name:
                return repository()
        return None