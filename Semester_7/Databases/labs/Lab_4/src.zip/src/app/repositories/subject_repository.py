import hashlib
from typing import Any

from database.exceptions import InvalidDataException
from repositories import BaseRepository
from schemas import Condition, StudentSubjectBase, SubjectBase, TeacherSubjectBase


class SubjectRepository(BaseRepository):
    TABLE_NAME = 'subject'
    EXCLUDED_FIELDS = ["id", "students", "teachers"]
    INCLUDED_FIELDS = ["subject_name"]

    def add_one(self, subject_id: int, data: dict[str, Any]) -> None:
        from repositories.unit_of_work import UnitOfWork
        uw = UnitOfWork()

        # Предмет с таким названием уже существует?
        if self.get_all_by_conditions([Condition(field_name='subject_name', value=data['subject_name'])]):
            raise InvalidDataException("Предмет с данным названием уже существует")

        if data.get("students"):
            student_subject_repo = uw.get_repository('student_subject')
            student_repo = uw.get_repository('student')
            for s_email in data['students']:
                student_id = student_repo.get_all_by_conditions([
                    Condition(field_name='email', value=s_email)
                ])[0][0]
                student_subject_repo.add_one(
                    int(hashlib.sha256().hexdigest(), 16),
                    StudentSubjectBase(student_id=student_id, subject_id=subject_id).model_dump()
                )

        if data.get("teachers"):
            teacher_subject_repo = uw.get_repository('teacher_subject')
            teacher_repo = uw.get_repository('teacher')
            for s_phone_no in data['teachers']:
                teacher_id = teacher_repo.get_all_by_conditions([
                    Condition(field_name='phone_no', value=s_phone_no)
                ])[0][0]
                teacher_subject_repo.add_one(
                    int(hashlib.sha256().hexdigest(), 16),
                    TeacherSubjectBase(teacher_id=teacher_id, subject_id=subject_id).model_dump()
                )

        new_subject = SubjectBase(id=subject_id, subject_name=data.get('subject_name'))
        self.db.create(subject_id, new_subject.model_dump())


    def update_one(self, data: dict) -> None:
        from repositories.unit_of_work import UnitOfWork
        uw = UnitOfWork()

        if data.get("students"):
            student_subject_repo = uw.get_repository('student_subject')
            student_repo = uw.get_repository('student')

            student_subject_records = student_subject_repo.get_all_by_conditions([
                Condition(field_name='subject_id', value=data['id'])
            ])
            for r in student_subject_records:
                student_subject_repo.delete_one(r[0])

            for s_email in data['students']:
                student_id = student_repo.get_all_by_conditions([
                    Condition(field_name='email', value=s_email)
                ])[0][0]
                bytes = (f"{student_id}{data['id']}").encode()
                obj_id = int(hashlib.sha256(bytes).hexdigest(), 16)
                student_subject_repo.add_one(
                    obj_id,
                    StudentSubjectBase(student_id=student_id, subject_id=data['id']).model_dump()
                )

        if data.get("teachers"):
            teacher_subject_repo = uw.get_repository('teacher_subject')
            teacher_repo = uw.get_repository('teacher')

            teacher_subject_records = teacher_subject_repo.get_all_by_conditions([
                Condition(field_name='subject_id', value=data['id'])
            ])
            for r in teacher_subject_records:
                teacher_subject_repo.delete_one(r[0])

            for s_phone_no in data['teachers']:
                teacher_id = teacher_repo.get_all_by_conditions([
                    Condition(field_name='phone_no', value=s_phone_no)
                ])[0][0]
                bytes = (f"{teacher_id}{data['id']}").encode()
                obj_id = int(hashlib.sha256(bytes).hexdigest(), 16)
                teacher_subject_repo.add_one(
                    obj_id,
                    TeacherSubjectBase(teacher_id=teacher_id, subject_id=data['id']).model_dump()
                )

        updated_subject = SubjectBase(id=data['id'], subject_name=data.get('subject_name'))
        self.db.update(data['id'], updated_subject.model_dump())


    def delete_one(self, subject_id: int) -> None:
        from repositories.unit_of_work import UnitOfWork
        uw = UnitOfWork()

        student_subject_repo = uw.get_repository('student_subject')
        student_subject_records = student_subject_repo.get_all_by_conditions([
            Condition(field_name='subject_id', value=subject_id)
        ])
        for r in student_subject_records:
            student_subject_repo.delete_one(r[0])

        teacher_subject_repo = uw.get_repository('teacher_subject')
        teacher_subject_records = teacher_subject_repo.get_all_by_conditions([
            Condition(field_name='subject_id', value=subject_id)
        ])
        for r in teacher_subject_records:
            teacher_subject_repo.delete_one(r[0])

        self.db.delete(subject_id)


    def get_linked_records(self, this_record: dict, field: str) -> list[tuple]:
        from repositories.unit_of_work import UnitOfWork
        uw = UnitOfWork()

        result = []
        if field == "students":
            student_subject_repo = uw.get_repository("student_subject")
            student_subjects = student_subject_repo.get_all_by_conditions([
                Condition(field_name="subject_id", value=this_record["id"])
            ])
            student_repo = uw.get_repository("student")
            students = []
            for student_subject in student_subjects:
                students.extend(
                    student_repo.get_all_by_conditions([
                        Condition(field_name="id", value=student_subject[1]["student_id"])
                    ])
                )
            result = students
        elif field == "teachers":
            teacher_subject_repo = uw.get_repository("teacher_subject")
            teacher_subjects = teacher_subject_repo.get_all_by_conditions([
                Condition(field_name="subject_id", value=this_record["id"])
            ])
            teacher_repo = uw.get_repository("teacher")
            teachers = []
            for teacher_subject in teacher_subjects:
                teachers.extend(
                    teacher_repo.get_all_by_conditions([
                        Condition(field_name="id", value=teacher_subject[1]["teacher_id"])
                    ])
                )
            result = teachers

        return result
