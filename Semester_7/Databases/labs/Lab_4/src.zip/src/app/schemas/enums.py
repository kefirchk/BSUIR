from enum import StrEnum


class DBCommandType(StrEnum):
    UPDATE = "UPDATE",
    DELETE = "DELETE",
    INSERT = "INSERT",
    TRUNCATE = "TRUNCATE"


class GenderType(StrEnum):
    MALE = "MALE",
    FEMALE = "FEMALE"
