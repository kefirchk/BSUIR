from pydantic import BaseModel, Field
from typing import Any
from schemas import GenderType, DBCommandType


class Condition(BaseModel):
    field_name: str
    value: Any


class Packet(BaseModel):
    operation: DBCommandType
    table: str
    data: Any


class SubjectBase(BaseModel):
    id: int
    subject_name: str = Field(min_length=1)


class StudentBase(BaseModel):
    id: int
    first_name: str = Field(min_length=1)
    last_name: str = Field(min_length=1)
    gender_type: GenderType = Field(default=GenderType.MALE)
    email: str = Field(min_length=3)
    class_id: int | None = None


class StudentSubjectBase(BaseModel):
    student_id: int | None = None
    subject_id: int | None = None


class ClassBase(BaseModel):
    id: int
    class_name: str = Field(min_length=1)
    class_teacher_id: int | None = None


class TeacherBase(BaseModel):
    id: int
    first_name: str = Field(min_length=1)
    last_name: str = Field(min_length=1)
    age: int = Field(gt=0, lt=100)
    phone_no: str = Field(min_length=1)
    gender_type: GenderType = Field(default=GenderType.MALE)


class TeacherSubjectBase(BaseModel):
    subject_id: int | None = None
    teacher_id: int | None = None
