import hashlib
import json
from enum import Enum
from tkinter import Tk, Canvas, Scrollbar, messagebox, StringVar, Entry
from tkinter.ttk import Label, Combobox, Button

from pydantic import BaseModel

from logger import logger
from schemas import DBCommandType, ClassBase, TeacherBase, StudentBase, SubjectBase
from configs import db_settings
from interfaces import IBaseRepository
from repositories.unit_of_work import UnitOfWork


class EditWindow(Tk):
    def __init__(self, main_window, repository: IBaseRepository, table_name: str, command: str, db_record=None):
        super().__init__()
        self.main_window = main_window
        self.title(f"{command} {table_name}")
        self.resizable(False, False)

        self.canvas = Canvas(self, width=460)
        self.canvas.grid(row=0, column=0, sticky='nsew')
        self.scrollbar = Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.scrollbar.grid(row=0, column=2, sticky='ns')
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.inner_frame = Canvas(self.canvas)
        self.canvas.create_window((0, 0), window=self.inner_frame, anchor='nw')
        self.inner_frame.bind("<Configure>", lambda event: self.canvas.configure(scrollregion=self.canvas.bbox("all")))

        self.repository = repository
        self.table_name = table_name
        self.command = command
        self.db_record = db_record
        self.field_counters = {}
        self.buttons = []
        self.focus_button_index = 0
        self.focus_field_index = 0

        self.create_widgets()


    def bind_keys(self):
        self.bind("<Escape>", self.close_window)
        self.bind("<Control-f>", self.focus_on_field)
        self.bind("<Control-b>", self.focus_on_button)
        self.bind("<Control-s>", self.execute_edit)
        self.bind("<Control-Tab>", self.main_window.switch_focus_to_next_window)
        self.bind("<Return>", self.handle_enter)
        self.bind_all("<MouseWheel>", lambda event: self.canvas.yview_scroll(int(-1 * (event.delta // 120)), "units"))


    def close_window(self, event=None):
        self.main_window.table_windows.remove(self)
        self.destroy()


    def focus_on_field(self, event=None):
        if self.entries:
            if self.focus_field_index == len(self.entries):
                self.focus_field_index = 0
            self.entries[self.focus_field_index].focus_set()
            self.focus_field_index += 1


    def focus_on_button(self, event=None):
        if self.buttons:
            if self.focus_button_index == len(self.buttons):
                self.focus_button_index = 0
            self.buttons[self.focus_button_index].focus_set()
            self.focus_button_index += 1


    def handle_enter(self, event):
        widget = self.focus_get()
        if isinstance(widget, Button):
            widget.invoke()


    def create_widgets(self):
        self.entries = []
        self.labels = []
        self.row_index = 0  # Индекс для размещения полей
        self.create_fields(indent=0)
        button = Button(self, text=self.command, width=30, command=self.execute_edit)
        button.grid(row=1, column=0, columnspan=2, pady=10)
        self.buttons.append(button)


    @staticmethod
    def get_related_table_name(field_type):
        if field_type == ClassBase:
            return 'class'
        elif field_type == TeacherBase:
            return 'teacher'
        elif field_type == StudentBase:
            return 'student'
        elif field_type == SubjectBase:
            return 'subject'
        return None


    def get_related_values(self, table_name: str) -> list[str]:
        table_data = UnitOfWork().get_repository(table_name).get_all()
        values = []
        for obj in table_data:
            field_value_display = obj[1][db_settings.RELATED_FIELD_MAP[table_name]['field']]
            values.append(field_value_display)
        return values


    def create_fields(self, indent=0):
        # INSERT
        if self.command == DBCommandType.INSERT and self.db_record is None:
            fields = self.repository.INCLUDED_FIELDS + self.repository.EXCLUDED_FIELDS
            for field_name in fields:
                if field_name == 'id' or field_name.endswith('_id'):
                    continue
                self.create_field_widget(field_name, indent)
        # UPDATE
        else:
            fields = self.repository.INCLUDED_FIELDS + self.repository.EXCLUDED_FIELDS
            for field_name in fields:
                if field_name == 'id' or field_name.endswith('_id'):
                    continue
                if field_name in self.db_record[1]:
                    field_value = self.db_record[1][field_name]
                else:
                    field_value = self.repository.get_linked_records(self.db_record[1], field_name)
                self.create_field_widget(field_name, indent, field_value)


    def create_field_widget(self, field_name, indent, field_value=None):
        field_type = db_settings.FIELD_TYPE_MAP[field_name]

        # Если Enum
        if issubclass(field_type, Enum):
            label = Label(self.inner_frame, text=field_name)
            label.grid(row=self.row_index, column=0, sticky="e", padx=indent)

            enum_values = [e.value for e in field_type]  # Получаем значения Enum
            combo_var = StringVar()
            combobox = Combobox(self.inner_frame, textvariable=combo_var, values=enum_values, width=30, state="readonly")
            combobox.grid(row=self.row_index, column=1, pady=5)

            if field_value is not None:
                display_value = field_value
                combobox.set(display_value)
            elif enum_values:
                combobox.set(enum_values[0])

            self.labels.append(field_name)
            self.entries.append(combobox)
            self.row_index += 1

        # Если поле — список моделей (Pydantic объектов)
        elif hasattr(field_type, '__origin__') and field_type.__origin__ is list:
            item_type = field_type.__args__[0]
            label = Label(self.inner_frame, text=f"{field_name}")
            label.grid(row=self.row_index, column=0, sticky="e", padx=indent)
            add_button = Button(self.inner_frame, text=f"+", command=lambda: self.create_combobox(field_name, item_type, indent=20))
            add_button.grid(row=self.row_index, column=1, pady=5)
            self.row_index += 1
            self.buttons.append(add_button)

            if field_value is not None and isinstance(field_value, list) and all(
                    isinstance(i, tuple) for i in field_value):
                for data in field_value:
                    self.create_combobox(field_name, item_type, indent + 20, data[1])

        # Если это отдельная Pydantic модель
        elif isinstance(field_value, BaseModel) or issubclass(field_type, BaseModel):
            label = Label(self.inner_frame, text=field_name)
            label.grid(row=self.row_index, column=0, sticky="e", padx=indent)

            table_name = self.get_related_table_name(db_settings.FIELD_TYPE_MAP[field_name])
            values = self.get_related_values(table_name)

            combo_var = StringVar()
            combobox = Combobox(self.inner_frame, textvariable=combo_var, values=values, width=30, state="readonly")
            combobox.grid(row=self.row_index, column=1, pady=5)

            if field_value:
                display_value = []
                field_value_display = field_value[0][1][db_settings.RELATED_FIELD_MAP[table_name]['field']]
                display_value.append(field_value_display)
                combobox.set(display_value)  # Устанавливаем текущее значение

            self.labels.append(field_name)
            self.entries.append(combobox)
            self.row_index += 1

        # Если значение None, создаем пустое поле ввода
        elif field_value is None:
            label = Label(self.inner_frame, text=field_name)
            label.grid(row=self.row_index, column=0, sticky="e", padx=indent)

            entry = Entry(self.inner_frame, width=30)
            self.labels.append(field_name)
            self.entries.append(entry)

            entry.grid(row=self.row_index, column=1, pady=5)
            self.row_index += 1

        # В противном случае, создаем поле ввода с текущим значением
        else:
            label = Label(self.inner_frame, text=field_name)
            label.grid(row=self.row_index, column=0, sticky="e", padx=indent)

            entry = Entry(self.inner_frame, width=30)

            if self.command == DBCommandType.UPDATE and self.db_record:
                entry.insert(0, field_value if field_value is not None else "")

            self.labels.append(field_name)
            self.entries.append(entry)
            entry.grid(row=self.row_index, column=1, pady=5)
            self.row_index += 1


    def create_combobox(self, field_name, field_type, indent, data=None):
        # Проверяем, есть ли уже счетчик для этого поля
        if field_name not in self.field_counters:
            self.field_counters[field_name] = 0

        # Используем значение счетчика для индекса
        model_label = Label(self.inner_frame, text=f"{field_name}[{self.field_counters[field_name]}]")
        model_label.grid(row=self.row_index, column=0, sticky="e", padx=indent)

        # Получаем возможные значения для этого типа объекта, исключая id и foreign ключи
        table_name = self.get_related_table_name(field_type)
        values = self.get_related_values(table_name)

        combo_var = StringVar()
        combobox = Combobox(self.inner_frame, textvariable=combo_var, values=values, width=30, state="readonly")
        combobox.grid(row=self.row_index, column=1, pady=5)

        display_value = ""
        if self.command == DBCommandType.UPDATE:
            # Устанавливаем текущее значение для объекта
            if data:
                field_value_display = data[db_settings.RELATED_FIELD_MAP[table_name]['field']]
                display_value = field_value_display
            else:
                display_value = values[0] if values else ""
        elif self.command == DBCommandType.INSERT:
            # Устанавливаем значение первой строки из соответствующей таблицы
            display_value = values[0] if values else ""

        combobox.set(display_value)

        # Кнопка удаления Pydantic объекта
        delete_button = Button(self.inner_frame, text="-", command=lambda: self.delete_model_entry(model_label, combobox, delete_button, field_name))
        delete_button.grid(row=self.row_index, column=2, pady=5)

        self.buttons.append(delete_button)
        self.labels.append(f"{field_name}[{self.field_counters[field_name]}]")  # Сохраняем метку с индексом
        self.entries.append(combobox)

        # Увеличиваем счетчик для этого поля
        self.field_counters[field_name] += 1
        self.row_index += 1  # Увеличиваем row_index после добавления нового элемента


    def redistribute_widgets_after_removal(self, start_row):
        for widget in self.inner_frame.grid_slaves():
            row = int(widget.grid_info()["row"])
            if row > start_row:
                widget.grid(row=row - 1, column=widget.grid_info()["column"])
        self.update_idletasks()  # Принудительно обновляем интерфейс


    def delete_model_entry(self, model_label, combobox, delete_button, field_name):
        start_row = model_label.grid_info()["row"]
        label_text = model_label.cget("text")

        self.buttons.remove(delete_button)

        # Теперь безопасно уничтожаем виджеты
        model_label.destroy()
        combobox.destroy()
        delete_button.destroy()

        if label_text in self.labels:
            index = self.labels.index(label_text)
            self.labels.pop(index)
            self.entries.pop(index)

            if field_name in self.field_counters:
                self.field_counters[field_name] -= 1

            self.redistribute_widgets_after_removal(start_row)

        self.row_index -= 1  # Уменьшаем общий счетчик строк


    def execute_edit(self, event=None):
        data = {}
        lists = {}  # Словарь для хранения списков

        for label, entry in zip(self.labels, self.entries):
            value = str(entry.get())  # Получаем введенные данные

            # Проверяем, является ли метка частью списка
            if "[" in label and "]" in label:
                base_label = label.split("[")[0]  # Получаем базовое имя поля
                index = int(label.split("[")[1].rstrip("]"))  # Извлекаем индекс из метки

                # Инициализируем список, если его ещё нет
                if base_label not in lists:
                    lists[base_label] = []

                # Убедимся, что у нас достаточно места в списке
                while len(lists[base_label]) <= index:
                    lists[base_label].append(None)

                lists[base_label][index] = value  # Сохраняем значение в списке
            else:
                data[label] = value  # Сохраняем остальные значения

        # Объединяем списки в общий словарь данных
        for key, values in lists.items():
            unique_list = list(set([item for item in values if item is not None]))
            data[key] = unique_list # Убираем None значения

        logger.info(f'Выполнение команды {self.command}: {data}')

        self.update_or_insert(data)


    def update_or_insert(self, data: dict):
        try:
            message = ""
            if self.command == DBCommandType.INSERT:
                json_bytes = json.dumps(data, sort_keys=True).encode()
                obj_id = int(hashlib.sha256(json_bytes).hexdigest(), 16)
                self.repository.add_one(obj_id, data)
                message = "Новая запись успешно добавлена!"
            elif self.command == DBCommandType.UPDATE:
                data['id'] = self.db_record[1]['id']
                self.repository.update_one(data)
                message = "Запись успешно обновлена!"

            messagebox.showinfo("Информация", message)
        except Exception as e:
            message = f"Не удалось выполнить операцию {self.command}: {e}"
            logger.error(message)
            messagebox.showerror("Ошибка", message)
