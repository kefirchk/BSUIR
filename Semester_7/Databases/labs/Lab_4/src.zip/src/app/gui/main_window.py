import json
from tkinter import Tk, Menu, Text, NSEW, NS, EW, FALSE, ttk, DISABLED, messagebox, filedialog

from configs import db_settings
from database.exceptions import InvalidJSONQueryDataException
from gui import TableWindow
from logger import logger
from schemas import DBCommandType


class MainWindow(Tk):
    def __init__(self):
        super().__init__()
        self.title("School Management System")
        self.geometry("440x360+540+220")
        self.resizable(False, False)
        self.option_add("*tearOff", FALSE)

        self.table_windows = []  # Список окон таблиц
        self.current_window_index = -1  # Индекс текущего активного окна

        self.create_text_editor()
        self.create_menus()
        self.bind_keys()


    def bind_keys(self):
        logger.info("Привязка горячих клавиш к главному окну")

        self.bind("<Control-t>", lambda event: self.table_menu.post(self.winfo_rootx(), self.winfo_rooty()))
        self.bind("<Control-e>", lambda event: self.editor.focus())
        self.bind("<Escape>", self.close_window)
        self.bind("<Control-Tab>", self.switch_focus_to_next_window)


    def close_window(self, event=None):
        for w in self.table_windows:
            w.destroy()
        self.destroy()


    def create_text_editor(self):
        logger.info("Создание текстового редактора для SQL-запросов")

        self.editor = Text(wrap="none", height=20, width=50, bg='lightgray')
        self.editor.grid(column=0, row=0, sticky=NSEW)
        ys = ttk.Scrollbar(orient="vertical", command=self.editor.yview)
        ys.grid(column=1, row=0, sticky=NS)
        xs = ttk.Scrollbar(orient="horizontal", command=self.editor.xview)
        xs.grid(column=0, row=1, sticky=EW)
        self.editor["yscrollcommand"] = ys.set
        self.editor["xscrollcommand"] = xs.set
        self.editor.insert("1.0", "Queries are blocked.")
        self.editor.config(state=DISABLED)


    def create_menus(self):
        logger.info("Создание главного меню")

        main_menu = Menu(self)
        self.create_table_menu(main_menu)
        self.create_query_menu(main_menu)
        self.config(menu=main_menu)


    def create_table_menu(self, main_menu):
        logger.info("Создание подменю для таблиц базы данных")

        self.table_menu = Menu(main_menu)
        for table_name in db_settings.INCLUDED_TABLES:
            self.table_menu.add_command(label=table_name, command=lambda name=table_name: self.show_table(name))
        main_menu.add_cascade(label="Tables", menu=self.table_menu)


    def create_query_menu(self, main_menu):
        logger.info("Создание подменю для работы с запросами")

        self.query_menu = Menu(main_menu)
        self.query_menu.add_command(label="Execute from file", command=self.execute_query_from_file)
        main_menu.add_cascade(label="Query", menu=self.query_menu)


    def show_table(self, table_name):
        logger.info(f"Отображение таблицы '{table_name}' в новом окне")

        table_window = TableWindow(parent_window=self, table_name=table_name)
        self.table_windows.append(table_window)
        table_window.lift()
        table_window.focus_force()
        table_window.mainloop()


    def switch_focus_to_next_window(self, event=None):
        logger.info("Переключение фокуса на другое окно")

        windows = [self] + self.table_windows
        self.current_window_index = (self.current_window_index + 1) % len(windows)
        next_window = windows[self.current_window_index]
        next_window.lift()
        next_window.focus_force()


    def load_packets_from_file(self, filename: str) -> list[dict]:
        try:
            with open(filename, 'r', encoding='utf-8') as file:
                packets = json.load(file)
                return packets
        except Exception as e:
            logger.error(f"Ошибка при чтении файла {filename}: {e}")
            return []


    def execute_query(self, packets: list[dict]):
        if not packets:
            logger.warning("Запрос не выполнен: JSON запрос для пакетного режима не найден")
            messagebox.showwarning("Предупреждение", "Запрос не выполнен: JSON запрос для пакетного режима не найден")
        else:
            for packet in packets:
                try:
                    op_type = packet.get('operation')
                    table = packet.get('table')
                    data = packet.get('data')
                    if not(op_type and table and data):
                        raise InvalidJSONQueryDataException("Невалидный формат JSON запроса для пакетного режима")

                    from repositories.unit_of_work import UnitOfWork
                    repository = UnitOfWork().get_repository(table)

                    if op_type == DBCommandType.INSERT:
                        record_id = data.get('id')
                        if not record_id:
                            raise InvalidJSONQueryDataException("Невалидный формат JSON запроса для пакетного режима")

                        repository.add_one(record_id, data)
                        logger.info(f"Запись {data} успешно добавлена через пакетный режим")

                    elif op_type == DBCommandType.UPDATE:
                        repository.update_one(data)
                        logger.info(f"Запись {data} успешно обновлена через пакетный режим")

                    elif op_type == DBCommandType.DELETE:
                        record_id = data.get('id')
                        if not record_id:
                            raise InvalidJSONQueryDataException("Невалидный формат JSON запроса для пакетного режима")

                        repository.delete_one(record_id)
                        logger.info(f"Запись {data} успешно удалена через пакетный режим")

                    else:
                        logger.warning(f"Неизвестная операция в пакетном режиме: {op_type}")
                except Exception as e:
                    logger.error(f"Ошибка при выполнении операции {packet} через пакетный режим: {e}")


    def execute_query_from_file(self):
        filepath = filedialog.askopenfile(title="Execute JSON query")
        if filepath:
            with open(filepath.name, "r", encoding="utf-8") as file:
                packets = json.load(file)
                self.execute_query(packets)
