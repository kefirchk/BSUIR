from database.postgres.converter import DBConverter


if __name__ == '__main__':
    postgres_url = 'postgresql://postgres:1234@localhost:5000/school'
    migration = DBConverter(postgres_url)
    migration.migrate_data()

    print("Миграция данных завершена.")