from abc import ABC, abstractmethod
from typing import Any

from schemas.entities import Condition


class IBaseRepository(ABC):
    TABLE_NAME = None
    INCLUDED_FIELDS = []
    EXCLUDED_FIELDS = []

    @abstractmethod
    def add_one(self, id: int, data: dict[str, Any]) -> None:
        raise NotImplementedError

    @abstractmethod
    def get_one(self, id: int) -> dict:
        raise NotImplementedError

    @abstractmethod
    def get_first(self) -> tuple:
        raise NotImplementedError

    @abstractmethod
    def get_all(self) -> list[tuple]:
        raise NotImplementedError

    @abstractmethod
    def delete_one(self, id: int) -> None:
        raise NotImplementedError

    @abstractmethod
    def update_one(self, data: dict) -> None:
        raise NotImplementedError

    @abstractmethod
    def get_all_by_conditions(self, conditions: list[Condition]) -> list[tuple]:
        raise NotImplementedError

    @abstractmethod
    def get_linked_records(self, this_record: dict, field: str) -> list[tuple]:
        raise NotImplementedError
