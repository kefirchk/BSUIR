class InvalidDataException(Exception):
    pass


class InvalidJSONQueryDataException(Exception):
    pass