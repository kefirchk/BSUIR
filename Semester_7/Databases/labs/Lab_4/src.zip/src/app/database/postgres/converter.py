import psycopg2
import bsddb3
import pickle
import os


class DBConverter:
    PATH_TO_SAVE = "app/database/data"

    def __init__(self, postgres_url: str):
        self.conn = psycopg2.connect(postgres_url)
        self.cursor = self.conn.cursor()
        if not os.path.exists(self.PATH_TO_SAVE):
            os.makedirs(self.PATH_TO_SAVE)
            print(f"Каталог '{self.PATH_TO_SAVE}' был создан.")
        else:
            print(f"Каталог '{self.PATH_TO_SAVE}' уже существует.")

    def fetch_tables_info(self):
        # Извлекаем имена всех таблиц в базе данных
        self.cursor.execute("""
            SELECT table_name 
            FROM information_schema.tables
            WHERE table_schema = 'public';
        """)
        tables = self.cursor.fetchall()

        tables_info = {}
        for table in tables:
            table_name = table[0]

            # Получаем столбцы таблицы
            self.cursor.execute(
                f"SELECT column_name FROM information_schema.columns WHERE table_name = '{table_name}';")
            columns = self.cursor.fetchall()

            # Определим первичный ключ таблицы
            self.cursor.execute(f"""
                SELECT a.column_name
                FROM information_schema.table_constraints t
                JOIN information_schema.key_column_usage a
                    ON a.constraint_name = t.constraint_name
                WHERE t.constraint_type = 'PRIMARY KEY'
                AND t.table_name = '{table_name}';
            """)
            primary_keys = self.cursor.fetchall()  # Могут быть несколько ключей
            primary_keys = [pk[0] for pk in primary_keys] if primary_keys else None

            # Сохраняем информацию о таблице (столбцы и первичный ключ)
            tables_info[table_name] = {
                "columns": [col[0] for col in columns],
                "primary_keys": primary_keys
            }

        return tables_info

    def fetch_data(self, table_name: str, columns):
        columns_str = ", ".join(columns)
        self.cursor.execute(f"SELECT {columns_str} FROM {table_name};")
        rows = self.cursor.fetchall()
        return rows

    def serialize_data(self, data, columns):
        serialized_data = {}
        for i in range(len(columns)):
            column_name = columns[i]  # Имя столбца
            column_value = data[i]  # Значение столбца
            serialized_data[column_name] = column_value
        return serialized_data

    def generate_combined_key(self, row, columns, primary_keys):
        key_values = [str(row[columns.index(col)]) for col in primary_keys]
        combined_key = "".join(key_values)
        return combined_key

    def create_berkeley_db(self, table_name: str, data, columns, primary_keys):
        db_name = f"{self.PATH_TO_SAVE}/{table_name}.db"
        db = bsddb3.hashopen(db_name, 'c')

        for row in data:
            if primary_keys:
                key = self.generate_combined_key(row, columns, primary_keys).encode()
            else:
                key = str(row[columns.index(primary_keys[0])]).encode()

            value = pickle.dumps(self.serialize_data(row, columns))  # Сериализуем данные
            db[key] = value

        db.close()

    def migrate_data(self):
        tables_info = self.fetch_tables_info()

        for table_name, table_info in tables_info.items():
            columns = table_info["columns"]
            primary_keys = table_info["primary_keys"]

            rows = self.fetch_data(table_name, columns)

            self.create_berkeley_db(table_name, rows, columns, primary_keys)
            print(f"Данные таблицы '{table_name}' успешно мигрированы в Berkeley DB.")

    def __del__(self):
        self.cursor.close()
        self.conn.close()
