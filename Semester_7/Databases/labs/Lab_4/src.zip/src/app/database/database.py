import pickle

import bsddb3

from logger import logger
from schemas import Condition


class Database:
    DB_PATH = 'app/database/data'

    def __init__(self, table_name: str):
        self.db_name = f"{self.DB_PATH}/{table_name}.db"
        self.db = bsddb3.hashopen(self.db_name, 'c')
        logger.info(f"База даных {self.db_name} открыта!")

    def create(self, key, value):
        try:
            key_encoded = str(key).encode()
            value_serialized = pickle.dumps(value)
            self.db[key_encoded] = value_serialized
            self.db.sync()  # Принудительная запись на диск
            logger.info(f"Запись с ключом {key} успешно добавлена.")
        except Exception as e:
            logger.error(f"Ошибка при добавлении записи: {e}")

    def read(self, key):
        try:
            key_encoded = str(key).encode()
            if key_encoded in self.db.keys():
                value = pickle.loads(self.db[key_encoded])
                return value
            else:
                logger.warning(f"Запись с ключом {key} не найдена.")
                return None
        except Exception as e:
            logger.error(f"Ошибка при чтении записи: {e}")
            return None

    def update(self, key, value):
        try:
            key_encoded = str(key).encode()
            if key_encoded in self.db.keys():
                value_serialized = pickle.dumps(value)
                self.db[key_encoded] = value_serialized
                self.db.sync()  # Принудительная запись на диск
                logger.info(f"Запись с ключом {key} успешно обновлена.")
            else:
                logger.warning(f"Запись с ключом {key} не найдена.")
        except Exception as e:
            logger.error(f"Ошибка при обновлении записи: {e}")

    def delete(self, key):
        try:
            key_encoded = str(key).encode()
            if key_encoded in self.db.keys():
                del self.db[key_encoded]
                self.db.sync()  # Принудительная запись на диск
                logger.info(f"Запись с ключом {key} успешно удалена.")
            else:
                logger.warning(f"Запись с ключом {key} не найдена.")
        except Exception as e:
            logger.error(f"Ошибка при удалении записи: {e}")

    def read_all(self):
        try:
            all_data = []
            for key in self.db.keys():
                value = pickle.loads(self.db[key])
                all_data.append((key.decode(), value))
            return all_data
        except Exception as e:
            logger.error(f"Ошибка при чтении всех записей: {e}")
            return []

    def __del__(self):
        try:
            self.db.close()
            logger.info(f"База данных {self.db_name} успешно закрыта.")
        except Exception as e:
            logger.error(f"Ошибка при закрытии базы данных: {e}")

    def read_all_by_conditions(self, conditions: list[Condition]) -> list:
        try:
            result = []
            for key in self.db.keys():
                value = pickle.loads(self.db[key])
                if self._check_conditions(value, conditions):
                    result.append((key.decode(), value))
            return result
        except Exception as e:
            logger.error(f"Ошибка при чтении записей с условиями: {e}")
            return []

    def _check_conditions(self, record: dict, conditions: list[Condition]) -> bool:
        for condition in conditions:
            field_value = record.get(condition.field_name)
            if field_value != condition.value:
                return False
        return True
