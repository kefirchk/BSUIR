import logging
import sys

from .color_formatter import ColorFormatter


class CustomLogger:
    def __init__(self, log_file='app/logger/logs/app.log'):
        self.logger = logging.getLogger()
        self.logger.setLevel(logging.DEBUG)  # Устанавливаем глобальный уровень логирования

        # Устанавливаем обработчики
        self._setup_console_handler()
        self._setup_file_handler(log_file)

    def _setup_console_handler(self):
        # Настройка обработчика для вывода в консоль
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.DEBUG)

        # Настройка цветного форматирования логов
        formatter = ColorFormatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        console_handler.setFormatter(formatter)

        # Добавляем обработчик в логгер
        self.logger.addHandler(console_handler)

    def _setup_file_handler(self, log_file):
        # Настройка для вывода в файл (без цвета)
        file_handler = logging.FileHandler(filename=log_file, encoding='utf-8')
        file_handler.setLevel(logging.INFO)

        # Настройка обычного форматирования для файлового вывода
        file_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(file_formatter)

        # Добавляем обработчик в логгер
        self.logger.addHandler(file_handler)

    def get_logger(self):
        return self.logger


logger = CustomLogger().get_logger()
