import logging


# ANSI escape-коды для цветов
class LogColors:
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    RESET = '\033[0m'


class ColorFormatter(logging.Formatter):
    def format(self, record):
        # Добавляем цвет в зависимости от уровня логирования
        if record.levelno == logging.INFO:
            record.msg = f"{LogColors.GREEN}{record.msg}{LogColors.RESET}"
        elif record.levelno == logging.WARNING:
            record.msg = f"{LogColors.YELLOW}{record.msg}{LogColors.RESET}"
        elif record.levelno == logging.ERROR or record.levelno == logging.CRITICAL:
            record.msg = f"{LogColors.RED}{record.msg}{LogColors.RESET}"
        return super().format(record)
