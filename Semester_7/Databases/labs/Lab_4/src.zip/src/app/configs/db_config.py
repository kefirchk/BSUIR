import schemas


class DBConfig:
    INCLUDED_TABLES = ['class', 'student', 'subject', 'teacher']
    EXCLUDED_TABLES = ['student_subject', 'teacher_subject']

    # Определяем соответствие моделей и их ключевых полей для поиска
    RELATED_FIELD_MAP = {
        'student': {'field': 'email', 'relation': 'students'},
        'subject': {'field': 'subject_name', 'relation': 'subjects'},
        'class': {'field': 'class_name', 'relation': 'class_'},
        'teacher': {'field': 'phone_no', 'relation': 'teacher'}
    }

    FIELD_TYPE_MAP = {
        "first_name": str,
        "gender_type": schemas.GenderType,
        "last_name": str,
        "email": str,
        "phone_no": str,
        "class_name": str,
        "age": int,
        "subject_name": str,
        "students": list[schemas.StudentBase],
        "subjects": list[schemas.SubjectBase],
        "subject": schemas.SubjectBase,
        "class_": schemas.ClassBase,
        "class_teacher": schemas.TeacherBase,
        "teachers": list[schemas.TeacherBase],
    }

db_settings = DBConfig()
