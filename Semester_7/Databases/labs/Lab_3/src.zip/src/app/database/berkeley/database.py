import bsddb3
import pickle

from app.logger import logger
from .postgres_to_berkeley import PostgreSQLToBerkeleyDB


class BerkeleyDBManager:
    PATH_TO_SAVE = PostgreSQLToBerkeleyDB.PATH_TO_SAVE

    def __init__(self, table_name: str):
        """Инициализация класса для работы с Berkeley DB."""
        self.db_name = f"{BerkeleyDBManager.PATH_TO_SAVE}/{table_name}.db"
        self.db = bsddb3.hashopen(self.db_name, 'c')

    def create(self, key, value):
        """Добавление записи в BerkeleyDB."""
        try:
            key_encoded = str(key).encode()
            value_serialized = pickle.dumps(value)  # Сериализуем значение
            self.db[key_encoded] = value_serialized
            logger.info(f"Запись с ключом {key} успешно добавлена.")
        except Exception as e:
            logger.error(f"Ошибка при добавлении записи: {e}")

    def read(self, key):
        """Чтение записи из BerkeleyDB по ключу."""
        try:
            key_encoded = str(key).encode()
            if key_encoded in self.db:
                value = pickle.loads(self.db[key_encoded])  # Десериализуем значение
                return value
            else:
                logger.warning(f"Запись с ключом {key} не найдена.")
                return None
        except Exception as e:
            logger.error(f"Ошибка при чтении записи: {e}")
            return None

    def update(self, key, value):
        """Обновление записи в BerkeleyDB по ключу."""
        try:
            key_encoded = str(key).encode()
            if key_encoded in self.db:
                value_serialized = pickle.dumps(value)
                self.db[key_encoded] = value_serialized
                logger.info(f"Запись с ключом {key} успешно обновлена.")
            else:
                logger.warning(f"Запись с ключом {key} не найдена.")
        except Exception as e:
            logger.error(f"Ошибка при обновлении записи: {e}")

    def delete(self, key):
        """Удаление записи из BerkeleyDB по ключу."""
        try:
            key_encoded = str(key).encode()
            if key_encoded in self.db:
                del self.db[key_encoded]
                logger.info(f"Запись с ключом {key} успешно удалена.")
            else:
                logger.warning(f"Запись с ключом {key} не найдена.")
        except Exception as e:
            logger.error(f"Ошибка при удалении записи: {e}")

    def read_all(self):
        """Чтение всех записей из BerkeleyDB."""
        try:
            all_data = []
            for key in self.db.keys():
                value = pickle.loads(self.db[key])
                all_data.append((key.decode(), value))
            return all_data
        except Exception as e:
            logger.error(f"Ошибка при чтении всех записей: {e}")
            return []

    def __del__(self):
        """Закрытие соединения с базой данных BerkeleyDB."""
        try:
            self.db.close()
            logger.info(f"База данных {self.db_name} успешно закрыта.")
        except Exception as e:
            logger.error(f"Ошибка при закрытии базы данных: {e}")
