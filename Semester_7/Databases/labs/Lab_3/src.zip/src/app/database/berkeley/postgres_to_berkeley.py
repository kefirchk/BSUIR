import psycopg2
import bsddb3
import pickle
import os


class PostgreSQLToBerkeleyDB:
    PATH_TO_SAVE = "app/database/berkeley/data"

    def __init__(self, postgres_url: str):
        """Инициализация класса для работы с PostgreSQL и Berkeley DB."""
        # Подключение к PostgreSQL
        self.conn = psycopg2.connect(postgres_url)
        self.cursor = self.conn.cursor()
        # Создание директории, если ее нет
        if not os.path.exists(PostgreSQLToBerkeleyDB.PATH_TO_SAVE):
            os.makedirs(PostgreSQLToBerkeleyDB.PATH_TO_SAVE)
            print(f"Директория '{PostgreSQLToBerkeleyDB.PATH_TO_SAVE}' была создана.")
        else:
            print(f"Директория '{PostgreSQLToBerkeleyDB.PATH_TO_SAVE}' уже существует.")

    def fetch_tables_info(self):
        """Получить список таблиц и их схемы в PostgreSQL."""
        # Извлекаем имена всех таблиц в базе данных
        self.cursor.execute("""
            SELECT table_name 
            FROM information_schema.tables
            WHERE table_schema = 'public';
        """)
        tables = self.cursor.fetchall()

        tables_info = {}
        for table in tables:
            table_name = table[0]

            # Получаем столбцы таблицы
            self.cursor.execute(
                f"SELECT column_name FROM information_schema.columns WHERE table_name = '{table_name}';")
            columns = self.cursor.fetchall()

            # Определим первичный ключ таблицы
            self.cursor.execute(f"""
                SELECT a.column_name
                FROM information_schema.table_constraints t
                JOIN information_schema.key_column_usage a
                    ON a.constraint_name = t.constraint_name
                WHERE t.constraint_type = 'PRIMARY KEY'
                AND t.table_name = '{table_name}';
            """)
            primary_keys = self.cursor.fetchall()  # Могут быть несколько ключей
            primary_keys = [pk[0] for pk in primary_keys] if primary_keys else None

            # Сохраняем информацию о таблице (столбцы и первичный ключ)
            tables_info[table_name] = {
                "columns": [col[0] for col in columns],
                "primary_keys": primary_keys
            }

        return tables_info

    def fetch_data(self, table_name: str, columns):
        """Получить все данные из таблицы PostgreSQL в том же порядке, что и столбцы."""
        # Формируем строку для выбора данных в том же порядке, как в columns
        columns_str = ", ".join(columns)
        self.cursor.execute(f"SELECT {columns_str} FROM {table_name};")
        rows = self.cursor.fetchall()
        return rows

    def serialize_data(self, data, columns):
        """Сериализовать данные строки в словарь с именами столбцов и их значениями."""
        serialized_data = {}
        for i in range(len(columns)):
            column_name = columns[i]  # Имя столбца
            column_value = data[i]  # Значение столбца
            serialized_data[column_name] = column_value
        return serialized_data

    def generate_combined_key(self, row, columns, primary_keys):
        """Генерация комбинированного ключа для промежуточных таблиц (многие ко многим)."""
        # Генерируем ключ, объединяя все значения внешних ключей, составляющих первичный ключ
        key_values = [str(row[columns.index(col)]) for col in primary_keys]
        combined_key = "_".join(key_values)  # Объединяем значения внешних ключей
        return combined_key

    def create_berkeley_db(self, table_name: str, data, columns, primary_keys):
        """Создать базу данных Berkeley DB для таблицы и записать в нее данные."""
        db_name = f"{PostgreSQLToBerkeleyDB.PATH_TO_SAVE}/{table_name}.db"
        db = bsddb3.hashopen(db_name, 'c')

        # Записываем каждую строку как запись в формате ключ-значение
        for row in data:
            # Если у таблицы есть первичный ключ, используем его
            if primary_keys:
                key = self.generate_combined_key(row, columns, primary_keys).encode()
            else:
                key = str(row[columns.index(primary_keys[0])]).encode()  # для остальных случаев

            value = pickle.dumps(self.serialize_data(row, columns))  # Сериализуем данные
            db[key] = value

        # Закрыть базу данных Berkeley DB
        db.close()

    def migrate_data(self):
        """Процесс миграции данных из PostgreSQL в Berkeley DB."""
        # Получаем информацию о таблицах
        tables_info = self.fetch_tables_info()

        # Для каждой таблицы:
        for table_name, table_info in tables_info.items():
            columns = table_info["columns"]
            primary_keys = table_info["primary_keys"]

            # Извлекаем данные из таблицы в том же порядке столбцов
            rows = self.fetch_data(table_name, columns)

            # Создаем Berkeley DB и записываем данные
            self.create_berkeley_db(table_name, rows, columns, primary_keys)
            print(f"Данные таблицы '{table_name}' успешно мигрированы в Berkeley DB.")

    def __del__(self):
        """Закрыть подключение к PostgreSQL."""
        self.cursor.close()
        self.conn.close()
