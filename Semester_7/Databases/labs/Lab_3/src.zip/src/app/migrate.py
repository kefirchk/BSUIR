from app.database.berkeley import PostgreSQLToBerkeleyDB


# Пример использования:
if __name__ == '__main__':
    # URL подключения к PostgreSQL (замените на ваш)
    postgres_url = 'postgresql://postgres:1234@localhost:5000/school'

    # Создаем объект для миграции данных
    migration = PostgreSQLToBerkeleyDB(postgres_url)

    # Мигрируем данные из PostgreSQL в Berkeley DB
    migration.migrate_data()

    print("Миграция данных завершена.")