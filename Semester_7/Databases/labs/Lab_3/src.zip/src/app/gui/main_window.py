from tkinter import Tk, Menu, Text, NSEW, NS, EW, FALSE, ttk, messagebox, RIGHT, BOTTOM, Y, X, filedialog
from tkinter.ttk import Label

from app.configs import db_settings
from app.logger import logger
from app.database.postgres import Database
from app.gui import TableWindow


class MainWindow(Tk):
    def __init__(self, db: Database):
        super().__init__()

        self.title("School Management System")
        self.geometry("440x360+540+220")
        self.resizable(False, False)
        self.option_add("*tearOff", FALSE)

        self.editor = self.create_text_editor()
        self.db = db
        self.create_menus()

        # Привязка горячих клавиш
        self.bind("<Control-q>", lambda event: self.query_menu.post(self.winfo_rootx(), self.winfo_rooty()))
        self.bind("<Control-t>", lambda event: self.table_menu.post(self.winfo_rootx(), self.winfo_rooty()))
        self.bind("<Control-e>", lambda event: self.editor.focus())
        self.bind("<Escape>", self.close_window)

        self.table_windows = []  # Список окон таблиц
        self.current_window_index = -1  # Индекс текущего активного окна
        self.bind("<Control-Tab>", self.switch_focus_to_next_window)  # Обработка Ctrl+Tab для переключения фокуса

    def close_window(self, event=None):
        for w in self.table_windows:
            w.destroy()
        self.destroy()

    @staticmethod
    def create_text_editor():
        """Создает текстовый редактор с полосами прокрутки."""
        logger.info("Создание текстового редактора для SQL-запросов")

        editor = Text(wrap="none", height=20, width=50)
        editor.grid(column=0, row=0, sticky=NSEW)

        ys = ttk.Scrollbar(orient="vertical", command=editor.yview)
        ys.grid(column=1, row=0, sticky=NS)

        xs = ttk.Scrollbar(orient="horizontal", command=editor.xview)
        xs.grid(column=0, row=1, sticky=EW)

        editor["yscrollcommand"] = ys.set
        editor["xscrollcommand"] = xs.set

        editor.insert("1.0", "Enter your query...")

        return editor

    def create_menus(self):
        """Создание главного меню с подменю."""
        main_menu = Menu(self)
        self.create_table_menu(main_menu)
        self.create_query_menu(main_menu)
        self.config(menu=main_menu)

    def create_table_menu(self, main_menu):
        """Создает подменю для таблиц базы данных."""
        logger.info("Создание подменю для таблиц базы данных")
        self.table_menu = Menu(main_menu)

        tables = self.db.get_tables()
        logger.info(f"Получены таблицы: {tables}")
        for t in db_settings.EXCLUDE_TABLES:
            if t in tables:
                tables.remove(t)

        for table_name in tables:
            self.table_menu.add_command(label=table_name, command=lambda name=table_name: self.show_table(name))
        main_menu.add_cascade(label="Tables", menu=self.table_menu)

    def create_query_menu(self, main_menu):
        """Создает подменю для работы с запросами."""
        logger.info("Создание подменю для работы с запросами")
        self.query_menu = Menu(main_menu)
        self.query_menu.add_command(label="Execute", command=lambda: self.execute_query(self.editor.get('1.0', 'end')))
        self.query_menu.add_command(label="Execute from file", command=self.execute_query_from_file)
        main_menu.add_cascade(label="Query", menu=self.query_menu)

    def show_table(self, table_name):
        """Отображение таблицы базы данных в новом окне."""
        logger.info(f"Отображение таблицы '{table_name}' в новом окне")
        table_window = TableWindow(parent_window=self, table_name=table_name, db=self.db)
        self.table_windows.append(table_window)  # Сохраняем ссылку на окно таблицы
        table_window.lift()  # Поднимаем окно на передний план
        table_window.focus_force()
        table_window.mainloop()

    def execute_query(self, query: str):
        """Выполнение SQL-запроса и отображение результата."""
        logger.info("Выполнение SQL-запроса")
        result = self.db.execute_query(query)
        if result['status']:
            logger.info(f"Запрос успешно выполнен!")
            messagebox.showinfo(title="Информация", message="Запрос успешно выполнен")
            if result['rows'] and result['column_names']:
                self.show_query_results_window(result['rows'], result['column_names'])
        else:
            logger.error(f"Запрос не выполнен.\n{result['error']}")
            messagebox.showerror(title="Ошибка", message=f"Запрос не выполнен.\n{result['error']}")

    def show_query_results_window(self, rows, column_names):
        """Отображение окна с результатами запроса."""
        result_window = self.create_result_window()
        result_table = self.create_result_table(result_window, column_names)
        if not rows:
            Label(result_table.master, text="No data in the table").pack()
        else:
            for row in rows:
                result_table.insert('', 'end', values=row)
        result_window.mainloop()

    def create_result_window(self):
        """Создание окна для отображения результатов."""
        result_window = Tk()
        result_window.option_add("*tearOff", FALSE)
        result_window.title("Query Result")
        result_window.geometry("600x400")
        result_window.resizable(False, False)
        return result_window

    @staticmethod
    def create_result_table(result_window, column_names):
        """Создание таблицы для отображения данных."""
        result_table = ttk.Treeview(result_window, columns=column_names, show="headings", height=20)
        ys = ttk.Scrollbar(result_window, orient="vertical", command=result_table.yview)
        xs = ttk.Scrollbar(result_window, orient="horizontal", command=result_table.xview)
        ys.pack(side=RIGHT, fill=Y)
        xs.pack(side=BOTTOM, fill=X)
        result_table["yscrollcommand"] = ys.set
        result_table["xscrollcommand"] = xs.set

        for col in column_names:
            result_table.heading(col, text=col)
            result_table.column(col, stretch=True)

        result_table.pack(fill="both")
        return result_table

    def execute_query_from_file(self):
        """Выполнение SQL-запроса из файла."""
        filepath = filedialog.askopenfile(title="Execute SQL-script")
        if filepath:
            with open(filepath.name, "r", encoding="utf-8") as file:
                query = file.read()
                self.execute_query(query)

    def switch_focus_to_next_window(self, event=None):
        """Циклическое переключение фокуса между главным окном и окнами TableWindow."""
        windows = [self] + self.table_windows  # Главный MainWindow и все окна TableWindow
        self.current_window_index = (self.current_window_index + 1) % len(windows)  # Циклическое переключение
        next_window = windows[self.current_window_index]

        next_window.lift()  # Поднимаем окно на передний план
        next_window.focus_force()  # Устанавливаем фокус на это окно
