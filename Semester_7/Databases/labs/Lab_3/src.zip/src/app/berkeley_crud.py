from app.database.berkeley import BerkeleyDBManager
from app.schemas import StudentBase, GenderType


if __name__ == "__main__":
    db_manager = BerkeleyDBManager("class")

    student = StudentBase(
        id=66,
        first_name="Vasya",
        last_name="Pupkin",
        email="<EMAIL>",
        gender=GenderType,
        class_id=1
    ).model_dump()

    db_manager.create(66, student)

    # Пример чтения всех записей
    all_students = db_manager.read_all()
    print("Все записи:")
    for key, student in all_students:
        print(f"Ключ: {key}, Данные: {student}")

    # Пример обновления данных
    student['email'] = "vasya_pupkin@mail.ru"
    db_manager.update(66, student)

    # Чтение одной записи
    student = db_manager.read(66)
    print(student)

    # Пример удаления записи
    db_manager.delete(66)

    # Пример чтения всех записей
    all_students = db_manager.read_all()
    print("Все записи:")
    for key, student in all_students:
        print(f"Ключ: {key}, Данные: {student}")