import pytest
from unittest import mock
import pickle
from app.database.berkeley import PostgreSQLToBerkeleyDB


@pytest.fixture
def pg_to_berkeley():
    with mock.patch('psycopg2.connect') as mock_connect:
        mock_conn = mock.MagicMock()
        mock_cursor = mock.MagicMock()
        mock_connect.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor

        # Инициализация объекта
        postgres_url = "postgresql://user:password@localhost:5432/mydb"
        migrator = PostgreSQLToBerkeleyDB(postgres_url)
        yield migrator, mock_conn, mock_cursor


# Тест инициализации и создания директории
def test_init(pg_to_berkeley):
    migrator, mock_conn, mock_cursor = pg_to_berkeley

    # Проверяем создание директории, если ее нет
    with mock.patch('os.makedirs') as mock_makedirs, \
            mock.patch('os.path.exists', return_value=False):
        migrator.__init__("postgresql://user:password@localhost:5432/mydb")
        mock_makedirs.assert_called_once_with(PostgreSQLToBerkeleyDB.PATH_TO_SAVE)


# Тест метода fetch_tables_info
def test_fetch_tables_info(pg_to_berkeley):
    migrator, mock_conn, mock_cursor = pg_to_berkeley

    # Мокаем возвращаемые значения для таблиц и столбцов
    mock_cursor.fetchall.side_effect = [
        [('table1',), ('table2',)],  # Таблицы
        [('col1',), ('col2',)],  # Столбцы для table1
        [('pk_col1',)],  # Первичный ключ для table1
        [('colA',), ('colB',)],  # Столбцы для table2
        []  # Нет первичного ключа для table2
    ]

    tables_info = migrator.fetch_tables_info()

    expected = {
        'table1': {
            'columns': ['col1', 'col2'],
            'primary_keys': ['pk_col1']
        },
        'table2': {
            'columns': ['colA', 'colB'],
            'primary_keys': None
        }
    }

    assert tables_info == expected
    assert mock_cursor.execute.call_count == 5


# Тест метода fetch_data
def test_fetch_data(pg_to_berkeley):
    migrator, mock_conn, mock_cursor = pg_to_berkeley

    mock_cursor.fetchall.return_value = [('row1_col1', 'row1_col2'), ('row2_col1', 'row2_col2')]

    columns = ['col1', 'col2']
    data = migrator.fetch_data('table1', columns)

    mock_cursor.execute.assert_called_with("SELECT col1, col2 FROM table1;")
    assert data == [('row1_col1', 'row1_col2'), ('row2_col1', 'row2_col2')]


# Тест сериализации данных
def test_serialize_data(pg_to_berkeley):
    migrator, _, _ = pg_to_berkeley

    row = ['value1', 'value2']
    columns = ['col1', 'col2']
    serialized = migrator.serialize_data(row, columns)

    expected = {'col1': 'value1', 'col2': 'value2'}
    assert serialized == expected


# Тест генерации комбинированного ключа
def test_generate_combined_key(pg_to_berkeley):
    migrator, _, _ = pg_to_berkeley

    row = ['value1', 'value2']
    columns = ['col1', 'col2']
    primary_keys = ['col1']
    key = migrator.generate_combined_key(row, columns, primary_keys)

    assert key == 'value1'


# Тест создания Berkeley DB
def test_create_berkeley_db(pg_to_berkeley):
    migrator, _, _ = pg_to_berkeley

    # Мокаем Berkeley DB
    with mock.patch('bsddb3.hashopen') as mock_db_open, \
            mock.patch('app.database.berkeley.PostgreSQLToBerkeleyDB.generate_combined_key',
                       return_value='key1'):
        mock_db = mock.MagicMock()
        mock_db_open.return_value = mock_db

        table_name = 'table1'
        columns = ['col1', 'col2']
        primary_keys = ['col1']
        data = [('value1', 'value2')]

        migrator.create_berkeley_db(table_name, data, columns, primary_keys)

        # Проверяем, что база данных открыта и запись добавлена
        mock_db_open.assert_called_with(f"{PostgreSQLToBerkeleyDB.PATH_TO_SAVE}/{table_name}.db", 'c')
        mock_db.__setitem__.assert_called_once_with(b'key1', pickle.dumps({'col1': 'value1', 'col2': 'value2'}))
        mock_db.close.assert_called_once()


# Тест миграции данных
def test_migrate_data(pg_to_berkeley):
    migrator, _, mock_cursor = pg_to_berkeley

    # Мокаем таблицы и данные
    mock_cursor.fetchall.side_effect = [
        [('table1',)],  # Таблицы
        [('col1',), ('col2',)],  # Столбцы для table1 (исправлено: два столбца)
        [('col1',)],  # Первичный ключ для table1
        [('value1', 'value2')]  # Данные таблицы (два столбца)
    ]

    with mock.patch('app.database.berkeley.PostgreSQLToBerkeleyDB.create_berkeley_db') as mock_create_db:
        migrator.migrate_data()

        # Проверяем, что создание Berkeley DB было вызвано с нужными аргументами
        mock_create_db.assert_called_once_with(
            'table1', [('value1', 'value2')], ['col1', 'col2'], ['col1']
        )
