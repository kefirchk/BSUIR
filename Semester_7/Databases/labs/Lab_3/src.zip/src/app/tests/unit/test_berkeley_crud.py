import pytest
from unittest import mock
from app.database.berkeley.database import BerkeleyDBManager
import pickle


@pytest.fixture
def db_manager():
    # Создаем mock для базы данных
    mock_db = mock.MagicMock()

    # Мокаем `bsddb3.hashopen`, чтобы возвращался наш mock-объект базы данных
    with mock.patch('bsddb3.hashopen', return_value=mock_db):
        manager = BerkeleyDBManager('test_table')
        yield manager


# Тест метода create
def test_create(db_manager):
    with mock.patch('app.logger.logger.info') as mock_logger_info:
        key, value = 'test_key', {'field': 'test_value'}
        db_manager.create(key, value)

        # Проверяем, что запись была сохранена с сериализованным значением
        db_manager.db.__setitem__.assert_called_with(b'test_key', pickle.dumps(value))
        mock_logger_info.assert_called_with(f"Запись с ключом {key} успешно добавлена.")


# Тест метода read, когда запись существует
def test_read_existing(db_manager):
    key, value = 'test_key', {'field': 'test_value'}
    encoded_key = key.encode()

    # Мокаем возвращаемое значение и проверку наличия ключа
    db_manager.db.__contains__.return_value = True
    db_manager.db.__getitem__.return_value = pickle.dumps(value)  # Мокаем возвращаемое значение

    with mock.patch('app.logger.logger.warning') as mock_logger_warning:
        result = db_manager.read(key)

        # Проверяем, что значение успешно десериализовано
        assert result == value
        mock_logger_warning.assert_not_called()


# Тест метода read, когда записи нет
def test_read_non_existing(db_manager):
    db_manager.db.__contains__.return_value = False  # Мокаем, что ключа нет

    with mock.patch('app.logger.logger.warning') as mock_logger_warning:
        result = db_manager.read('non_existing_key')

        # Проверяем, что вернется None, если ключ не найден
        assert result is None
        mock_logger_warning.assert_called_with("Запись с ключом non_existing_key не найдена.")


# Тест метода update, когда запись существует
def test_update_existing(db_manager):
    key, value = 'test_key', {'field': 'new_value'}
    db_manager.db.__contains__.return_value = True  # Мокаем, что ключ существует

    with mock.patch('app.logger.logger.info') as mock_logger_info:
        db_manager.update(key, value)

        # Проверяем, что значение обновлено
        db_manager.db.__setitem__.assert_called_with(b'test_key', pickle.dumps(value))
        mock_logger_info.assert_called_with(f"Запись с ключом {key} успешно обновлена.")


# Тест метода update, когда записи нет
def test_update_non_existing(db_manager):
    key, value = 'test_key', {'field': 'new_value'}
    db_manager.db.__contains__.return_value = False  # Мокаем, что ключа нет

    with mock.patch('app.logger.logger.warning') as mock_logger_warning:
        db_manager.update(key, value)

        # Проверяем, что запись не обновлена, если ключа нет
        db_manager.db.__setitem__.assert_not_called()
        mock_logger_warning.assert_called_with(f"Запись с ключом {key} не найдена.")


# Тест метода delete, когда запись существует
def test_delete_existing(db_manager):
    key = 'test_key'
    db_manager.db.__contains__.return_value = True  # Мокаем, что ключ существует

    with mock.patch('app.logger.logger.info') as mock_logger_info:
        db_manager.delete(key)

        # Проверяем, что запись удалена
        db_manager.db.__delitem__.assert_called_with(b'test_key')
        mock_logger_info.assert_called_with(f"Запись с ключом {key} успешно удалена.")


# Тест метода delete, когда записи нет
def test_delete_non_existing(db_manager):
    key = 'non_existing_key'
    db_manager.db.__contains__.return_value = False  # Мокаем, что ключа нет

    with mock.patch('app.logger.logger.warning') as mock_logger_warning:
        db_manager.delete(key)

        # Проверяем, что ничего не удалено, если ключа нет
        db_manager.db.__delitem__.assert_not_called()
        mock_logger_warning.assert_called_with(f"Запись с ключом {key} не найдена.")


# Тест метода read_all
def test_read_all(db_manager):
    # Мокаем ключи и значения
    db_manager.db.keys.return_value = [b'test_key1', b'test_key2']
    db_manager.db.__getitem__.side_effect = [pickle.dumps({'field': 'value1'}), pickle.dumps({'field': 'value2'})]

    with mock.patch('app.logger.logger.error') as mock_logger_error:
        result = db_manager.read_all()

        # Проверяем, что все записи прочитаны и десериализованы
        expected = [('test_key1', {'field': 'value1'}), ('test_key2', {'field': 'value2'})]
        assert result == expected
        mock_logger_error.assert_not_called()


# Тест метода __del__, проверка закрытия базы
def test_del(db_manager):
    # Мокаем метод close для базы данных
    with mock.patch.object(db_manager.db, 'close', return_value=None) as mock_close, \
            mock.patch('app.logger.logger.info') as mock_logger_info:
        db_manager.__del__()

        # Проверяем, что метод close был вызван
        mock_close.assert_called_once()

        # Проверяем, что запись в логгере выполнена
        mock_logger_info.assert_called_with(f"База данных {db_manager.db_name} успешно закрыта.")
